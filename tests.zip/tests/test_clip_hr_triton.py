"""clip_hr._to_rgb as one Triton kernel gives the torch path's values exactly."""

import pytest
import torch
from torch import Tensor
from traiNNer.data import clip_hr
from traiNNer.data.clip_hr import _HAS_TRITON, _to_rgb, _to_rgb_fits

needs_triton = pytest.mark.skipif(
    not torch.cuda.is_available() or not _HAS_TRITON, reason="needs CUDA and Triton"
)


def _planes(
    n: int, h: int, w: int, seed: int, device: str = "cuda"
) -> tuple[Tensor, Tensor, Tensor]:
    generator = torch.Generator().manual_seed(seed)
    y = torch.randint(0, 256, (n, 1, h, w), generator=generator, dtype=torch.uint8)
    u = torch.randint(0, 256, (n, 1, h // 2, w // 2), generator=generator)
    v = torch.randint(0, 256, (n, 1, h // 2, w // 2), generator=generator)
    return y.to(device), u.to(torch.uint8).to(device), v.to(torch.uint8).to(device)


def _torch_rgb(
    monkeypatch: pytest.MonkeyPatch, y: Tensor, u: Tensor, v: Tensor
) -> Tensor:
    with monkeypatch.context() as patch:
        patch.setattr(clip_hr, "_to_rgb_fits", lambda *_: False)
        return _to_rgb(y, u, v)


@needs_triton
@pytest.mark.parametrize(
    ("n", "h", "w"), [(1, 2, 2), (4, 16, 16), (8, 72, 132), (3, 270, 482), (2, 2, 512)]
)
def test_bit_identical(monkeypatch: pytest.MonkeyPatch, n: int, h: int, w: int) -> None:
    y, u, v = _planes(n, h, w, seed=h + w)
    assert _to_rgb_fits(y, u, v)
    actual = _to_rgb(y, u, v)
    expected = _torch_rgb(monkeypatch, y, u, v)
    assert actual.shape == (n, 3, h, w)
    assert actual.is_contiguous()
    assert torch.equal(actual, expected)


@needs_triton
def test_bit_identical_on_windows_of_larger_planes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    y, u, v = _planes(3, 96, 160, seed=9)
    window = (y[..., 8:72, 20:120], u[..., 4:36, 10:60], v[..., 4:36, 10:60])
    assert _to_rgb_fits(*window)
    assert torch.equal(_to_rgb(*window), _torch_rgb(monkeypatch, *window))


@needs_triton
def test_bit_identical_at_the_code_extremes(monkeypatch: pytest.MonkeyPatch) -> None:
    generator = torch.Generator().manual_seed(4)
    codes = torch.tensor([0, 1, 16, 128, 235, 240, 254, 255], dtype=torch.uint8)

    def plane(*shape: int) -> Tensor:
        index = torch.randint(0, len(codes), shape, generator=generator)
        return codes[index].cuda()

    y, u, v = plane(4, 1, 64, 64), plane(4, 1, 32, 32), plane(4, 1, 32, 32)
    assert torch.equal(_to_rgb(y, u, v), _torch_rgb(monkeypatch, y, u, v))


@pytest.mark.parametrize(
    ("device", "shapes", "dtype"),
    [
        ("cpu", ((2, 1, 8, 8), (2, 1, 4, 4)), torch.uint8),
        ("cuda", ((2, 1, 8, 8), (2, 1, 4, 4)), torch.int16),
        ("cuda", ((2, 1, 9, 8), (2, 1, 4, 4)), torch.uint8),
        ("cuda", ((2, 1, 8, 8), (2, 1, 4, 3)), torch.uint8),
        ("cuda", ((2, 3, 8, 8), (2, 1, 4, 4)), torch.uint8),
    ],
)
def test_falls_back(
    device: str,
    shapes: tuple[tuple[int, ...], tuple[int, ...]],
    dtype: torch.dtype,
) -> None:
    if device == "cuda" and not torch.cuda.is_available():
        pytest.skip("needs CUDA")
    y = torch.randint(16, 236, shapes[0], device=device).to(dtype)
    u = torch.randint(16, 241, shapes[1], device=device).to(dtype)
    v = torch.randint(16, 241, shapes[1], device=device).to(dtype)
    assert not _to_rgb_fits(y, u, v)
