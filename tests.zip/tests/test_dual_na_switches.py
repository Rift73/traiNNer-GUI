"""CPU contracts for the local and retrieval neighborhood-attention switches."""

import math
import os
from collections.abc import Iterator

import pytest
import torch
from torch import Tensor
from traiNNer.archs import dual_arch as dual
from traiNNer.archs.dual_arch import (
    DUAL,
    SecondOctaveTransfer,
    _SpatialAttention,
    attend_packed,
    pack_qk,
)


@pytest.fixture(scope="module", autouse=True)
def cpu_only() -> Iterator[None]:
    assert os.environ.get("CUDA_VISIBLE_DEVICES") == ""
    torch.set_num_threads(1)
    yield


def starts(length: int, keys: int, window: int, stride: int) -> Tensor:
    size = min(window, keys)
    centers = torch.arange(length) // stride
    return (centers - size // 2).clamp(0, keys - size)


def local_reference(attention: _SpatialAttention, x: Tensor) -> Tensor:
    """Dense per-query neighborhoods with the RPB table read by offset."""
    batch, channels, height, width = x.shape
    heads, dim, window = attention.heads, channels // attention.heads, attention.window
    tokens = x.flatten(2).transpose(1, 2)
    qkv = attention.qkv(tokens).reshape(batch, height * width, 3, heads, dim)
    q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
    yy, xx = torch.meshgrid(torch.arange(height), torch.arange(width), indexing="ij")
    y, x_ = yy.flatten(), xx.flatten()
    dy, dx = y[:, None] - y[None], x_[:, None] - x_[None]
    span = 2 * window - 1
    in_table = (dy.abs() < window) & (dx.abs() < window)
    index = ((dy + window - 1) * span + dx + window - 1).where(in_table, 0)
    bias = attention.relative_bias[index].permute(2, 0, 1)
    kh, kw = min(height, window), min(width, window)
    sy, sx = starts(height, height, window, 1)[y], starts(width, width, window, 1)[x_]
    mask = (
        (y[None] >= sy[:, None])
        & (y[None] < sy[:, None] + kh)
        & (x_[None] >= sx[:, None])
        & (x_[None] < sx[:, None] + kw)
    )
    assert torch.equal(mask.sum(-1), torch.full((height * width,), kh * kw))
    logits = (q * dim**-0.5) @ k.transpose(-2, -1) + bias
    out = logits.masked_fill(~mask, -torch.inf).softmax(-1) @ v
    return (
        out.transpose(1, 2).reshape(batch, height, width, channels).permute(0, 3, 1, 2)
    )


def retrieval_reference(q: Tensor, k: Tensor, v: Tensor, log_tau: Tensor) -> Tensor:
    """Slow per-query 48x48 coarse neighborhoods around each fine query's cell."""
    batch, channels, height, width = q.shape
    heads, kh_all, kw_all = channels // 32, k.shape[-2], k.shape[-1]
    kh, kw = min(48, kh_all), min(48, kw_all)
    sy, sx = starts(height, kh_all, 48, 2), starts(width, kw_all, 48, 2)
    tau = log_tau.exp().clamp(0.1, 10)
    scale = math.log(kh * kw) / (math.log(1024) * math.sqrt(32))
    out = torch.empty_like(q)
    for b in range(batch):
        for i in range(height):
            for j in range(width):
                keys = k[b, :, sy[i] : sy[i] + kh, sx[j] : sx[j] + kw]
                values = v[b, :, sy[i] : sy[i] + kh, sx[j] : sx[j] + kw]
                keys = keys.reshape(heads, 32, -1)
                values = values.reshape(heads, 32, -1)
                query = q[b, :, i, j].reshape(heads, 32) * tau[:, None]
                weights = ((query[:, :, None] * keys).sum(1) * scale).softmax(-1)
                out[b, :, i, j] = (weights[:, None] * values).sum(-1).reshape(-1)
    return out


def local_layer(**kwargs) -> _SpatialAttention:
    layer = _SpatialAttention(64, 2, 16, pos_bias="rpb", **kwargs).double()
    with torch.no_grad():
        layer.relative_bias.normal_()
    return layer


def test_defaults_and_bool_validation() -> None:
    with torch.device("meta"):
        model = dual.dual_light(scale=2)
    assert model.local_na and model.retrieval_na
    attentions = [m for m in model.modules() if isinstance(m, _SpatialAttention)]
    local = [m for m in attentions if m.pos_bias == "rpb"]
    assert local and all(m.local_na for m in local)
    assert not any(m.local_na for m in attentions if m.pos_bias == "rfb")
    with torch.device("meta"):
        off = dual.dual_light(scale=2, local_na=False, retrieval_na=False)
    assert not off.local_na and not off.retrieval_na
    assert not any(m.local_na for m in off.modules() if hasattr(m, "local_na"))
    for name in ("local_na", "retrieval_na"):
        with pytest.raises(ValueError, match=name):
            DUAL(**{name: 1})
    with pytest.raises(ValueError, match="local_na"):
        DUAL(qk="cosine", context_na=False)


@pytest.mark.parametrize("shape", [(16, 16), (5, 16), (16, 3), (9, 11)])
@pytest.mark.parametrize("shifted", [False, True])
def test_local_na_small_map_is_the_window_path(
    shape: tuple[int, int], shifted: bool
) -> None:
    torch.manual_seed(0)
    layer = local_layer(shifted=shifted)
    x = torch.randn(2, 64, *shape, dtype=torch.float64)
    expected = layer.pre_gate_core(x)
    layer.local_na = True
    assert torch.equal(layer.pre_gate_core(x), expected)


@pytest.mark.parametrize("shape", [(37, 45), (17, 70), (16, 17)])
@pytest.mark.parametrize("shifted", [False, True])
def test_local_na_matches_per_query_reference(
    shape: tuple[int, int], shifted: bool
) -> None:
    torch.manual_seed(1)
    layer = local_layer(shifted=shifted)
    layer.local_na = True
    x = torch.randn(1, 64, *shape, dtype=torch.float64)
    torch.testing.assert_close(
        layer.pre_gate_core(x), local_reference(layer, x), atol=1e-10, rtol=1e-10
    )


def test_local_na_chunking_matches_one_call(monkeypatch: pytest.MonkeyPatch) -> None:
    torch.manual_seed(2)
    layer = local_layer()
    layer.local_na = True
    x = torch.randn(1, 64, 37, 45, dtype=torch.float64)
    expected = layer.pre_gate_core(x)
    monkeypatch.setattr(dual, "_NA_ELEMENT_CAP", 2 * 64 * 23 * 23 * 3)
    torch.testing.assert_close(layer.pre_gate_core(x), expected, atol=1e-12, rtol=0)


def coarse_inputs(height: int, width: int, seed: int) -> tuple[Tensor, ...]:
    torch.manual_seed(seed)
    q = torch.randn(1, 64, height, width, dtype=torch.float64)
    k = torch.randn(1, 64, height // 2, width // 2, dtype=torch.float64)
    v = torch.randn(1, 64, height // 2, width // 2, dtype=torch.float64)
    return q, k, v, 0.3 * torch.randn(2, dtype=torch.float64)


@pytest.mark.parametrize("shape", [(96, 96), (40, 96), (2, 6)])
def test_retrieval_na_single_block_is_the_block_path(shape: tuple[int, int]) -> None:
    q, k, v, tau = coarse_inputs(*shape, 3)
    expected = attend_packed(pack_qk(q, k), v, tau)
    assert torch.equal(attend_packed(pack_qk(q, k, na=True), v, tau), expected)


@pytest.mark.parametrize("shape", [(118, 210), (98, 40)])
def test_retrieval_na_matches_per_query_reference(
    shape: tuple[int, int], monkeypatch: pytest.MonkeyPatch
) -> None:
    q, k, v, tau = coarse_inputs(*shape, 4)
    expected = retrieval_reference(q, k, v, tau)
    actual = attend_packed(pack_qk(q, k, na=True), v, tau)
    torch.testing.assert_close(actual, expected, atol=1e-10, rtol=1e-10)
    monkeypatch.setattr(dual, "_NA_ELEMENT_CAP", 2 * 64 * 51 * 51 * 5)
    chunked = attend_packed(pack_qk(q, k, na=True), v, tau)
    torch.testing.assert_close(chunked, actual, atol=1e-12, rtol=0)


def test_second_octave_transfer_follows_the_switch() -> None:
    torch.manual_seed(5)
    transfer = SecondOctaveTransfer(64).double()
    with torch.no_grad():
        transfer.out.weight.normal_()
        transfer.log_tau.normal_(0, 0.3)
    h, w = 100, 104
    q = torch.randn(1, 64, h, w, dtype=torch.float64)
    k = torch.randn(1, 64, h // 2, w // 2, dtype=torch.float64)
    t2 = torch.randn(1, 64, 2 * h, 2 * w, dtype=torch.float64)
    # Values only: without autograd the per-query reference keeps no graph.
    with torch.no_grad():
        na = transfer(t2, pack_qk(q, k, na=True), (h, w))
        blocks = transfer(t2, pack_qk(q, k), (h, w))
        g = dual.pack_grandchildren(transfer.value(t2))
        expected = transfer.out(
            dual.unpack_grandchildren(retrieval_reference(q, k, g, transfer.log_tau))
        )
    assert na.shape == blocks.shape
    assert not torch.allclose(na, blocks)
    torch.testing.assert_close(na, expected, atol=1e-10, rtol=1e-10)


def test_gradients_reach_both_neighborhood_paths() -> None:
    torch.manual_seed(6)
    model = DUAL(
        scale=2, embed_dim=64, depths=(2, 2), layer_indices=((0, 1), (0, 1))
    ).double()
    model.train()
    x = torch.rand(1, 3, 100, 98, dtype=torch.float64, requires_grad=True)
    with torch.no_grad():
        model.xr.project.weight.normal_(0, 0.1)
    model(x).square().mean().backward()
    assert x.grad is not None and torch.isfinite(x.grad).all()
    biases = [
        m.relative_bias.grad
        for m in model.modules()
        if isinstance(m, _SpatialAttention) and m.local_na
    ]
    assert biases and all(
        g is not None and torch.isfinite(g).all() and g.abs().sum() > 0 for g in biases
    )
    for grad in (model.xr.log_tau.grad, model.xr.query.weight.grad):
        assert grad is not None and torch.isfinite(grad).all() and grad.abs().sum() > 0
