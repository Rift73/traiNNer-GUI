import multiprocessing as mp
import os
import random
import subprocess
import sys
from functools import partial

import numpy as np
import pytest
from torch.utils.data import DataLoader
from traiNNer.data import worker_init_fn
from traiNNer.utils.rng import RNG

# Halves an image the way the datasets do, then prints the process's threads.
_RESIZE_AND_COUNT_THREADS = """
import numpy as np
from chainner_ext import ResizeFilter, resize

image = np.random.default_rng(0).random((256, 256, 3), dtype=np.float32)
resize(image, (128, 128), ResizeFilter.Hermite, False)
with open("/proc/self/status") as status:
    print(next(line.split()[1] for line in status if line.startswith("Threads:")))
"""


def test_worker_init_limits_the_resize_pool(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("RAYON_NUM_THREADS", raising=False)
    monkeypatch.setattr(RNG, "_rng", None)
    seeds: list[int] = []
    monkeypatch.setattr(np.random, "seed", seeds.append)
    monkeypatch.setattr(random, "seed", seeds.append)
    worker_init_fn(1, num_workers=4, rank=0, seed=7)
    assert os.environ["RAYON_NUM_THREADS"] == "1"
    assert seeds == [8, 8]
    assert RNG.get_rng() is not None


def _draw_worker_sample(_: int) -> tuple[float, float]:
    return RNG.get_rng().random(), RNG.get_codec_route_rng().random()


@pytest.mark.skipif("fork" not in mp.get_all_start_methods(), reason="requires fork")
def test_replacement_worker_uses_its_assigned_seed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(RNG, "_rng", None)
    monkeypatch.setattr(RNG, "_codec_route_rng", None)
    monkeypatch.setattr(RNG, "_seed", None)
    loader = DataLoader(
        range(1),
        batch_size=None,
        num_workers=1,
        persistent_workers=False,
        multiprocessing_context="fork",
        worker_init_fn=partial(worker_init_fn, num_workers=1, rank=0, seed=7),
        collate_fn=_draw_worker_sample,
    )
    first_pass = list(loader)

    # Training draws from both parent streams between loader passes.
    RNG.init_rng(89)
    _draw_worker_sample(0)
    assert list(loader) == first_pass


@pytest.mark.skipif(
    not sys.platform.startswith("linux") or (os.cpu_count() or 1) < 4,
    reason="counts the threads of a Linux process with several CPUs",
)
def test_resize_pool_honors_the_limit() -> None:
    def threads(limit: str | None) -> int:
        env = {k: v for k, v in os.environ.items() if k != "RAYON_NUM_THREADS"}
        if limit is not None:
            env["RAYON_NUM_THREADS"] = limit
        out = subprocess.run(
            [sys.executable, "-c", _RESIZE_AND_COUNT_THREADS],
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        return int(out.stdout.strip())

    assert threads("1") < threads(None)
