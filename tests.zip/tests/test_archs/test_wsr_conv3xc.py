"""WSR owns its Conv3XC: original eval arithmetic, training equal up to rounding."""

import ast
import copy
from collections.abc import Iterator
from pathlib import Path

import pytest
import torch
from traiNNer.archs import wsr_arch
from traiNNer.archs.span_arch import Conv3XC as SpanConv3XC
from traiNNer.archs.wsr_arch import Conv3XC, _fold_conv3xc


@pytest.fixture(autouse=True)
def cpu_only() -> Iterator[None]:
    previous = torch.get_num_threads()
    torch.set_num_threads(2)
    try:
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(291029)
            yield
    finally:
        torch.set_num_threads(previous)
    assert not torch.cuda.is_initialized()


def test_no_other_architecture_dependency() -> None:
    tree = ast.parse(Path(wsr_arch.__file__).read_text())
    imports = {
        node.module for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)
    }
    assert imports <= {"__future__", "typing", "torch", "traiNNer.utils.registry"}
    assert {
        alias.name
        for node in ast.walk(tree)
        if isinstance(node, ast.Import)
        for alias in node.names
    } <= {"copy", "math", "torch", "torch.nn.functional"}
    assert Conv3XC.__module__ == wsr_arch.__name__


@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
@pytest.mark.parametrize(
    ("cin", "cout", "gain", "stride", "relu"),
    [
        (3, 8, 2, 1, False),
        (8, 16, 2, 1, False),
        (16, 8, 1, 1, False),
        (8, 8, 2, 2, True),
    ],
)
def test_conv3xc_matches_original(
    dtype: torch.dtype, cin: int, cout: int, gain: int, stride: int, relu: bool
) -> None:
    kwargs = {"gain1": gain, "s": stride, "relu": relu}
    torch.manual_seed(291029)
    reference = SpanConv3XC(cin, cout, **kwargs).to(dtype)
    reference_rng = torch.random.get_rng_state().clone()
    torch.manual_seed(291029)
    local = Conv3XC(cin, cout, **kwargs).to(dtype)
    assert torch.equal(reference_rng, torch.random.get_rng_state())
    assert list(reference.state_dict()) == list(local.state_dict())
    for name, value in reference.state_dict().items():
        assert torch.equal(value, local.state_dict()[name]), name
    local.load_state_dict(reference.state_dict(), strict=True)

    x_reference = torch.randn(1, cin, 7, 9, dtype=dtype, requires_grad=True)
    x_local = x_reference.detach().clone().requires_grad_(True)
    y_reference, y_local = reference(x_reference), local(x_local)
    # Training composes one kernel from the branches: equal up to rounding.
    train_tolerance = 2e-5 if dtype == torch.float32 else 2e-11
    torch.testing.assert_close(
        y_local, y_reference, atol=train_tolerance, rtol=train_tolerance
    )
    cotangent = torch.randn_like(y_reference)
    y_reference.backward(cotangent)
    y_local.backward(cotangent)
    torch.testing.assert_close(
        x_local.grad, x_reference.grad, atol=train_tolerance, rtol=train_tolerance
    )
    for (name, old), (new_name, new) in zip(
        reference.named_parameters(), local.named_parameters(), strict=True
    ):
        assert name == new_name
        assert old.requires_grad == new.requires_grad
        if old.requires_grad:
            assert old.grad is not None and new.grad is not None
            assert torch.isfinite(new.grad).all()
            torch.testing.assert_close(
                new.grad, old.grad, atol=train_tolerance, rtol=train_tolerance
            )
        else:
            assert old.grad is None and new.grad is None

    reference.eval()
    local.eval()
    with torch.no_grad():
        assert torch.equal(reference(x_reference), local(x_local))
        # Cached eval convolutions must refresh after parameter changes.
        reference.conv[0].bias.add_(0.125)
        local.conv[0].bias.add_(0.125)
        assert torch.equal(reference(x_reference), local(x_local))
        for name, value in reference.state_dict().items():
            assert torch.equal(value, local.state_dict()[name]), name
        if stride == 1 and not relu:
            old_folded = _fold_conv3xc(reference)
            new_folded = _fold_conv3xc(local)
            assert torch.equal(old_folded(x_reference), new_folded(x_local))
            # Compare the permanent fold with the training path.
            trained = copy.deepcopy(local).train()(x_local)
            tolerance = 2e-6 if dtype == torch.float32 else 2e-12
            torch.testing.assert_close(
                new_folded(x_local), trained, atol=tolerance, rtol=tolerance
            )


@pytest.mark.parametrize("scale", [1, 2, 4])
@pytest.mark.parametrize(
    "name",
    [
        "wsr",
        "wsr_compact",
        "wsr_ultracompact",
        "wsr_superultracompact",
        "wsr_mobile",
    ],
)
def test_all_presets_use_local_conv3xc(name: str, scale: int) -> None:
    model = getattr(wsr_arch, name)(scale=scale)
    assert any(isinstance(module, Conv3XC) for module in model.modules())
    assert not any(isinstance(module, SpanConv3XC) for module in model.modules())
