"""composite_rainbow_pt as two Triton kernels against the torch path.

The kernels compute the YIQ transforms and the Gaussian weights in float32
without matmuls, so values agree to float rounding.
"""

import math
from collections.abc import Iterator

import pytest
import torch
from torch import Tensor
from traiNNer.data import gpu_degradations
from traiNNer.data.gpu_degradations import (
    _HAS_TRITON,
    _composite_rainbow_fits,
    composite_rainbow_pt,
)

needs_triton = pytest.mark.skipif(
    not torch.cuda.is_available() or not _HAS_TRITON, reason="needs CUDA and Triton"
)


def _image(b: int, h: int, w: int, seed: int) -> Tensor:
    """Noise plus a gradient and a hard edge, in [0, 1], on CUDA."""
    generator = torch.Generator(device="cuda").manual_seed(seed)
    noise = torch.rand(b, 3, h, w, device="cuda", generator=generator)
    ramp = torch.linspace(0.0, 1.0, w, device="cuda").expand(h, w)
    edge = (torch.arange(w, device="cuda") > w // 2).float()
    return (0.5 * noise + 0.3 * ramp + 0.2 * edge).clamp(0, 1)


def _torch_rainbow(
    monkeypatch: pytest.MonkeyPatch, image: Tensor, *args: float | bool
) -> Tensor:
    with monkeypatch.context() as patch:
        patch.setattr(gpu_degradations, "_composite_rainbow_fits", lambda *_: False)
        return composite_rainbow_pt(image, *args)


@pytest.fixture(autouse=True)
def _full_precision_matmul() -> Iterator[None]:
    # The torch path's YIQ transforms are matmuls; compare against full float32.
    precision = torch.get_float32_matmul_precision()
    torch.set_float32_matmul_precision("highest")
    yield
    torch.set_float32_matmul_precision(precision)


@needs_triton
@pytest.mark.parametrize(
    ("shape", "params"),
    [
        ((4, 96, 160), (0.25, 0.08, 1.0, True, 0.0)),
        ((4, 96, 160), (0.15, 0.15, 0.3, False, 1.0)),
        ((2, 64, 416), (0.35, 0.005, 0.7, True, 5.5)),  # bandwidth floor, radius 48
        ((3, 33, 41), (0.2, 0.02, 1.0, True, 2.0)),  # radius capped at w // 2
        ((2, 17, 6), (0.3, 0.1, 0.5, False, 3.0)),
        ((1, 1, 3), (0.3, 0.1, 1.0, True, 0.5)),
    ],
)
def test_matches_the_torch_path(
    monkeypatch: pytest.MonkeyPatch,
    shape: tuple[int, int, int],
    params: tuple[float, float, float, bool, float],
) -> None:
    image = _image(*shape, seed=sum(shape))
    assert _composite_rainbow_fits(image, params[1])
    actual = composite_rainbow_pt(image, *params)
    expected = _torch_rainbow(monkeypatch, image, *params)
    assert actual.shape == expected.shape
    assert actual.is_contiguous()
    assert (actual - expected).abs().max().item() <= 2e-4


@needs_triton
def test_random_parameters(monkeypatch: pytest.MonkeyPatch) -> None:
    image = _image(4, 96, 160, seed=7)
    generator = torch.Generator().manual_seed(3)
    for _ in range(12):
        u = torch.rand(4, generator=generator).tolist()
        params = (
            0.15 + 0.2 * u[0],
            0.005 + 0.145 * u[1],
            0.3 + 0.7 * u[2],
            u[3] < 0.5,
            2 * math.pi * u[0] * u[1],
        )
        actual = composite_rainbow_pt(image, *params)
        expected = _torch_rainbow(monkeypatch, image, *params)
        assert (actual - expected).abs().max().item() <= 2e-4, params


@needs_triton
def test_strided_input(monkeypatch: pytest.MonkeyPatch) -> None:
    image = _image(2, 64, 96, seed=2).to(memory_format=torch.channels_last)
    params = (0.25, 0.06, 0.8, True, 1.0)
    actual = composite_rainbow_pt(image, *params)
    expected = _torch_rainbow(monkeypatch, image.contiguous(), *params)
    assert (actual - expected).abs().max().item() <= 2e-4


@pytest.mark.parametrize(
    ("device", "dtype", "shape"),
    [
        ("cpu", torch.float32, (2, 3, 16, 16)),
        ("cuda", torch.float16, (2, 3, 16, 16)),
        ("cuda", torch.float32, (2, 4, 16, 16)),
        ("cuda", torch.float32, (2, 3, 16, 1)),  # width not above the radius
    ],
)
def test_falls_back(device: str, dtype: torch.dtype, shape: tuple[int, ...]) -> None:
    if not _HAS_TRITON or (device == "cuda" and not torch.cuda.is_available()):
        pytest.skip("needs CUDA and Triton")
    image = torch.rand(shape, device=device).to(dtype)
    assert not _composite_rainbow_fits(image, 0.08)
