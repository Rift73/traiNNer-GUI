import json
from pathlib import Path

import av
import numpy as np
import pytest
import torch
from chainner_ext import ResizeFilter, resize
from torch.utils.data import DataLoader
from traiNNer.data.clip_hr import hr_clip
from traiNNer.data.descale import descale, encode_light, linearize
from traiNNer.data.video_clip_dataset import VideoClipDataset
from traiNNer.data.video_index import index_path, open_video, to_rgb, write_index
from traiNNer.utils import RNG
from traiNNer.utils.redux_options import DatasetOptions

SHOT = 20
CUTS = [0, SHOT, 2 * SHOT]


def _shot_frame(shot: int, t: int) -> np.ndarray:
    """Three shots of different brightness and texture, each moving slowly."""
    y, x = np.mgrid[0:36, 0:64].astype(np.float64)
    base = (50, 120, 190)[shot]
    if shot == 0:
        texture = np.sin((x + t) / 4)
    elif shot == 1:
        texture = np.sign(np.sin((x - t) / 5) * np.sin(y / 5))
    else:
        texture = np.cos(np.hypot(x - 32 - t / 2, y - 18) / 3)
    gray = base + 25 * texture
    rgb = np.stack([gray, gray * 0.8 + 20, 255 - gray], axis=-1)
    return np.clip(rgb, 0, 255).astype(np.uint8)


@pytest.fixture(scope="module")
def video(tmp_path_factory: pytest.TempPathFactory) -> Path:
    path = tmp_path_factory.mktemp("clips") / "synthetic.mkv"
    with av.open(str(path), "w") as container:
        stream = container.add_stream("mpeg4", rate=24)
        stream.width, stream.height, stream.pix_fmt = 64, 36, "yuv420p"
        stream.codec_context.gop_size = 12
        stream.codec_context.max_b_frames = 2
        for shot in range(3):
            for t in range(SHOT):
                rgb = av.VideoFrame.from_ndarray(_shot_frame(shot, t), format="rgb24")
                frame = rgb.reformat(format="yuv420p")
                frame.pts = shot * SHOT + t
                container.mux(stream.encode(frame))
        container.mux(stream.encode())
    write_index(path, width=48, height=27)
    return path


def _options(video: Path, **overrides: object) -> DatasetOptions:
    options = {
        "name": "clips",
        "type": "videoclipdataset",
        "phase": "train",
        "dataroot_gt": [str(video.parent)],
        "scale": 2,
        "lq_size": 4,
        "use_hflip": True,
        "use_rot": True,
        "clip_lengths": [6, 8],
        "descale_size": (48, 27),
        "hr_size": (32, 18),
        "downscale_algorithm": "hermite",
        "descale_error_threshold": 1.0,
        "cut_clip_prob": 0.0,
        "use_time_reverse": False,
    }
    options.update(overrides)
    return DatasetOptions(**options)


_GENERATOR = {"rng": np.random.default_rng(0)}


@pytest.fixture(autouse=True)
def _project_rng(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(RNG, "get_rng", lambda: _GENERATOR["rng"])


def _seed(seed: int) -> None:
    _GENERATOR["rng"] = np.random.default_rng(seed)


def _shots(sample: dict) -> np.ndarray:
    return sample["shot_ids"].numpy()


_PLANES = ("gt_y", "gt_u", "gt_v")


def _gt(sample: dict, options: DatasetOptions) -> torch.Tensor:
    return hr_clip(*(sample[k] for k in _PLANES), sample["gt_geometry"], options)


def _same_item(a: dict, b: dict) -> bool:
    keys = (*_PLANES, "gt_geometry", "shot_ids")
    return a["gt_path"] == b["gt_path"] and all(torch.equal(a[k], b[k]) for k in keys)


def test_index_finds_cuts(video: Path) -> None:
    index = json.loads(index_path(video).read_text())
    assert index["cuts"] == CUTS
    assert index["frames"] == 3 * SHOT
    assert len(index["pts"]) == 3 * SHOT
    assert [e["frame"] for e in index["descale_error"]] == list(range(0, 60, 8))


def test_sample_shapes_and_constant_shot(video: Path) -> None:
    _seed(0)
    options = _options(video)
    dataset = VideoClipDataset(options)
    assert len(dataset) == 60 // 7
    assert dataset.frame_size == (36, 64)
    h, w = dataset.window
    for _ in range(10):
        sample = dataset[0]
        t = sample["gt_y"].shape[0]
        assert t in (6, 8)
        assert sample["gt_y"].shape == (t, 1, h, w)
        for key in ("gt_u", "gt_v"):
            assert sample[key].shape == (t, 1, h // 2, w // 2)
        assert all(sample[k].dtype == torch.uint8 for k in _PLANES)
        assert sample["gt_geometry"].shape == (9,)
        assert sample["gt_geometry"].dtype == torch.int64
        gt = _gt(sample, options)
        assert gt.shape == (t, 3, 8, 8)
        assert gt.dtype == torch.float32
        assert 0 <= gt.min() and gt.max() <= 1
        assert sample["shot_ids"].dtype == torch.int64
        assert len(set(_shots(sample))) == 1
        name, first = sample["gt_path"].split(":")
        assert name == "synthetic.mkv"
        assert _shots(sample)[0] == int(first) // SHOT


def test_batch_shares_clip_length(video: Path) -> None:
    _seed(1)
    loader = DataLoader(VideoClipDataset(_options(video)), batch_size=4)
    lengths = set()
    for i, batch in enumerate(loader):
        for key in _PLANES:
            assert batch[key].dim() == 5
            assert batch[key].shape[:2] == batch["shot_ids"].shape
        assert batch["gt_geometry"].shape == (4, 9)
        assert batch["gt_y"].shape[0] == 4
        lengths.add(batch["gt_y"].shape[1])
        if i == 5:
            break
    assert lengths <= {6, 8}


def test_seeking_matches_sequential_decode(video: Path) -> None:
    dataset = VideoClipDataset(_options(video))
    with open_video(video, threads=1) as container:
        sequential = [to_rgb(f) for f in container.decode(container.streams.video[0])]
    for first in (0, 13, 25, 37, 52):
        frames = dataset.decode_frames(0, first, 8)
        for k, frame in enumerate(frames):
            assert np.array_equal(frame, sequential[first + k])


def test_cut_spanning_clips_show_the_cut(video: Path) -> None:
    _seed(2)
    dataset = VideoClipDataset(_options(video, cut_clip_prob=1.0))
    for _ in range(10):
        sample = dataset[0]
        first = int(sample["gt_path"].split(":")[1])
        expected = (np.arange(first, first + len(_shots(sample)))) // SHOT
        assert len(set(expected)) > 1
        assert np.array_equal(_shots(sample), expected)


def test_bad_shot_is_never_sampled(video: Path, tmp_path: Path) -> None:
    copy = tmp_path / video.name
    copy.symlink_to(video)
    index = json.loads(index_path(video).read_text())
    for entry in index["descale_error"]:
        entry["p999"] = 0.5 if SHOT <= entry["frame"] < 2 * SHOT else 0.01
    index_path(copy).parent.mkdir()
    index_path(copy).write_text(json.dumps(index))
    _seed(3)
    dataset = VideoClipDataset(
        _options(copy, descale_error_threshold=0.1, cut_clip_prob=0.5)
    )
    for _ in range(12):
        assert 1 not in _shots(dataset[0])


def test_time_reverse_reverses_frames_and_shots(video: Path) -> None:
    plain = VideoClipDataset(_options(video, cut_clip_prob=1.0))
    reverse = VideoClipDataset(
        _options(video, cut_clip_prob=1.0, use_time_reverse=True)
    )
    reversed_once = False
    for seed in range(8):
        _seed(seed)
        a = plain[0]
        _seed(seed)
        b = reverse[0]
        assert a["gt_path"] == b["gt_path"]
        assert torch.equal(a["gt_geometry"], b["gt_geometry"])
        if not torch.equal(a["gt_y"], b["gt_y"]):
            reversed_once = True
            for key in _PLANES:
                assert torch.equal(a[key].flip(0), b[key])
            assert torch.equal(a["shot_ids"].flip(0), b["shot_ids"])
    assert reversed_once


def _linked_copies(video: Path, folder: Path, count: int) -> None:
    index_path(folder / "x.mkv").parent.mkdir()
    for k in range(count):
        copy = folder / f"copy{k}.mkv"
        copy.symlink_to(video)
        index_path(copy).write_text(index_path(video).read_text())


def test_at_most_two_containers_open(
    video: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _linked_copies(video, tmp_path, 3)
    opened = []

    def counting_open(path: str, threads: int) -> av.container.InputContainer:
        opened.append(Path(path).name)
        return open_video(path, threads)

    monkeypatch.setattr("traiNNer.data.video_clip_dataset.open_video", counting_open)
    dataset = VideoClipDataset(_options(tmp_path / "copy0.mkv"))
    for v in (0, 1, 2, 1, 0):
        dataset.decode_frames(v, 10, 2)
    # copy0 was closed when copy2 opened; copy1 stayed open.
    assert opened == ["copy0.mkv", "copy1.mkv", "copy2.mkv", "copy0.mkv"]


def test_hr_resize_in_named_light_domain(video: Path) -> None:
    rgb = VideoClipDataset(_options(video)).decode_frames(0, 5, 1)[0]
    stored = VideoClipDataset(_options(video, hr_linear_light=None)).hr_frame(rgb)
    linear = VideoClipDataset(_options(video)).hr_frame(rgb)
    small = descale(rgb, 48, 27, border="zero")
    expected = encode_light(
        resize(linearize(small, "gamma24"), (32, 18), ResizeFilter.Hermite, False),
        "gamma24",
    )
    assert np.allclose(linear, np.clip(expected, 0, 1), atol=1e-6)
    assert not np.allclose(stored, linear, atol=1e-3)


def test_same_seed_same_clips(video: Path) -> None:
    dataset = VideoClipDataset(_options(video, cut_clip_prob=0.3))
    runs = []
    for _ in range(2):
        _seed(4)
        runs.append([dataset[0] for _ in range(4)])
    for a, b in zip(*runs, strict=True):
        assert _same_item(a, b)


def _reference_clip(
    dataset: VideoClipDataset, rng: np.random.Generator
) -> tuple[str, torch.Tensor]:
    """gt_path and HR clip of the next item, drawn and made on the CPU."""
    opt = dataset.opt
    length = int(rng.choice(dataset.clip_lengths))
    v, first = dataset.draw(length, rng)
    hr_w, hr_h = opt.hr_size
    crop = dataset.crop
    top = int(rng.integers(hr_h - crop + 1))
    left = int(rng.integers(hr_w - crop + 1))
    hflip = opt.use_hflip and rng.random() < 0.5
    vflip = opt.use_rot and rng.random() < 0.5
    transpose = opt.use_rot and rng.random() < 0.5
    reverse = opt.use_time_reverse and rng.random() < 0.5
    frames = []
    for rgb in dataset.decode_frames(v, first, length):
        patch = dataset.hr_frame(rgb)[top : top + crop, left : left + crop]
        if hflip:
            patch = patch[:, ::-1]
        if vflip:
            patch = patch[::-1]
        if transpose:
            patch = patch.transpose(1, 0, 2)
        frames.append(np.ascontiguousarray(patch.transpose(2, 0, 1)))
    if reverse:
        frames.reverse()
    return f"{dataset.videos[v].name}:{first}", torch.from_numpy(np.stack(frames))


def test_same_seed_matches_cpu_reference(video: Path) -> None:
    options = _options(video, cut_clip_prob=0.3, use_time_reverse=True)
    dataset = VideoClipDataset(options)
    for seed in range(6):
        _seed(seed)
        sample = dataset[0]
        path, expected = _reference_clip(dataset, np.random.default_rng(seed))
        assert sample["gt_path"] == path
        assert (_gt(sample, options) - expected).abs().max() <= 2e-6
