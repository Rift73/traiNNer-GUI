"""resize_pt's lanczos mode as two Triton passes against the conv path.

The Triton path folds the lowpass into the bicubic taps, so it rounds
differently from _resample: values agree to float rounding, and a few 8-bit
codes differ by one.
"""

import pytest
import torch
from torch import Tensor
from traiNNer.data import degradations
from traiNNer.data.degradations import (
    _HAS_TRITON,
    _composed_lanczos,
    _resample,
    resize_pt,
)

needs_triton = pytest.mark.skipif(
    not torch.cuda.is_available() or not _HAS_TRITON, reason="needs CUDA and Triton"
)

# (n, c, h, w, target h, target w): OTF sizes, the eligibility edges (16 px,
# ratio 0.2, 1024 px), odd and non-square sizes, and one axis growing.
CASES = [
    (16, 3, 256, 256, 144, 144),
    (8, 3, 288, 288, 117, 117),
    (4, 3, 37, 53, 20, 31),
    (2, 3, 16, 16, 4, 4),
    (2, 3, 100, 100, 20, 20),
    (1, 3, 1024, 1024, 500, 512),
    (2, 1, 64, 80, 64, 30),
    (2, 3, 90, 64, 45, 100),
    (3, 3, 255, 129, 254, 128),
]


def _image(n: int, c: int, h: int, w: int, seed: int) -> Tensor:
    """Noise plus a gradient and a hard edge, in [0, 1], on CUDA."""
    generator = torch.Generator(device="cuda").manual_seed(seed)
    noise = torch.rand(n, c, h, w, device="cuda", generator=generator)
    ramp = torch.linspace(0.0, 1.0, w, device="cuda").expand(h, w)
    edge = (torch.arange(h, device="cuda") > h // 2).float()[:, None]
    return (0.5 * noise + 0.3 * ramp + 0.2 * edge).clamp(0, 1)


def _assert_close(actual: Tensor, expected: Tensor) -> None:
    assert actual.shape == expected.shape
    assert actual.dtype == expected.dtype
    assert actual.is_contiguous()
    assert (actual - expected).abs().max().item() <= 1e-5
    codes = (actual * 255).round() - (expected * 255).round()
    assert codes.abs().max().item() <= 1
    assert codes.ne(0).float().mean().item() <= 1e-3


@needs_triton
@pytest.mark.parametrize(("n", "c", "h", "w", "th", "tw"), CASES)
def test_matches_the_conv_path(
    monkeypatch: pytest.MonkeyPatch, n: int, c: int, h: int, w: int, th: int, tw: int
) -> None:
    calls = []

    def counted(img: Tensor, size: tuple[int, int]) -> Tensor:
        calls.append(size)
        return _composed_lanczos(img, size)

    monkeypatch.setattr(degradations, "_composed_lanczos", counted)
    image = _image(n, c, h, w, seed=h * w)
    _assert_close(
        resize_pt(image, "lanczos", size=(th, tw)), _resample(image, (th, tw))
    )
    assert calls == [(th, tw)]


@needs_triton
def test_matches_the_conv_path_at_random_scales() -> None:
    image = _image(4, 3, 256, 256, seed=3)
    generator = torch.Generator().manual_seed(7)
    for scale in (0.2 + 0.79 * torch.rand(40, generator=generator)).tolist():
        size = (round(256 * scale), round(256 * scale))
        _assert_close(
            resize_pt(image, "lanczos", scale_factor=scale), _resample(image, size)
        )


@needs_triton
def test_strided_inputs() -> None:
    image = _image(4, 3, 200, 300, seed=5)
    expected = _resample(image, (77, 101))
    _assert_close(
        resize_pt(
            image.to(memory_format=torch.channels_last), "lanczos", size=(77, 101)
        ),
        expected,
    )
    window = _image(4, 3, 240, 320, seed=6)[:, :, 20:220, 10:310]
    _assert_close(
        resize_pt(window, "lanczos", size=(77, 101)), _resample(window, (77, 101))
    )


def _fail(img: Tensor, size: tuple[int, int]) -> Tensor:
    raise AssertionError("the Triton path was taken")


@needs_triton
@pytest.mark.parametrize(
    ("device", "dtype", "shape", "size"),
    [
        ("cpu", torch.float32, (2, 3, 64, 64), (32, 32)),
        ("cuda", torch.float64, (2, 3, 64, 64), (32, 32)),
        ("cuda", torch.float32, (2, 3, 15, 64), (8, 32)),  # side below 16
        ("cuda", torch.float32, (2, 3, 100, 100), (19, 19)),  # ratio below 0.2
        ("cuda", torch.float32, (1, 3, 1100, 600), (550, 300)),  # side above 1024
        ("cuda", torch.float32, (2, 3, 64, 64), (64, 64)),  # no axis shrinks
        ("cuda", torch.float32, (2, 3, 64, 64), (96, 80)),
    ],
)
def test_falls_back_outside_the_kernel_limits(
    monkeypatch: pytest.MonkeyPatch,
    device: str,
    dtype: torch.dtype,
    shape: tuple[int, int, int, int],
    size: tuple[int, int],
) -> None:
    monkeypatch.setattr(degradations, "_composed_lanczos", _fail)
    image = torch.rand(shape, device=device, dtype=dtype)
    assert torch.equal(resize_pt(image, "lanczos", size=size), _resample(image, size))


@needs_triton
def test_falls_back_when_the_input_needs_gradients(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(degradations, "_composed_lanczos", _fail)
    image = _image(2, 3, 64, 64, seed=1).requires_grad_()
    resize_pt(image, "lanczos", size=(32, 32)).sum().backward()
    assert image.grad is not None
