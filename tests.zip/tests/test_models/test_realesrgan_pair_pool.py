"""The training pair pool keeps its pairs in place and tracks their logical
order; it delivers, keeps and shuffles exactly as the pool that gathers its
whole contents in the shuffled order on every update. The reference below is
that gathering pool."""

from __future__ import annotations

from collections.abc import Callable
from operator import methodcaller

import pytest
import torch
from torch import Tensor
from traiNNer.models.realesrgan_model import RealESRGANModel

QUEUE = 12
BATCH = 3
DISPATCHES = 45
REFILL_AT = 25

DEVICES = ["cpu"] + (["cuda"] if torch.cuda.is_available() else [])


def _gathering_dequeue_and_enqueue(model: RealESRGANModel) -> None:
    """The pool that gathers all of its pairs in the shuffled order."""
    assert model.lq is not None
    assert model.gt is not None
    b, c, h, w = model.lq.size()
    if model.queue_lr is None:
        model.queue_lr = torch.zeros(
            model.queue_size, c, h, w, device=model.lq.device, dtype=model.lq.dtype
        )
        _, c, h, w = model.gt.size()
        model.queue_gt = torch.zeros(
            model.queue_size, c, h, w, device=model.gt.device, dtype=model.gt.dtype
        )
        model.queue_ptr = 0
    assert model.queue_gt is not None
    if model.queue_ptr == model.queue_size:
        idx = torch.randperm(model.queue_size)
        device_idx = idx.to(model.lq.device)
        model.queue_lr = model.queue_lr[device_idx]
        model.queue_gt = model.queue_gt[device_idx]
        lq = model.queue_lr[0:b].clone()
        gt = model.queue_gt[0:b].clone()
        model.queue_lr[0:b] = model.lq.clone()
        model.queue_gt[0:b] = model.gt.clone()
        model.lq = lq
        model.gt = gt
    else:
        model.queue_lr[model.queue_ptr : model.queue_ptr + b] = model.lq.clone()
        model.queue_gt[model.queue_ptr : model.queue_ptr + b] = model.gt.clone()
        model.queue_ptr = model.queue_ptr + b


def _pool_model() -> RealESRGANModel:
    model = object.__new__(RealESRGANModel)
    model.queue_size = QUEUE
    model.queue_lr = None
    model.queue_gt = None
    model.queue_ptr = 0
    return model


def _run(
    model: RealESRGANModel,
    update: Callable[[RealESRGANModel], None],
    rng_state: Tensor,
) -> Tensor:
    """Run one update and return the default generator state afterward."""
    torch.set_rng_state(rng_state)
    update(model)
    return torch.get_rng_state()


@pytest.mark.parametrize("device", DEVICES)
def test_logical_pool_matches_the_gathering_pool(device: str) -> None:
    reference = _pool_model()
    pool = _pool_model()
    data = torch.Generator(device="cpu").manual_seed(3)
    torch.manual_seed(11)
    for step in range(DISPATCHES):
        if step == REFILL_AT:
            # A refill: the pool starts over empty.
            for model in (reference, pool):
                model.queue_lr = None
                model.queue_ptr = 0
        lq = torch.rand(BATCH, 3, 4, 5, generator=data).to(device)
        gt = torch.rand(BATCH, 3, 8, 10, generator=data).to(device)
        if step % 2:
            # The pool takes channels-last batches as they come.
            lq = lq.to(memory_format=torch.channels_last)
            gt = gt.to(memory_format=torch.channels_last)
        reference.lq, reference.gt = lq.clone(), gt.clone()
        pool.lq, pool.gt = lq.clone(), gt.clone()
        rng_state = torch.get_rng_state()
        expected_state = _run(reference, _gathering_dequeue_and_enqueue, rng_state)
        state = _run(pool, methodcaller("_dequeue_and_enqueue"), rng_state)
        assert torch.equal(state, expected_state)

        assert pool.lq is not None and reference.lq is not None
        assert pool.gt is not None and reference.gt is not None
        assert torch.equal(pool.lq, reference.lq)
        assert torch.equal(pool.gt, reference.gt)
        assert pool.lq.dtype == reference.lq.dtype
        assert pool.lq.stride() == reference.lq.stride()
        assert pool.gt.stride() == reference.gt.stride()
        assert pool.queue_lr is not None and pool.queue_gt is not None
        assert pool.queue_order is not None
        for delivered, stored in ((pool.lq, pool.queue_lr), (pool.gt, pool.queue_gt)):
            assert delivered.untyped_storage().data_ptr() != (
                stored.untyped_storage().data_ptr()
            )

        order = pool.queue_order.to(device)
        assert torch.equal(pool.queue_lr[order], reference.queue_lr)
        assert torch.equal(pool.queue_gt[order], reference.queue_gt)
        assert pool.queue_ptr == reference.queue_ptr
