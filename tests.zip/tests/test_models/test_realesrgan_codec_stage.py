"""RealESRGANModel.feed_data in image training runs each video-codec round trip
on the calling thread, at its place in the project RNG's stream: after the
chroma sampling draw of the codec stage and before the next draw of the chain.

DegradeAheadPrefetcher on image training: its schedule, its results against
feeding batches one by one and against thread timing, WebP jobs in the pool,
and which models the trainer gives it.
"""

import threading
import time
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Any
from unittest.mock import Mock

import msgspec
import numpy as np
import pytest
import torch
from torch import Tensor
from traiNNer.data.prefetch_dataloader import CPUPrefetcher
from traiNNer.models import degrades_ahead, realesrgan_model
from traiNNer.models.rdual_model import RDUALModel
from traiNNer.models.realesrgan_model import (
    DegradeAheadPrefetcher,
    DegradingBatch,
    RealESRGANModel,
    ThickLines,
)
from traiNNer.models.realesrgan_paired_model import RealESRGANPairedModel
from traiNNer.models.sr_model import SRModel
from traiNNer.utils import DiffJPEG
from traiNNer.utils.misc import set_random_seed
from traiNNer.utils.redux_options import ReduxOptions
from traiNNer.utils.rng import RNG

OPTIONS = {
    "name": "codec_stage",
    "scale": 2,
    "num_gpu": 0,
    "path": {},
    "high_order_degradation": True,
    "compress_prob": 1.0,
    "compress_prob2": 1.0,
    "compress_algorithms": ["h264"],
    "compress_algorithm_probs": [1.0],
    "compress_algorithms2": ["h264"],
    "resize_prob": [0.0, 0.0, 1.0],
    "resize_prob2": [0.0, 0.0, 1.0],
    "compress_algorithm_probs2": [1.0],
    "datasets": {
        "train": {
            "name": "codec_stage",
            "type": "RealESRGANDataset",
            "phase": "train",
            "scale": 2,
            "dataroot_gt": ["unused"],
            "gt_size": 32,
        }
    },
    "train": {"total_iter": 1},
}


class _LoggedRNG:
    """The project generator, logging the name of every method called on it."""

    def __init__(self, rng: np.random.Generator, log: list[str]) -> None:
        self._rng = rng
        self._log = log

    def __getattr__(self, name: str) -> Any:
        method = getattr(self._rng, name)

        def logged(*args: Any, **kwargs: Any) -> Any:
            self._log.append(name)
            return method(*args, **kwargs)

        return logged


@pytest.fixture(autouse=True)
def _contiguous_filter2d(monkeypatch: pytest.MonkeyPatch) -> None:
    # Some CPU ops return channels-last tensors, which filter2d's .view()
    # rejects; the same filter on a contiguous copy gives the same values.
    filter2d: Callable[[Tensor, Tensor], Tensor] = realesrgan_model.filter2d
    monkeypatch.setattr(
        realesrgan_model, "filter2d", lambda img, k: filter2d(img.contiguous(), k)
    )


def _model(**changes: Any) -> RealESRGANModel:
    """The attributes feed_data reads, as RealESRGANModel.__init__ sets them."""
    opt = msgspec.convert({**OPTIONS, **changes}, ReduxOptions)
    model = object.__new__(RealESRGANModel)
    model.opt = opt
    model.is_train = True
    model.device = torch.device("cpu")
    model.memory_format = torch.preserve_format
    model.lq = None
    model.gt = None
    model.queue_lr = None
    model.queue_gt = None
    model.queue_ptr = 0
    model.queue_size = opt.queue_size
    model.kernel1 = None
    model.kernel2 = None
    model.sinc_kernel = None
    model.jpeger = DiffJPEG(differentiable=False)
    model.thicklines = ThickLines()
    model.otf_debug = False
    model.otf_debug_limit = 0
    model.vosr_target = None
    model.batch_augment = None
    return model


def test_video_codec_runs_inline_in_draw_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    log: list[str] = []
    threads: list[int] = []
    prepare = realesrgan_model.prepare_video_batch

    def logged_prepare(*args: Any, **kwargs: Any) -> Any:
        round_trip, finish = prepare(*args, **kwargs)

        def logged_round_trip() -> Tensor:
            log.append("round trip")
            threads.append(threading.get_ident())
            return round_trip()

        return logged_round_trip, finish

    monkeypatch.setattr(realesrgan_model, "prepare_video_batch", logged_prepare)
    monkeypatch.setattr(RNG, "_rng", _LoggedRNG(np.random.default_rng(0), log))
    torch.manual_seed(0)
    kernel = torch.zeros(2, 21, 21)
    kernel[:, 10, 10] = 1
    model = _model()
    model.feed_data(
        {
            "gt": torch.rand(2, 3, 32, 32, generator=torch.Generator().manual_seed(1)),
            "kernel1": kernel,
            "kernel2": kernel,
            "sinc_kernel": kernel,
        }
    )
    assert model.lq is not None
    assert model.lq.shape == (2, 3, 16, 16)
    assert threads == [threading.get_ident()] * 2
    stages = [i for i, name in enumerate(log) if name == "round trip"]
    assert len(stages) == 2
    for i in stages:
        # The chroma sampling draw of prepare_video_batch comes just before.
        assert log[i - 1] == "choice"
    # Stage 1 is followed by the blur_prob2 draw of the second degradation.
    assert log[stages[0] + 1] == "uniform"


# Every stage compresses with a job or JPEG; sizes stay even. Only codecs that
# give the same frames every time for the same input.
AHEAD = {
    "compress_algorithms": ["mpeg2", "mpeg4", "jpeg", "webp"],
    "compress_algorithm_probs": [1.0, 1.0, 1.0, 1.0],
    "compress_algorithms2": ["mpeg2", "mpeg4", "jpeg", "webp"],
    "compress_algorithm_probs2": [1.0, 1.0, 1.0, 1.0],
}
WEBP = {
    "compress_algorithms": ["webp"],
    "compress_algorithm_probs": [1.0],
    "compress_algorithms2": ["webp"],
    "compress_algorithm_probs2": [1.0],
}


def _raw_batches(count: int) -> list[dict[str, Tensor]]:
    """Raw batches of four textured images; the GT of batch k averages
    0.05 + k / 32."""
    kernel = torch.zeros(4, 21, 21)
    kernel[:, 10, 10] = 1
    texture = torch.rand(4, 3, 64, 64, generator=torch.Generator().manual_seed(1))
    return [
        {
            "gt": 0.05 + k / 32 + 0.02 * (texture - 0.5),
            "kernel1": kernel,
            "kernel2": kernel,
            "sinc_kernel": kernel,
        }
        for k in range(count)
    ]


def _batch_number(data: Any) -> int:
    return round((float(data["gt"].mean()) - 0.05) * 32)


def _seeded(monkeypatch: pytest.MonkeyPatch, seed: int) -> None:
    set_random_seed(seed)
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(seed))


def _ahead(
    model: RealESRGANModel, batches: list[dict[str, Tensor]]
) -> DegradeAheadPrefetcher:
    return DegradeAheadPrefetcher(CPUPrefetcher(batches), model)


def _delivered(
    monkeypatch: pytest.MonkeyPatch,
    model: RealESRGANModel,
    batches: list[dict[str, Tensor]],
    seed: int,
) -> list[Any]:
    _seeded(monkeypatch, seed)
    ahead = _ahead(model, batches)
    delivered = []
    while (data := ahead.next()) is not None:
        delivered.append(data)
    return delivered


class _InlinePool(ThreadPoolExecutor):
    """Runs each job when it is submitted, one after another."""

    def submit(self, fn: Callable[..., Any], /, *args: Any, **kwargs: Any) -> Future:
        future: Future = Future()
        future.set_result(fn(*args, **kwargs))
        return future


class _DelayingPool(ThreadPoolExecutor):
    """Starts each job after a delay drawn on the submitting thread."""

    def __init__(self, seed: int) -> None:
        super().__init__(max_workers=4)
        self.delays = np.random.default_rng(seed)

    def submit(self, fn: Callable[..., Any], /, *args: Any, **kwargs: Any) -> Future:
        delay = float(self.delays.uniform(0.0, 0.03))

        def delayed() -> Any:
            time.sleep(delay)
            return fn(*args, **kwargs)

        return super().submit(delayed)


def test_ahead_without_stride_feeds_batches_one_by_one(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(RealESRGANModel, "ahead_stride", 0)
    model = _model(**AHEAD)
    batches = _raw_batches(6)
    delivered = _delivered(monkeypatch, model, batches, 3)
    assert len(delivered) == 6
    _seeded(monkeypatch, 3)
    for batch, data in zip(batches, delivered, strict=True):
        model.feed_data(batch)
        assert torch.equal(model.lq, data["lq"])
        assert torch.equal(model.gt, data["gt"])


def test_ahead_does_not_depend_on_thread_timing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model = _model(**AHEAD)
    batches = _raw_batches(9)
    model.degradation_pool = _InlinePool(max_workers=1)
    inline = _delivered(monkeypatch, model, batches, 5)
    model.degradation_pool = _DelayingPool(9)
    pooled = _delivered(monkeypatch, model, batches, 5)
    assert len(inline) == len(pooled) == 9
    for a, b in zip(inline, pooled, strict=True):
        assert torch.equal(a["lq"], b["lq"])
        assert torch.equal(a["gt"], b["gt"])


def test_ahead_schedule(monkeypatch: pytest.MonkeyPatch) -> None:
    # Keyed by the batches themselves, which keeps them alive.
    advanced: dict[DegradingBatch, list[int]] = {}
    finished: dict[DegradingBatch, int] = {}
    advance = RealESRGANModel.advance_batch
    finish = RealESRGANModel.finish_batch

    def logged_advance(self: RealESRGANModel, batch: DegradingBatch) -> None:
        advanced.setdefault(batch, []).append(batch.age)
        advance(self, batch)

    def logged_finish(self: RealESRGANModel, batch: DegradingBatch) -> Any:
        finished[batch] = batch.age
        return finish(self, batch)

    monkeypatch.setattr(RealESRGANModel, "advance_batch", logged_advance)
    monkeypatch.setattr(RealESRGANModel, "finish_batch", logged_finish)
    model = _model(**AHEAD)
    assert model.ahead_stride == 3
    _seeded(monkeypatch, 0)
    batches = _raw_batches(12)
    ahead = _ahead(model, batches)
    for _ in range(2):  # two epochs
        ahead.reset()
        advanced.clear()
        finished.clear()
        numbers = []
        while (data := ahead.next()) is not None:
            numbers.append(_batch_number(data))
        assert numbers == list(range(12))
        assert sorted(advanced.values()) == [[3, 6]] * 12
        assert list(finished.values()) == [6] * 12
    # Dropping (as the trainer does for a GPU lease) and resetting both empty
    # the flight; next() goes on with the inner prefetcher's next batch.
    ahead.reset()
    assert _batch_number(ahead.next()) == 0  # raw batches 0..6 pulled
    assert _batch_number(ahead.next()) == 1  # raw batch 7 pulled
    assert len(ahead.in_flight) == 6
    ahead.drop()
    assert len(ahead.in_flight) == 0
    assert _batch_number(ahead.next()) == 8
    ahead.reset()
    assert len(ahead.in_flight) == 0
    assert _batch_number(ahead.next()) == 0


def test_webp_job_runs_inline_in_feed_data_and_in_the_pool_ahead(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    threads: list[str] = []
    prepare = realesrgan_model.prepare_webp_batch

    def logged(*args: Any, **kwargs: Any) -> Any:
        round_trip, finish = prepare(*args, **kwargs)

        def logged_round_trip() -> Tensor:
            threads.append(threading.current_thread().name)
            return round_trip()

        return logged_round_trip, finish

    monkeypatch.setattr(realesrgan_model, "prepare_webp_batch", logged)
    monkeypatch.setattr(RealESRGANModel, "ahead_stride", 0)
    model = _model(**WEBP)
    batches = _raw_batches(3)
    _seeded(monkeypatch, 2)
    plain = []
    for batch in batches:
        model.feed_data(batch)
        plain.append(model.lq)
    assert threads == [threading.current_thread().name] * 6
    threads.clear()
    delivered = _delivered(monkeypatch, model, batches, 2)
    assert len(threads) == 6
    assert all(name.startswith("degradation") for name in threads)
    for lq, data in zip(plain, delivered, strict=True):
        assert torch.equal(lq, data["lq"])


def test_which_models_degrade_ahead() -> None:
    def bare(cls: type, **attributes: Any) -> Any:
        model = object.__new__(cls)
        model.is_train = True
        for name, value in attributes.items():
            setattr(model, name, value)
        return model

    assert degrades_ahead(bare(RealESRGANModel))
    assert degrades_ahead(bare(RDUALModel))
    assert not degrades_ahead(bare(RealESRGANModel, is_train=False))
    assert not degrades_ahead(bare(RealESRGANPairedModel))
    assert not degrades_ahead(bare(SRModel))
    assert not degrades_ahead(Mock())


def test_prepared_batch_installs_without_running_degradation_again(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model = _model(**AHEAD)
    _seeded(monkeypatch, 1)
    data = model.finish_batch(model.start_batch(_raw_batches(1)[0]))
    monkeypatch.setattr(model, "start_batch", Mock(side_effect=AssertionError))

    model.feed_data(data)

    assert model.lq is data["lq"]
    assert model.gt is data["gt"]
