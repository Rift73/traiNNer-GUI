"""train.vosr_target: VOSR's restoration of each degraded LR replaces the HR in RealESRGANModel.feed_data.

The feed_data tests run the real OTF chain on the CPU (no NLMeans or custom degradations) with a recording
stand-in for the TensorRT teacher.
"""

from pathlib import Path
from types import SimpleNamespace
from typing import cast

import msgspec
import numpy as np
import pytest
import torch
from torch import Tensor
from torch.nn import functional
from torch.utils.data import default_collate
from traiNNer.data.realesrgan_dataset import RealESRGANDataset
from traiNNer.losses.vosr_loss import VosrTeacher
from traiNNer.models import realesrgan_model
from traiNNer.models.realesrgan_model import RealESRGANModel
from traiNNer.models.sr_model import SRModel
from traiNNer.utils import DiffJPEG
from traiNNer.utils.misc import set_random_seed
from traiNNer.utils.redux_options import ReduxOptions
from traiNNer.utils.rng import RNG

ROOT = Path(__file__).resolve().parents[2]
BATCH = 4

OPTIONS = {
    "name": "vosr_target_feed",
    "scale": 2,
    "num_gpu": 0,
    "path": {},
    "high_order_degradation": True,
    "queue_size": BATCH,
    "thicklines_prob": 0.0,
    "compress_algorithms": ["jpeg"],
    "compress_algorithm_probs": [1.0],
    "compress_algorithms2": ["jpeg"],
    "compress_algorithm_probs2": [1.0],
    "datasets": {
        "train": {
            "name": "vosr_target_feed",
            "type": "RealESRGANDataset",
            "phase": "train",
            "scale": 2,
            "dataroot_gt": [str(ROOT / "datasets" / "train" / "dataset1" / "hr")],
            "io_backend": {"type": "disk"},
            "gt_size": 64,
        }
    },
    "train": {
        "total_iter": 1,
        "vosr_target": {"engine_dir": "engines", "plugin": "plugin.so"},
    },
}


class _RecordingTeacher:
    """Returns a known function of the LR as an inference tensor, like VosrTeacher.restore."""

    def __init__(self) -> None:
        self.seen: list[Tensor] = []

    def restore(self, lq_rgb: Tensor, scale: int) -> Tensor:
        self.seen.append(lq_rgb.clone())
        with torch.inference_mode():
            return _expected(lq_rgb, scale)


def _expected(lq: Tensor, scale: int) -> Tensor:
    return functional.interpolate(lq, scale_factor=scale, mode="nearest") * 0.5 + 0.25


def _model(opt: ReduxOptions, teacher: _RecordingTeacher) -> RealESRGANModel:
    """The attributes feed_data reads (as in test_otf_rng_stream), on the CPU, with the stand-in teacher."""
    model = object.__new__(RealESRGANModel)
    model.opt = opt
    model.is_train = True
    model.device = torch.device("cpu")
    model.memory_format = torch.preserve_format
    model.lq = None
    model.gt = None
    model.queue_lr = None
    model.queue_gt = None
    model.queue_ptr = 0
    model.queue_size = opt.queue_size
    model.kernel1 = None
    model.kernel2 = None
    model.sinc_kernel = None
    model.jpeger = DiffJPEG(differentiable=False)
    model.thicklines = None
    model.otf_debug = False
    model.otf_debug_limit = 0
    model.vosr_target = cast(VosrTeacher, teacher)  # same restore() interface
    model.batch_augment = None
    return model


def test_feed_data_replaces_gt_with_vosr_restoration(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    opt = msgspec.convert(OPTIONS, ReduxOptions)
    set_random_seed(0)
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(0))
    # On the CPU some OTF ops return channels-last tensors, which filter2d's .view() rejects (CUDA keeps the
    # standard layout); the same filter on a contiguous copy computes the same values.
    filter2d = realesrgan_model.filter2d
    monkeypatch.setattr(
        realesrgan_model,
        "filter2d",
        lambda img, kernel: filter2d(img.contiguous(), kernel),
    )
    dataset = RealESRGANDataset(opt.datasets["train"])
    teacher = _RecordingTeacher()
    model = _model(opt, teacher)
    # Two batches: the second goes through the full training pair pool (queue_size == batch), which swaps
    # in queued pairs; the teacher must restore the LR that leaves the pool.
    for step in range(2):
        batch = default_collate(
            [dataset[(step * BATCH + i) % len(dataset)] for i in range(BATCH)]
        )
        model.feed_data(batch)
        assert model.lq is not None
        assert model.gt is not None
        assert len(teacher.seen) == step + 1
        assert torch.equal(teacher.seen[-1], model.lq)
        assert model.gt.shape == (BATCH, 3, 64, 64)
        assert torch.equal(model.gt, _expected(model.lq, 2))
        assert not model.gt.is_inference()


def _validation_model(**changes: object) -> SRModel:
    opt = SimpleNamespace(
        train=SimpleNamespace(
            vosr_target=SimpleNamespace(engine_dir="e", plugin="p", lanes=2)
        ),
        high_order_degradation=True,
        otf_hf_noise_prob=0.0,
        input_pixel_format="rgb",
        output_pixel_format="rgb",
        datasets={"train": SimpleNamespace(gt_size=384, target_dataroot_gt=None)},
    )
    losses = {"l_g_gan": None}
    for key, value in changes.items():
        if key == "losses":
            losses = cast(dict, value)
        elif key in ("gt_size", "target_dataroot_gt"):
            setattr(opt.datasets["train"], key, value)
        else:
            setattr(opt, key, value)
    model = object.__new__(SRModel)
    # Only the attributes the check reads
    model.opt = cast(ReduxOptions, opt)
    model.losses = cast(dict, losses)
    return model


def test_vosr_target_settings_accepted() -> None:
    _validation_model().validate_vosr_target()


def test_vosr_target_unset_is_not_checked() -> None:
    model = _validation_model(
        train=SimpleNamespace(vosr_target=None), high_order_degradation=False
    )
    model.validate_vosr_target()


@pytest.mark.parametrize(
    ("changes", "match"),
    [
        ({"high_order_degradation": False}, "on-the-fly"),
        ({"losses": {"l_g_gan": None, "l_g_vosr": None}}, "vosrloss"),
        ({"otf_hf_noise_prob": 0.5}, "otf_hf_noise_prob"),
        ({"output_pixel_format": "yuv"}, "rgb"),
        ({"input_pixel_format": "yuv"}, "rgb"),
        ({"gt_size": 576}, "512"),
        ({"target_dataroot_gt": ["targets"]}, "target_dataroot_gt"),
    ],
)
def test_vosr_target_rejects_settings(changes: dict, match: str) -> None:
    with pytest.raises(ValueError, match=match):
        _validation_model(**changes).validate_vosr_target()


def _gan(gan_type: str) -> SimpleNamespace:
    return SimpleNamespace(gan_type=gan_type, loss_weight=0.03)


@pytest.mark.parametrize("gan_type", ["vanilla", "lsgan", "wgan_softplus"])
def test_vosrloss_accepts_positive_gan_losses(gan_type: str) -> None:
    losses = {"l_g_gan": _gan(gan_type), "l_g_vosr": None}
    _validation_model(losses=losses).validate_vosr_loss()


@pytest.mark.parametrize(
    ("losses", "match"),
    [
        ({"l_g_vosr": None}, "add a ganloss"),
        ({"l_g_gan": _gan("hinge"), "l_g_vosr": None}, "hinge"),
        ({"l_g_gan": _gan("wgan"), "l_g_vosr": None}, "wgan"),
    ],
)
def test_vosrloss_rejects_settings(losses: dict, match: str) -> None:
    with pytest.raises(ValueError, match=match):
        _validation_model(losses=losses).validate_vosr_loss()
