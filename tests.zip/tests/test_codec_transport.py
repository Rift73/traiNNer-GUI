"""The codec round trips of CUDA batches give the frames of the CPU code path:
video codecs through pinned staging, WebP through its byte route and through
webp_reconstruct, whose pixels equal the byte route's."""

import numpy as np
import pytest
import torch
from torch import Tensor
from traiNNer.data import webp_reconstruct
from traiNNer.data.compress_video_batch import prepare_video_batch, stage_to_host
from traiNNer.data.otf_degradations import (
    apply_per_image_parallel,
    compress_webp,
    prepare_webp_batch,
)
from traiNNer.utils.rng import RNG

cuda = pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
built = pytest.mark.skipif(
    webp_reconstruct.load_library() is None, reason="libwebp_reconstruct.so not built"
)

# Every chroma sampling each codec supports.
SAMPLING = [
    *((codec, s) for codec in ("h264", "hevc", "vp9") for s in ("444", "422", "420")),
    ("mpeg2", "422"),
    ("mpeg2", "420"),
    ("mpeg4", "420"),
]


def _images(b: int, c: int, h: int, w: int, seed: int = 0) -> Tensor:
    """Smooth images with some noise, a little outside [0, 1] at the edges."""
    generator = torch.Generator().manual_seed(seed)
    ramp = torch.linspace(-0.05, 1.05, w).expand(b, c, h, w)
    noise = torch.rand(b, c, h, w, generator=generator)
    return 0.7 * ramp + 0.3 * noise


def _video(
    monkeypatch: pytest.MonkeyPatch,
    tensor: Tensor,
    codec: str,
    sampling: str,
    lead_in: int | None = None,
) -> Tensor:
    """One round trip; a clip when lead_in is given."""
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(0))
    quality = 6 if codec in ("mpeg2", "mpeg4") else 30
    round_trip, finish = prepare_video_batch(
        tensor,
        codec,
        quality,
        [sampling],
        temporal=lead_in is not None,
        lead_in=lead_in or 0,
    )
    frames = round_trip()
    assert frames.is_pinned() == tensor.is_cuda
    return finish(frames)


def test_stage_to_host_keeps_cpu_frames() -> None:
    frames = torch.zeros(2, 3, 4, 4, dtype=torch.uint8)
    host, ready = stage_to_host(frames)
    assert host is frames
    assert ready is None


@cuda
def test_stage_to_host_pins_cuda_frames() -> None:
    frames = torch.randint(0, 256, (2, 3, 5, 7), dtype=torch.uint8, device="cuda")
    host, ready = stage_to_host(frames.permute(0, 2, 3, 1))
    assert ready is not None
    ready.synchronize()
    assert host.is_pinned()
    assert torch.equal(host, frames.permute(0, 2, 3, 1).cpu())


@cuda
@pytest.mark.parametrize(("codec", "sampling"), SAMPLING)
@pytest.mark.parametrize("size", [(32, 48), (33, 45)])
def test_still_video_batch_matches_cpu_route(
    monkeypatch: pytest.MonkeyPatch, codec: str, sampling: str, size: tuple[int, int]
) -> None:
    images = _images(4, 3, *size)
    expected = _video(monkeypatch, images, codec, sampling).cuda()
    result = _video(monkeypatch, images.cuda(), codec, sampling)
    assert result.is_contiguous()
    assert torch.equal(result, expected)


def _clip() -> Tensor:
    # Odd sides, large enough for x265: it crashes on six-frame clips of about 40 px.
    return _images(6, 3, 65, 67, seed=1)


@cuda
@pytest.mark.parametrize(
    ("codec", "sampling"), [(c, s) for c, s in SAMPLING if c != "h264"]
)
@pytest.mark.parametrize("lead_in", [0, 3])
def test_clip_matches_cpu_route(
    monkeypatch: pytest.MonkeyPatch, codec: str, sampling: str, lead_in: int
) -> None:
    # x264's temporal encode can differ run to run on the same frames (frame
    # threads), so h264 clips are covered by the next test only.
    clip = _clip()
    expected = _video(monkeypatch, clip, codec, sampling, lead_in).cuda()
    result = _video(monkeypatch, clip.cuda(), codec, sampling, lead_in)
    assert result.shape == clip.shape
    assert torch.equal(result, expected)


@cuda
@pytest.mark.parametrize("sampling", ["444", "422", "420"])
@pytest.mark.parametrize("lead_in", [0, 3])
def test_h264_clip_crosses_like_cpu_route(
    monkeypatch: pytest.MonkeyPatch, sampling: str, lead_in: int
) -> None:
    """The encoder gets the frames of the CPU route, and the finish turns
    the decoded frames into the CPU route's result."""
    import torchcodec.encoders

    encoder = torchcodec.encoders.VideoEncoder
    inputs: list[Tensor] = []

    def recording(frames: Tensor, **kwargs: int) -> torchcodec.encoders.VideoEncoder:
        inputs.append(frames.clone())
        return encoder(frames=frames, **kwargs)

    monkeypatch.setattr(torchcodec.encoders, "VideoEncoder", recording)
    steps = []
    for tensor in (_clip(), _clip().cuda()):
        monkeypatch.setattr(RNG, "_rng", np.random.default_rng(0))
        steps.append(
            prepare_video_batch(
                tensor, "h264", 30, [sampling], temporal=True, lead_in=lead_in
            )
        )
    (_, cpu_finish), (cuda_round_trip, cuda_finish) = steps
    frames = cuda_round_trip()
    assert frames.is_pinned()
    expected = cpu_finish(frames.clone()).cuda()
    assert torch.equal(cuda_finish(frames), expected)
    steps[0][0]()
    assert torch.equal(inputs[0], inputs[1])


def _webp_per_image(images: Tensor, quality: int) -> Tensor:
    """The per-image WebP route the batch route replaces."""
    return apply_per_image_parallel(
        torch.clamp(images, 0, 1).cpu(), lambda img: compress_webp(img, quality)
    )


@pytest.mark.parametrize("device", ["cpu", pytest.param("cuda", marks=cuda)])
@pytest.mark.parametrize("channels", [1, 3, 4])
def test_webp_bytes_match_per_image_route(device: str, channels: int) -> None:
    images = _images(3, channels, 37, 50).to(device)
    round_trip, finish = prepare_webp_batch(images, 61, direct=False)
    result = finish(round_trip())
    assert result.device == images.device
    assert result.dtype == images.dtype
    assert torch.equal(result.cpu(), _webp_per_image(images, 61))


@cuda
def test_webp_bytes_keep_half_precision() -> None:
    images = _images(2, 3, 16, 24).cuda().half()
    round_trip, finish = prepare_webp_batch(images, 80, direct=False)
    result = finish(round_trip())
    assert result.dtype == torch.float16
    assert torch.equal(result.cpu(), _webp_per_image(images, 80))


@cuda
@built
def test_webp_reconstruct_support() -> None:
    images = _images(1, 3, 8, 8).cuda()
    assert webp_reconstruct.supports(images, 40)
    assert webp_reconstruct.supports(images, 100)
    assert not webp_reconstruct.supports(images, 39)
    assert not webp_reconstruct.supports(images.cpu(), 70)
    assert not webp_reconstruct.supports(images.half(), 70)
    assert not webp_reconstruct.supports(_images(1, 4, 8, 8).cuda(), 70)
    assert not webp_reconstruct.supports(_images(1, 3, 2049, 1).cuda(), 70)


@cuda
@built
@pytest.mark.parametrize(
    "size", [(1, 1), (2, 3), (17, 33), (64, 64), (189, 195), (96, 1), (385, 383)]
)
@pytest.mark.parametrize("quality", [40, 47, 53, 66, 75, 85, 94, 99, 100])
def test_webp_reconstruct_matches_byte_route(
    size: tuple[int, int], quality: int
) -> None:
    images = _images(3, 3, *size, seed=quality).cuda()
    expected = prepare_webp_batch(images, quality, direct=False)
    round_trip, finish = webp_reconstruct.prepare(images, quality)
    result = finish(round_trip())
    assert result.is_contiguous()
    assert torch.equal(result, expected[1](expected[0]()))


@cuda
@built
def test_webp_reconstruct_reads_channels_last() -> None:
    images = _images(2, 3, 31, 40).cuda()
    expected = webp_reconstruct.prepare(images, 70)
    round_trip, finish = webp_reconstruct.prepare(
        images.to(memory_format=torch.channels_last), 70
    )
    assert torch.equal(finish(round_trip()), expected[1](expected[0]()))
