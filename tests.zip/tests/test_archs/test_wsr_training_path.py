"""WSR training composes linear branches and upsamples gates without changing results."""

import copy
from collections.abc import Iterator

import pytest
import torch
from torch import Tensor, nn
from torch.nn import functional
from traiNNer.archs import wsr_arch
from traiNNer.archs.wsr_arch import ContextGate, Conv3XC, FoldableRGB5, _upsample4
from traiNNer.models.sr_weight_window import WSRWeightWindow

TOLERANCE = {"atol": 1e-10, "rtol": 1e-9}


@pytest.fixture(autouse=True)
def cpu_only() -> Iterator[None]:
    previous = torch.get_num_threads()
    torch.set_num_threads(2)
    try:
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(291029)
            yield
    finally:
        torch.set_num_threads(previous)
    assert not torch.cuda.is_initialized()


def perturb(module: nn.Module, scale: float = 0.1) -> None:
    with torch.no_grad():
        for parameter in module.parameters():
            if parameter.requires_grad:
                parameter.add_(torch.randn_like(parameter) * scale)


def assert_same_gradients(left: nn.Module, right: nn.Module) -> None:
    for (name, a), (other, b) in zip(
        left.named_parameters(), right.named_parameters(), strict=True
    ):
        assert name == other
        if a.grad is None:
            assert b.grad is None, name
            continue
        assert b.grad is not None, name
        torch.testing.assert_close(a.grad, b.grad, **TOLERANCE, msg=name)


def explicit_conv3xc(module: Conv3XC, x: Tensor) -> Tensor:
    first, spatial, last = module.conv
    return last(spatial(first(functional.pad(x, (1, 1, 1, 1))))) + module.sk(x)


@pytest.mark.parametrize("channels_last", [False, True])
@pytest.mark.parametrize(("cin", "cout", "stride"), [(8, 16, 1), (6, 8, 2)])
def test_conv3xc_training_matches_explicit_branches(
    cin: int, cout: int, stride: int, channels_last: bool
) -> None:
    composed = Conv3XC(cin, cout, gain1=2, s=stride).double().train()
    perturb(composed)
    explicit = copy.deepcopy(composed)
    layout = torch.channels_last if channels_last else torch.contiguous_format
    x = torch.randn(2, cin, 11, 9, dtype=torch.float64).contiguous(memory_format=layout)
    x_composed = x.clone().requires_grad_(True)
    x_explicit = x.clone().requires_grad_(True)
    y_composed = composed(x_composed)
    y_explicit = explicit_conv3xc(explicit, x_explicit)
    torch.testing.assert_close(y_composed, y_explicit, **TOLERANCE)
    cotangent = torch.randn_like(y_explicit)
    y_composed.backward(cotangent)
    y_explicit.backward(cotangent)
    torch.testing.assert_close(x_composed.grad, x_explicit.grad, **TOLERANCE)
    assert_same_gradients(composed, explicit)


def test_foldable_rgb5_training_matches_two_valid_operators() -> None:
    composed = FoldableRGB5(12, middle=8).double().train()
    perturb(composed)
    explicit = copy.deepcopy(composed)
    x = torch.randn(2, 3, 13, 7, dtype=torch.float64)
    x_composed = x.clone().requires_grad_(True)
    x_explicit = x.clone().requires_grad_(True)
    y_composed = composed(x_composed)
    # ValidConv3XC.forward always evaluates its explicit branches.
    y_explicit = explicit.second(
        explicit.first(functional.pad(x_explicit, (2, 2, 2, 2)))
    )
    torch.testing.assert_close(y_composed, y_explicit, **TOLERANCE)
    cotangent = torch.randn_like(y_explicit)
    y_composed.backward(cotangent)
    y_explicit.backward(cotangent)
    torch.testing.assert_close(x_composed.grad, x_explicit.grad, **TOLERANCE)
    assert_same_gradients(composed, explicit)


@pytest.mark.parametrize(
    "shape", [(2, 3, 1, 5), (2, 3, 6, 1), (1, 1, 1, 1), (1, 2, 7, 9), (2, 4, 16, 16)]
)
def test_upsample4_matches_bilinear_interpolation(shape: tuple[int, ...]) -> None:
    x = torch.randn(shape, dtype=torch.float64)
    x_separable = x.clone().requires_grad_(True)
    x_native = x.clone().requires_grad_(True)
    y_separable = _upsample4(_upsample4(x_separable, -2), -1)
    y_native = functional.interpolate(
        x_native, scale_factor=4.0, mode="bilinear", align_corners=False
    )
    assert y_separable.shape == y_native.shape
    torch.testing.assert_close(y_separable, y_native, atol=1e-12, rtol=1e-12)
    cotangent = torch.randn_like(y_native)
    y_separable.backward(cotangent)
    y_native.backward(cotangent)
    torch.testing.assert_close(x_separable.grad, x_native.grad, atol=1e-12, rtol=1e-12)


def test_context_gate_training_matches_eval_with_crop() -> None:
    trained = ContextGate(8, 16).double()
    perturb(trained, scale=0.5)
    evaluated = copy.deepcopy(trained)
    x = torch.randn(2, 8, 21, 18, dtype=torch.float64)
    context = torch.randn(2, 16, 6, 5, dtype=torch.float64)
    x_trained = x.clone().requires_grad_(True)
    x_evaluated = x.clone().requires_grad_(True)
    context_trained = context.clone().requires_grad_(True)
    context_evaluated = context.clone().requires_grad_(True)
    y_trained = trained.train()(x_trained, context_trained)
    y_evaluated = evaluated.eval()(x_evaluated, context_evaluated)
    torch.testing.assert_close(y_trained, y_evaluated, **TOLERANCE)
    cotangent = torch.randn_like(y_evaluated)
    y_trained.backward(cotangent)
    y_evaluated.backward(cotangent)
    torch.testing.assert_close(x_trained.grad, x_evaluated.grad, **TOLERANCE)
    torch.testing.assert_close(
        context_trained.grad, context_evaluated.grad, **TOLERANCE
    )
    assert_same_gradients(trained, evaluated)


@pytest.mark.parametrize("name", ["wsr_compact", "wsr_ultracompact"])
def test_training_forward_matches_eval(name: str) -> None:
    model = getattr(wsr_arch, name)(scale=2).double()
    perturb(model, scale=0.02)
    x = torch.rand(1, 3, 23, 19, dtype=torch.float64)
    trained = model.train()(x)
    with torch.no_grad():
        evaluated = model.eval()(x)
    assert trained.shape == (1, 3, 46, 38)
    torch.testing.assert_close(trained.detach(), evaluated, **TOLERANCE)


def test_bf16_autocast_training_step_is_finite() -> None:
    model = wsr_arch.wsr_compact(scale=2).train()
    perturb(model, scale=0.02)
    x = torch.rand(1, 3, 20, 20)
    with torch.autocast("cpu", dtype=torch.bfloat16):
        output = model(x)
    assert torch.isfinite(output.float()).all()
    output.float().square().mean().backward()
    gradients = [p.grad for p in model.parameters() if p.grad is not None]
    assert gradients
    assert all(torch.isfinite(grad).all() for grad in gradients)


def test_wsr_accumulation_matches_branch_updates_across_windows() -> None:
    reference = nn.Sequential(FoldableRGB5(4, middle=5), nn.SiLU(), Conv3XC(4, 3)).double()
    folded = copy.deepcopy(reference)
    window = WSRWeightWindow(folded)
    assert window.can_fold()
    optimizers = [torch.optim.SGD(model.parameters(), lr=0.02) for model in (reference, folded)]
    for _ in range(2):
        for optimizer in optimizers:
            optimizer.zero_grad()
        for _ in range(3):
            x = torch.randn(1, 3, 7, 11, dtype=torch.float64)
            window.begin()
            target, prediction = reference(x), folded(x)
            torch.testing.assert_close(prediction, target, **TOLERANCE)
            target.square().mean().backward()
            prediction.square().mean().backward()
        window.backward()
        for a, b in zip(reference.parameters(), folded.parameters(), strict=True):
            torch.testing.assert_close(a.grad, b.grad, **TOLERANCE)
        for optimizer in optimizers:
            optimizer.step()
