"""RealESRGANModel._apply_compression routes eligible video and WebP calls to
the GPU approximations of codec_approx: the routing draw, the project RNG
stream, the result and the number of yielded jobs per call."""

from collections.abc import Callable
from operator import methodcaller
from typing import Any

import msgspec
import numpy as np
import pytest
import torch
from torch import Tensor
from traiNNer.models import realesrgan_model
from traiNNer.models.realesrgan_model import RealESRGANModel
from traiNNer.utils.redux_options import ReduxOptions
from traiNNer.utils.rng import RNG

pytestmark = pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")

OPTIONS = {
    "name": "codec_approx",
    "scale": 2,
    "num_gpu": 0,
    "path": {},
    "high_order_degradation": True,
    "compress_algorithms": ["h264"],
    "compress_algorithm_probs": [1.0],
    "compress_video_sampling": ["444", "422", "420"],
    "datasets": {
        "train": {
            "name": "codec_approx",
            "type": "RealESRGANDataset",
            "phase": "train",
            "scale": 2,
            "dataroot_gt": ["unused"],
            "gt_size": 32,
        }
    },
    "train": {"total_iter": 1},
}


class _LoggedRNG:
    """The project generator, logging the name of every method called on it."""

    def __init__(self, seed: int, log: list[str]) -> None:
        self._rng = np.random.default_rng(seed)
        self._log = log

    def __getattr__(self, name: str) -> Any:
        method = getattr(self._rng, name)

        def logged(*args: Any, **kwargs: Any) -> Any:
            self._log.append(name)
            return method(*args, **kwargs)

        return logged


@pytest.fixture(autouse=True)
def _codec_route_rng(monkeypatch: pytest.MonkeyPatch) -> None:
    # A known routing generator for every test, as RNG.get_codec_route_rng
    # would make it from seed 7.
    monkeypatch.setattr(RNG, "_codec_route_rng", None)
    monkeypatch.setattr(RNG, "_seed", 7)


def _model(clip_mode: bool = False, **changes: Any) -> RealESRGANModel:
    model = object.__new__(RealESRGANModel)
    model.opt = msgspec.convert({**OPTIONS, **changes}, ReduxOptions)
    model.clip_mode = clip_mode
    return model


def _image(batch: int = 4, size: int = 32, seed: int = 0) -> Tensor:
    generator = torch.Generator().manual_seed(seed)
    coarse = torch.rand(batch, 3, 4, 4, generator=generator)
    return torch.nn.functional.interpolate(coarse, size=(size, size), mode="bilinear")


def _run(
    model: RealESRGANModel,
    out: Tensor,
    monkeypatch: pytest.MonkeyPatch,
    seed: int = 3,
) -> tuple[Tensor, int, list[str]]:
    """Drive one compression call with its jobs run inline: the result, the
    number of yielded jobs and the project RNG methods called."""
    log: list[str] = []
    monkeypatch.setattr(RNG, "_rng", _LoggedRNG(seed, log))
    chain = methodcaller("_apply_compression", out)(model)
    jobs = 0
    try:
        job = next(chain)
        while True:
            jobs += 1
            job = chain.send(job())
    except StopIteration as stop:
        return stop.value, jobs, log


def _spy(
    monkeypatch: pytest.MonkeyPatch, name: str
) -> list[tuple[tuple[Any, ...], dict[str, Any]]]:
    """Record the calls of a function realesrgan_model imported."""
    calls: list[tuple[tuple[Any, ...], dict[str, Any]]] = []
    function: Callable[..., Any] = getattr(realesrgan_model, name)

    def recorded(*args: Any, **kwargs: Any) -> Any:
        calls.append((args, kwargs))
        return function(*args, **kwargs)

    monkeypatch.setattr(realesrgan_model, name, recorded)
    return calls


def test_probability_zero_is_the_genuine_path(monkeypatch: pytest.MonkeyPatch) -> None:
    approximate = _spy(monkeypatch, "approximate_video")
    genuine = _spy(monkeypatch, "prepare_video_batch")
    model = _model(compress_video_approx_prob=0.0)
    result, jobs, log = _run(model, _image().cuda(), monkeypatch)
    # The same call on a CPU tensor is ineligible and takes the genuine path
    # with the stock draws.
    cpu_result, cpu_jobs, cpu_log = _run(
        _model(compress_video_approx_prob=0.5), _image(), monkeypatch
    )
    assert not approximate
    assert len(genuine) == 2
    assert jobs == cpu_jobs == 1
    assert log == cpu_log
    assert "uniform" not in log
    assert torch.equal(result.cpu(), cpu_result)


def test_probability_one_approximates_without_a_routing_draw(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _, _, genuine_log = _run(
        _model(compress_video_approx_prob=0.0), _image().cuda(), monkeypatch
    )
    approximate = _spy(monkeypatch, "approximate_video")
    genuine = _spy(monkeypatch, "prepare_video_batch")
    source = _image().cuda()
    result, jobs, log = _run(
        _model(compress_video_approx_prob=1.0), source, monkeypatch
    )
    assert len(approximate) == 1
    assert not genuine
    assert jobs == 1
    assert log == genuine_log
    assert result.shape == source.shape
    assert result.is_cuda


def test_routing_takes_no_project_rng_draw(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The project RNG's stream is the same at probability 0, 0.5 and 1; the
    routing decisions come from RNG.get_codec_route_rng."""
    approximate = _spy(monkeypatch, "approximate_video")
    genuine = _spy(monkeypatch, "prepare_video_batch")
    calls = 16
    logs = {}
    for prob in (0.0, 0.5, 1.0):
        model = _model(compress_video_approx_prob=prob)
        logs[prob] = []
        for seed in range(calls):
            _, jobs, log = _run(model, _image().cuda(), monkeypatch, seed)
            assert jobs == 1
            logs[prob].append(log)
    assert logs[0.0] == logs[0.5] == logs[1.0]
    assert all("uniform" not in log for log in logs[0.5])
    # 16 genuine calls at 0, 16 approximated at 1, a mix at 0.5.
    assert len(approximate) + len(genuine) == 3 * calls
    assert calls < len(approximate) < 2 * calls


def _routes(seed: int, monkeypatch: pytest.MonkeyPatch) -> list[bool]:
    """Which of 12 eligible calls a fresh routing generator from `seed` sends
    to the approximation."""
    monkeypatch.setattr(RNG, "_codec_route_rng", None)
    monkeypatch.setattr(RNG, "_seed", seed)
    approximate = _spy(monkeypatch, "approximate_video")
    model = _model(compress_video_approx_prob=0.5)
    routes = []
    for call in range(12):
        before = len(approximate)
        _run(model, _image().cuda(), monkeypatch, call)
        routes.append(len(approximate) > before)
    return routes


def test_same_seed_gives_the_same_routing(monkeypatch: pytest.MonkeyPatch) -> None:
    first = _routes(21, monkeypatch)
    assert first == _routes(21, monkeypatch)
    assert first != _routes(22, monkeypatch)
    assert any(first)
    assert not all(first)


def test_no_routing_draw_outside_zero_and_one(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    route = RNG.get_codec_route_rng()
    for prob in (0.0, 1.0):
        model = _model(compress_video_approx_prob=prob)
        state = route.bit_generator.state
        _run(model, _image().cuda(), monkeypatch)
        _run(model, _image(), monkeypatch)
        assert route.bit_generator.state == state
    model = _model(compress_video_approx_prob=0.5)
    state = route.bit_generator.state
    _run(model, _image(), monkeypatch)  # ineligible: no draw
    assert route.bit_generator.state == state
    _run(model, _image().cuda(), monkeypatch)
    assert route.bit_generator.state != state


def test_route_generator_follows_the_project_seed(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Same seed, same routing stream; independent of the project stream; no
    reseeding once either generator exists."""
    monkeypatch.setattr(RNG, "_rng", None)
    RNG.init_rng(5)
    first = RNG.get_codec_route_rng().random(4)
    assert not np.array_equal(first, np.random.default_rng(5).random(4))
    monkeypatch.setattr(RNG, "_rng", None)
    monkeypatch.setattr(RNG, "_codec_route_rng", None)
    RNG.init_rng(5)
    assert np.array_equal(RNG.get_codec_route_rng().random(4), first)
    with pytest.raises(RuntimeError, match="reseeded"):
        RNG.init_rng(6)
    monkeypatch.setattr(RNG, "_rng", None)
    with pytest.raises(RuntimeError, match="reseeded"):
        RNG.init_rng(6)


def test_clip_mode_passes_time_and_lead_in(monkeypatch: pytest.MonkeyPatch) -> None:
    clip = _image(batch=6).cuda()
    _, _, genuine_log = _run(
        _model(clip_mode=True, compress_video_approx_prob=0.0), clip, monkeypatch
    )
    approximate = _spy(monkeypatch, "approximate_video")
    result, jobs, log = _run(
        _model(clip_mode=True, compress_video_approx_prob=1.0), clip, monkeypatch
    )
    assert jobs == 1
    assert log == genuine_log
    ((args, _),) = approximate
    temporal, lead_in = args[4], args[5]
    assert temporal is True
    assert 0 <= lead_in <= 5
    assert result.shape == clip.shape


@pytest.mark.parametrize("clip_mode", [False, True])
@pytest.mark.parametrize("enabled", [False, True])
def test_webp_switch(
    monkeypatch: pytest.MonkeyPatch, enabled: bool, clip_mode: bool
) -> None:
    approximate = _spy(monkeypatch, "approximate_webp")
    genuine = _spy(monkeypatch, "prepare_webp_batch")
    changes = {
        "compress_algorithms": ["webp"],
        "compress_webp_approx": enabled,
        "compress_video_approx_prob": 1.0,
    }
    source = _image().cuda()
    result, jobs, log = _run(_model(clip_mode, **changes), source, monkeypatch)
    _, _, stock_log = _run(
        _model(clip_mode, **{**changes, "compress_webp_approx": False}),
        source,
        monkeypatch,
    )
    assert jobs == 1
    assert log == stock_log
    assert (len(approximate), len(genuine)) == ((1, 1) if enabled else (0, 2))
    assert result.shape == source.shape


def test_ineligible_webp_takes_the_genuine_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    approximate = _spy(monkeypatch, "approximate_webp")
    genuine = _spy(monkeypatch, "prepare_webp_batch")
    model = _model(compress_algorithms=["webp"], compress_webp_approx=True)
    _, jobs, _ = _run(model, _image(), monkeypatch)
    assert jobs == 1
    assert not approximate
    assert len(genuine) == 1
