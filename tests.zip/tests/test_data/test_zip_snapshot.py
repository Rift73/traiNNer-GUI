from pathlib import Path
from zipfile import BadZipFile, ZipFile

import pytest
from trainner_data.zip_images import ZipImageReader


def test_index_refuses_replaced_archive(tmp_path: Path) -> None:
    archive = tmp_path / "images.zip"
    replacement = tmp_path / "next.zip"
    for path, body in ((archive, b"snapshot one"), (replacement, b"snapshot two")):
        with ZipFile(path, "w") as out:
            out.writestr("sample.png", body)

    reader = ZipImageReader([str(archive)])
    replacement.replace(archive)
    with pytest.raises(ValueError, match="changed since"):
        reader.read(0)
    assert ZipImageReader([str(archive)]).read(0) == b"snapshot two"


def test_indexed_member_keeps_crc_check(tmp_path: Path) -> None:
    archive = tmp_path / "images.zip"
    with ZipFile(archive, "w") as out:
        out.writestr("sample.png", b"original payload")
    archive.write_bytes(
        archive.read_bytes().replace(b"original payload", b"modified payload")
    )
    reader = ZipImageReader([str(archive)])
    with pytest.raises(BadZipFile):
        reader.read(0)
