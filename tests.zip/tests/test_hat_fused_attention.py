"""HAT window attention and OCAB on the fused relative-bias attention kernel."""

import copy
import functools

import pytest
import torch
from einops import rearrange
from traiNNer.archs import hat_arch
from traiNNer.archs.hat_arch import HAT, OCAB, WindowAttention, hat_s
from traiNNer.ops import window_attention
from traiNNer.ops.window_attention import (
    mask_to_regions,
    relative_bias_window_attention,
    supports_region_channels,
)

CUDA_FUSED = pytest.mark.skipif(
    not torch.cuda.is_available() or not hat_arch.FUSED_WINDOW_ATTENTION_AVAILABLE,
    reason="CUDA fused attention",
)


def _kernel_index(qh: int, qw: int, kh: int, kw: int) -> torch.Tensor:
    # The fused kernel's table index: key minus query, rows major.
    query = torch.arange(qh * qw)
    key = torch.arange(kh * kw)
    ry = (key // kw)[None, :] - (query // qw)[:, None] + qh - 1
    rx = (key % kw)[None, :] - (query % qw)[:, None] + qw - 1
    return ry * (qw + kw - 1) + rx


def _kernel_emulation(
    query: torch.Tensor,
    key: torch.Tensor,
    value: torch.Tensor,
    table: torch.Tensor,
    qh: int,
    qw: int,
    kh: int,
    kw: int,
    scale: float,
    preserve_layout: bool = False,
) -> torch.Tensor:
    del preserve_layout
    bias = table[_kernel_index(qh, qw, kh, kw).to(table.device)].permute(2, 0, 1)
    attn = (query @ key.transpose(-2, -1)) * scale + bias
    return attn.softmax(-1) @ value


def _hand_written(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    table: torch.Tensor,
    rpi: torch.Tensor,
    scale: float,
    mask: torch.Tensor | None = None,
) -> torch.Tensor:
    # The equations of WindowAttention.forward / OCAB.forward.
    b_, heads, nq, _ = q.shape
    nk = k.shape[2]
    attn = (q * scale) @ k.transpose(-2, -1)
    attn = attn + table[rpi.view(-1)].view(nq, nk, -1).permute(2, 0, 1)
    if mask is not None:
        nw = mask.shape[0]
        attn = attn.view(b_ // nw, nw, heads, nq, nk) + mask[None, :, None]
        attn = attn.view(-1, heads, nq, nk)
    return attn.softmax(-1) @ v


def _swin_index(h: int, w: int) -> torch.Tensor:
    # Swin convention (query minus key), as HAT.calculate_rpi_sa for h == w.
    coords = torch.stack(
        torch.meshgrid(torch.arange(h), torch.arange(w), indexing="ij")
    ).flatten(1)
    rel = (coords[:, :, None] - coords[:, None, :]).permute(1, 2, 0).contiguous()
    rel[:, :, 0] += h - 1
    rel[:, :, 1] += w - 1
    rel[:, :, 0] *= 2 * w - 1
    return rel.sum(-1)


@functools.cache
def _geometry() -> HAT:
    # A small real HAT (window 16, shift 8, overlap window 24) for its index
    # buffers and shift mask.
    return HAT(
        img_size=64,
        embed_dim=60,
        depths=(1,),
        num_heads=(1,),
        window_size=16,
        overlap_ratio=0.5,
        mlp_ratio=1.0,
    )


def _buffer(name: str) -> torch.Tensor:
    return dict(_geometry().named_buffers())[name]


def _hat_mask(size: int = 64) -> torch.Tensor:
    return _geometry().calculate_mask((size, size), dtype=torch.float64, device="cpu")


def _qkvt(
    windows: int, heads: int, nq: int, nk: int, d: int, rows: int
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    g = torch.Generator().manual_seed(7)

    def rnd(*shape: int) -> torch.Tensor:
        return torch.randn(*shape, generator=g, dtype=torch.float64)

    return (
        rnd(windows, heads, nq, d),
        rnd(windows, heads, nk, d),
        rnd(windows, heads, nk, d),
        rnd(rows, heads) * 0.5,
    )


@pytest.mark.parametrize("h,w", [(16, 16), (8, 16), (16, 8)])
def test_table_reorder_matches_swin_index(
    monkeypatch: pytest.MonkeyPatch, h: int, w: int
) -> None:
    monkeypatch.setattr(window_attention, "ocab_attention", _kernel_emulation)
    rpi = _buffer("relative_position_index_SA") if h == w == 16 else _swin_index(h, w)
    q, k, v, table = _qkvt(4, 3, h * w, h * w, 24, (2 * h - 1) * (2 * w - 1))
    actual = relative_bias_window_attention(q, k, v, table, h, w, 0.2)
    expected = _hand_written(q, k, v, table, rpi, 0.2)
    torch.testing.assert_close(actual, expected, rtol=1e-12, atol=1e-12)


def test_overlap_table_shift_matches_hat_index() -> None:
    ws, wse = 16, 24
    rpi = _buffer("relative_position_index_OCA")
    assert int(rpi.min()) < 0  # HAT's index wraps; the shift must account for it
    rows = (ws + wse - 1) ** 2
    shift = hat_arch.overlap_table_shift(ws, wse)
    assert shift == 880
    q, k, v, table = _qkvt(4, 3, ws * ws, wse * wse, 24, rows)
    actual = _kernel_emulation(q, k, v, table.roll(shift, 0), ws, ws, wse, wse, 0.2)
    expected = _hand_written(q, k, v, table, rpi, 0.2)
    torch.testing.assert_close(actual, expected, rtol=1e-12, atol=1e-12)


@pytest.mark.parametrize("head_dim", [24, 30])
def test_region_channels_reproduce_hat_shift_mask(
    monkeypatch: pytest.MonkeyPatch, head_dim: int
) -> None:
    monkeypatch.setattr(window_attention, "ocab_attention", _kernel_emulation)
    mask = _hat_mask(64)
    regions = mask_to_regions(mask)
    assert regions.shape == (16, 256)
    assert int(regions.max()) == 3
    rpi = _buffer("relative_position_index_SA")
    scale = head_dim**-0.5
    # Two images of 16 windows: the regions repeat per image.
    q, k, v, table = _qkvt(32, 2, 256, 256, head_dim, 31 * 31)
    actual = relative_bias_window_attention(
        q, k, v, table, 16, 16, scale, regions=regions
    )
    expected = _hand_written(q, k, v, table, rpi, scale, mask=mask)
    torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)


def test_region_channel_capacity() -> None:
    assert supports_region_channels(24)
    assert supports_region_channels(30)
    assert not supports_region_channels(31)
    assert not supports_region_channels(32)
    q = torch.zeros(16, 1, 256, 32, dtype=torch.float64)
    with pytest.raises(ValueError, match="region channels"):
        relative_bias_window_attention(
            q,
            q,
            q,
            torch.zeros(31 * 31, 1, dtype=torch.float64),
            16,
            16,
            0.2,
            regions=torch.zeros(16, 256, dtype=torch.long),
        )


def test_mask_to_regions_rejects_other_masks() -> None:
    allowed = torch.tensor([[1, 1, 0], [1, 1, 1], [0, 1, 1]], dtype=torch.bool)
    not_transitive = torch.where(allowed, 0.0, -100.0)[None]
    with pytest.raises(ValueError, match="same-region"):
        mask_to_regions(not_transitive)
    with pytest.raises(ValueError, match="0 or -100"):
        mask_to_regions(torch.full((1, 3, 3), -50.0))
    five_regions = torch.where(torch.eye(5, dtype=torch.bool), 0.0, -100.0)[None]
    with pytest.raises(ValueError, match="at most 4"):
        mask_to_regions(five_regions)


def _unfold_windows(kv: torch.Tensor, window: int, overlap: int) -> torch.Tensor:
    # OCAB's reference extraction: nn.Unfold and the rearrange in OCAB.forward.
    unfold = torch.nn.Unfold(
        kernel_size=(overlap, overlap), stride=window, padding=(overlap - window) // 2
    )
    return rearrange(
        unfold(kv),
        "b (nc ch owh oww) nw -> nc (b nw) (owh oww) ch",
        nc=2,
        ch=kv.shape[1] // 2,
        owh=overlap,
        oww=overlap,
    ).contiguous()


@pytest.mark.parametrize(
    "window,overlap,cell", [(16, 24, 8), (16, 32, 16), (8, 12, 4), (16, 16, 16)]
)
def test_overlap_cell(window: int, overlap: int, cell: int) -> None:
    assert hat_arch.overlap_cell(window, overlap) == cell


@pytest.mark.parametrize("window,overlap", [(16, 25), (16, 20), (7, 10)])
def test_overlap_cell_falls_back_to_unfold(window: int, overlap: int) -> None:
    assert hat_arch.overlap_cell(window, overlap) is None


@pytest.mark.parametrize(
    "dim,h,w,window,overlap",
    [
        (144, 64, 64, 16, 24),
        (180, 64, 64, 16, 24),
        (144, 48, 80, 16, 24),
        (180, 48, 80, 16, 24),
        (8, 32, 48, 16, 32),
        (8, 24, 16, 8, 12),
    ],
)
def test_overlap_windows_equal_unfold(
    dim: int, h: int, w: int, window: int, overlap: int
) -> None:
    g = torch.Generator().manual_seed(21)
    kv = torch.randn(2, 2 * dim, h, w, generator=g, requires_grad=True)
    cell = hat_arch.overlap_cell(window, overlap)
    actual = hat_arch.overlap_windows(kv, window, overlap, cell)
    expected = _unfold_windows(kv, window, overlap)
    assert actual.shape == expected.shape
    assert torch.equal(actual, expected)
    cotangent = torch.randn(expected.shape, generator=g)
    (grad_actual,) = torch.autograd.grad(actual, kv, cotangent)
    (grad_expected,) = torch.autograd.grad(expected, kv, cotangent)
    # Up to four overlapping windows per pixel: equal up to summation order.
    torch.testing.assert_close(grad_actual, grad_expected, rtol=1e-6, atol=1e-6)


def _fused_modules(model: torch.nn.Module) -> list[torch.nn.Module]:
    return [m for m in model.modules() if isinstance(m, (WindowAttention, OCAB))]


def test_cpu_default_never_reaches_fused_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def refuse(*args: object, **kwargs: object) -> None:
        raise AssertionError("fused attention reached")

    monkeypatch.setattr(hat_arch, "relative_bias_window_attention", refuse)
    monkeypatch.setattr(hat_arch, "ocab_attention", refuse)
    torch.manual_seed(0)
    model = hat_s().train()
    model.prepare_for_compile(input_shape=(1, 3, 32, 32), input_dtype=torch.bfloat16)
    assert not any(m.use_fused_attention_training for m in _fused_modules(model))
    assert "attn_regions" not in dict(model.named_buffers())
    assert not any("attn_regions" in key for key in model.state_dict())
    out = model(torch.rand(1, 3, 32, 32))
    assert out.shape == (1, 3, 128, 128)
    assert torch.isfinite(out).all()


# ----------------------------------------------------------------------------- CUDA


def _rel(a: torch.Tensor, ref: torch.Tensor) -> float:
    return float((a.float() - ref.float()).norm() / ref.float().norm().clamp_min(1e-12))


def _outputs_and_grads(
    module: torch.nn.Module, x: torch.Tensor, args: tuple, autocast: bool
) -> list[torch.Tensor]:
    module.zero_grad(set_to_none=True)
    x = x.detach().clone().requires_grad_()
    with torch.autocast("cuda", dtype=torch.bfloat16, enabled=autocast):
        out = module(x, *args)
    generator = torch.Generator(device="cuda").manual_seed(3)
    weight = torch.randn(out.shape, generator=generator, device="cuda")
    (out.float() * weight).sum().backward()
    assert x.grad is not None
    return [out.detach().float(), x.grad.float()] + [
        p.grad.float() for p in module.parameters() if p.grad is not None
    ]


def _check_against_fp32(
    hand: torch.nn.Module, fused: torch.nn.Module, x: torch.Tensor, args: tuple
) -> None:
    reference = _outputs_and_grads(hand, x, args, autocast=False)
    hand_bf16 = _outputs_and_grads(hand, x, args, autocast=True)
    fused_bf16 = _outputs_and_grads(fused, x, args, autocast=True)
    assert len(reference) == len(hand_bf16) == len(fused_bf16)
    for ref, h, f in zip(reference, hand_bf16, fused_bf16, strict=True):
        assert torch.isfinite(f).all()
        # The fused path keeps scores in fp32 (the hand-written path rounds them
        # to bf16) but rounds the bias and the dense bias gradient to bf16; it
        # must be about as close to fp32 as the hand-written bf16 path.
        assert _rel(f, ref) <= max(1.5 * _rel(h, ref), 2e-3)


def _window_attention_pair(
    heads: int = 6, dim: int = 144
) -> tuple[WindowAttention, WindowAttention, torch.Tensor]:
    torch.manual_seed(11)
    hand = WindowAttention(dim, (16, 16), heads).cuda().train()
    with torch.no_grad():
        hand.relative_position_bias_table.normal_(0.0, 0.5)
    fused = copy.deepcopy(hand)
    fused.use_fused_attention_training = True
    rpi = _buffer("relative_position_index_SA").cuda()
    return hand, fused, rpi


# Head width 24 (embed 144) and 30 (embed 180): with the two region channels
# the latter fills the kernel's 32-wide channel block exactly.
DIMS = pytest.mark.parametrize("dim", [144, 180])


@CUDA_FUSED
@DIMS
def test_cuda_window_attention_unshifted_matches_reference(dim: int) -> None:
    hand, fused, rpi = _window_attention_pair(dim=dim)
    x = torch.randn(32, 256, dim, device="cuda")
    _check_against_fp32(hand, fused, x, (rpi, None, None))


@CUDA_FUSED
@DIMS
def test_cuda_window_attention_shifted_matches_reference(dim: int) -> None:
    hand, fused, rpi = _window_attention_pair(dim=dim)
    mask = _hat_mask(64).float().cuda()
    regions = mask_to_regions(mask).cuda()
    x = torch.randn(32, 256, dim, device="cuda")
    _check_against_fp32(hand, fused, x, (rpi, mask, regions))


@CUDA_FUSED
@DIMS
def test_cuda_ocab_matches_reference(dim: int) -> None:
    torch.manual_seed(12)
    hand = OCAB(dim, (64, 64), 16, 0.5, 6).cuda().train()
    with torch.no_grad():
        hand.relative_position_bias_table.normal_(0.0, 0.5)
    fused = copy.deepcopy(hand)
    fused.use_fused_attention_training = True
    rpi = _buffer("relative_position_index_OCA")
    x = torch.randn(2, 64 * 64, dim, device="cuda")
    _check_against_fp32(hand, fused, x, ((64, 64), rpi.cuda()))


@CUDA_FUSED
def test_cuda_ocab_fused_backward_deterministic_mode(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    torch.manual_seed(15)
    fused = OCAB(144, (64, 64), 16, 0.5, 6).cuda().train()
    fused.use_fused_attention_training = True
    rpi = _buffer("relative_position_index_OCA")
    x = torch.randn(2, 64 * 64, 144, device="cuda")
    torch.use_deterministic_algorithms(True)
    try:
        first = _outputs_and_grads(fused, x, ((64, 64), rpi.cuda()), autocast=True)
        second = _outputs_and_grads(fused, x, ((64, 64), rpi.cuda()), autocast=True)
    finally:
        torch.use_deterministic_algorithms(False)
    for a, b in zip(first, second, strict=True):
        assert torch.equal(a, b)


@CUDA_FUSED
def test_cuda_eval_keeps_reference_path() -> None:
    hand, fused, rpi = _window_attention_pair()
    hand.eval()
    fused.eval()
    x = torch.randn(32, 256, 144, device="cuda")
    with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
        assert torch.equal(hand(x, rpi), fused(x, rpi))


@CUDA_FUSED
def test_cuda_fused_backward_is_deterministic() -> None:
    _, fused, rpi = _window_attention_pair()
    mask = _hat_mask(64).float().cuda()
    regions = mask_to_regions(mask).cuda()
    x = torch.randn(32, 256, 144, device="cuda")
    first = _outputs_and_grads(fused, x, (rpi, mask, regions), autocast=True)
    second = _outputs_and_grads(fused, x, (rpi, mask, regions), autocast=True)
    for a, b in zip(first, second, strict=True):
        assert torch.equal(a, b)


@CUDA_FUSED
def test_cuda_hat_s_fused_training_step_matches_reference() -> None:
    torch.manual_seed(13)
    hand = hat_s().cuda().train()
    fused = copy.deepcopy(hand)
    fused.prepare_for_compile(input_shape=(2, 3, 64, 64), input_dtype=torch.bfloat16)
    assert all(m.use_fused_attention_training for m in _fused_modules(fused))
    assert len(_fused_modules(fused)) == 42
    assert fused.attn_regions_size == (64, 64)
    assert "attn_regions" in dict(fused.named_buffers())
    assert fused.state_dict().keys() == hand.state_dict().keys()

    image = torch.rand(2, 3, 64, 64, device="cuda")
    target = torch.rand(2, 3, 256, 256, device="cuda")
    results = []
    for model in (hand, fused):
        torch.manual_seed(14)  # same stochastic-depth draws for both paths
        with torch.autocast("cuda", dtype=torch.bfloat16):
            loss = (model(image).float() - target).abs().mean()
        loss.backward()
        parameters = dict(model.named_parameters())
        names = [
            "conv_first.weight",
            "conv_last.weight",
            "layers.0.residual_group.blocks.1.attn.relative_position_bias_table",
            "layers.5.residual_group.overlap_attn.relative_position_bias_table",
            "layers.5.residual_group.blocks.4.attn.qkv.weight",
        ]
        norms = []
        for n in names:
            grad = parameters[n].grad
            assert grad is not None
            norms.append(grad.norm())
        results.append((loss.detach(), norms))
    (hand_loss, hand_norms), (fused_loss, fused_norms) = results
    assert abs(float(fused_loss - hand_loss)) <= 1e-2 * abs(float(hand_loss))
    for a, b in zip(fused_norms, hand_norms, strict=True):
        assert abs(float(a - b)) <= 5e-2 * float(b)
