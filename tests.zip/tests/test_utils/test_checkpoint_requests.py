from logging import getLogger
from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING, cast
from unittest.mock import Mock
from uuid import uuid4

import pytest
import torch
from studio.run_process import read_record, write_record
from traiNNer.training.checkpoints import CheckpointRequests, save_periodic_checkpoint

if TYPE_CHECKING:
    from traiNNer.models.base_model import BaseModel


@pytest.mark.parametrize("refresh_weights", [True, False])
def test_request_during_regular_save_requires_fresh_numbered_set(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, refresh_weights: bool
) -> None:
    monkeypatch.setenv("TRAINNER_STUDIO_CONTROL", str(tmp_path))
    logger = getLogger(__name__)
    request_path = tmp_path / "checkpoint-request.json"
    result_path = tmp_path / "checkpoint-result.json"
    request = {"id": uuid4().hex}
    weights = tmp_path / "net_ae_10.pth"
    state = tmp_path / "10.state"
    torch.save({"weight": torch.zeros(1, device="cpu")}, weights)

    def write_checkpoint(epoch: int, iteration: int) -> None:
        # Model saving is already in progress when Studio posts the request.
        write_record(request_path, request)
        assert read_record(result_path) is None
        torch.save({"epoch": epoch, "iter": iteration}, state)
        if refresh_weights:
            torch.save({"weight": torch.ones(2, device="cpu")}, weights)

    save = Mock(side_effect=write_checkpoint)
    model = cast(
        "BaseModel",
        SimpleNamespace(
            opt=SimpleNamespace(
                path=SimpleNamespace(
                    models=str(tmp_path),
                    training_states=str(tmp_path),
                    resume_models=str(tmp_path),
                ),
                logger=SimpleNamespace(
                    save_checkpoint_freq=10, save_checkpoint_format="pth"
                ),
            ),
            net_ae=object(),
            net_ae_ema=None,
            net_d=None,
            save=save,
        ),
    )
    assert CheckpointRequests.from_environment(model, 1, logger) is None
    assert not (tmp_path / "checkpoint-ready").exists()
    requests = CheckpointRequests.from_environment(model, 0, logger)
    assert requests is not None
    assert (tmp_path / "checkpoint-ready").is_file()

    assert (
        save_periodic_checkpoint(
            model,
            0,
            10,
            logger=logger,
            layout=None,
            recovery=None,
            retention=None,
            requests=requests,
        )
        is refresh_weights
    )
    save.assert_called_once_with(0, 10)
    result = read_record(result_path)
    assert result and result["id"] == request["id"]
    if refresh_weights:
        assert result == {**request, "status": "saved", "iteration": 10}
    else:
        assert result["status"] == "failed"
        assert result["error"]
        assert "iteration" not in result
    assert read_record(request_path) == request
    assert not requests.poll(force=True)

    restarted = CheckpointRequests.from_environment(model, 0, logger)
    assert restarted is not None and not restarted.poll(force=True)
