"""DVD pairs through RealESRGANDataset, collate_dvd and RealESRGANModel.feed_data.

Every delivered pair is checked against an independent reference: GT is found
in a brute-force flipped and rotated copy of the source (or target) image, its
canonical position read from a coordinate-coded image, and LQ must equal the
same crop of the response of the whole canonical source, oriented the same way.
"""

import itertools
import random
from collections.abc import Callable, Iterator
from pathlib import Path
from typing import Any
from unittest.mock import Mock

import msgspec
import numpy as np
import pytest
import pyvips
import torch
from torch import Tensor
from torch.utils.data import DataLoader, default_collate
from traiNNer.data import build_dataloader
from traiNNer.data.dvd_response import DvdSample, collate_dvd, dvd_pair, dvd_response
from traiNNer.data.realesrgan_dataset import RealESRGANDataset
from traiNNer.data.transforms import paired_random_crop
from traiNNer.models import realesrgan_model
from traiNNer.models.rdual_model import clip_training_problems
from traiNNer.models.realesrgan_model import RealESRGANModel, ThickLines
from traiNNer.utils import DiffJPEG
from traiNNer.utils.redux_options import DatasetOptions, ReduxOptions
from traiNNer.utils.rng import RNG

GT_SIZE = 64
PATCH = GT_SIZE // 2
D4 = list(itertools.product([False, True], repeat=3))

OPTIONS = {
    "name": "dvd_feed",
    "scale": 2,
    "num_gpu": 0,
    "path": {},
    "high_order_degradation": True,
    "queue_size": 12,
    "compress_prob": 0.0,
    "compress_prob2": 0.0,
    "datasets": {
        "train": {
            "name": "dvd_feed",
            "type": "RealESRGANDataset",
            "phase": "train",
            "scale": 2,
            "dataroot_gt": ["unused"],
            "gt_size": GT_SIZE,
        }
    },
    "train": {"total_iter": 1},
}


@pytest.fixture(autouse=True)
def _project_rng(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(0))


@pytest.fixture(autouse=True)
def _contiguous_filter2d(monkeypatch: pytest.MonkeyPatch) -> None:
    # Some CPU ops return channels-last tensors, which filter2d's .view()
    # rejects; the same filter on a contiguous copy gives the same values.
    filter2d: Callable[[Tensor, Tensor], Tensor] = realesrgan_model.filter2d
    monkeypatch.setattr(
        realesrgan_model, "filter2d", lambda img, k: filter2d(img.contiguous(), k)
    )


def _model(dvd_prob: float, **changes: Any) -> RealESRGANModel:
    """The attributes feed_data reads, as RealESRGANModel.__init__ sets them."""
    opt = msgspec.convert({**OPTIONS, "dvd_prob": dvd_prob, **changes}, ReduxOptions)
    model = object.__new__(RealESRGANModel)
    model.opt = opt
    model.is_train = True
    model.device = torch.device("cpu")
    model.memory_format = torch.preserve_format
    model.lq = None
    model.gt = None
    model.queue_lr = None
    model.queue_gt = None
    model.queue_ptr = 0
    model.queue_size = opt.queue_size
    model.kernel1 = None
    model.kernel2 = None
    model.sinc_kernel = None
    model.jpeger = DiffJPEG(differentiable=False)
    model.thicklines = ThickLines()
    model.otf_debug = False
    model.otf_debug_limit = 0
    model.vosr_target = None
    model.batch_augment = None
    model.dvd_fallback_warned = False
    return model


def _write(root: Path, name: str, width: int, height: int, seed: int) -> np.ndarray:
    root.mkdir(exist_ok=True)
    pixels = np.random.default_rng(seed).integers(0, 256, (height, width, 3), np.uint8)
    pyvips.Image.new_from_array(pixels).pngsave(str(root / name))
    return pixels.astype(np.float32) / 255


def _dataset(
    root: Path, dvd_prob: float, target: Path | None = None, **changes: Any
) -> RealESRGANDataset:
    return RealESRGANDataset(
        DatasetOptions(
            name="dvd_feed",
            type="realesrgandataset",
            dataroot_gt=[str(root)],
            target_dataroot_gt=[str(target)] if target else None,
            gt_size=GT_SIZE,
            use_hflip=True,
            use_rot=True,
            dvd_prob=dvd_prob,
            **changes,
        )
    )


def _brute_orient(image: np.ndarray, flags: tuple[bool, bool, bool]) -> np.ndarray:
    hflip, vflip, clockwise = flags
    if hflip:
        image = image[:, ::-1]
    if vflip:
        image = image[::-1]
    if clockwise:
        image = np.rot90(image, k=-1)
    return np.ascontiguousarray(image)


def _find(haystack: np.ndarray, patch: np.ndarray) -> tuple[int, int]:
    """The unique (top, left) of patch in haystack (HWC)."""
    size = patch.shape[0]
    rows, cols = np.nonzero((haystack == patch[0, 0]).all(-1))
    found = [
        (int(t), int(l))
        for t, l in zip(rows, cols, strict=True)
        if t + size <= haystack.shape[0]
        and l + size <= haystack.shape[1]
        and np.array_equal(haystack[t : t + size, l : l + size], patch)
    ]
    assert len(found) == 1
    return found[0]


def _canonical_origin(
    height: int,
    width: int,
    flags: tuple[bool, bool, bool],
    top: int,
    left: int,
    size: int,
) -> tuple[int, int]:
    coded = _brute_orient(np.arange(height * width).reshape(height, width), flags)
    square = coded[top : top + size, left : left + size]
    return int((square % width).min()), int((square // width).min())


def _response(source: np.ndarray) -> np.ndarray:
    """The response of the whole canonical source, its odd last row/column trimmed."""
    height, width = source.shape[0] // 2 * 2, source.shape[1] // 2 * 2
    image = torch.from_numpy(source[:height, :width]).permute(2, 0, 1)[None]
    return dvd_response(image.contiguous())[0].permute(1, 2, 0).numpy()


def _force_flags(
    monkeypatch: pytest.MonkeyPatch, flags: list[tuple[bool, bool, bool]]
) -> None:
    """Make the dataset draw the given flips and rotation, one triple per sample."""
    values: Iterator[float] = iter(
        [0.0 if flag else 0.9 for triple in flags for flag in triple]
    )
    monkeypatch.setattr(random, "random", lambda: next(values))


def _check_pair(
    lq: np.ndarray,
    gt: np.ndarray,
    source: np.ndarray,
    supervision: np.ndarray,
    flags: tuple[bool, bool, bool],
) -> tuple[tuple[int, int], float]:
    """The canonical GT origin of a delivered pair and its LQ's difference to
    the reference; GT must be an exact crop of the oriented supervision image."""
    top, left = _find(_brute_orient(supervision, flags), gt)
    x, y = _canonical_origin(*source.shape[:2], flags, top, left, GT_SIZE)
    assert x % 2 == 0 and y % 2 == 0
    reference = _brute_orient(
        _response(source)[y // 2 : y // 2 + PATCH, x // 2 : x // 2 + PATCH], flags
    )
    return (x, y), float(np.abs(lq - reference).max())


SIZES = [(200, 170), (GT_SIZE, GT_SIZE), (101, 97), (150, 260)]


@pytest.mark.parametrize("flags", D4)
@pytest.mark.parametrize("with_target", [False, True])
def test_pairs_match_the_canonical_response(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    flags: tuple[bool, bool, bool],
    with_target: bool,
) -> None:
    sources = [
        _write(tmp_path / "source", f"{i}.png", w, h, i)
        for i, (w, h) in enumerate(SIZES)
    ]
    targets = (
        [
            _write(tmp_path / "target", f"{i}.png", w, h, 100 + i)
            for i, (w, h) in enumerate(SIZES)
        ]
        if with_target
        else sources
    )
    _force_flags(monkeypatch, [flags] * len(SIZES))
    # Odd canvas offsets: the DVD crop must still land on the even grid.
    monkeypatch.setattr(
        random, "randint", lambda low, high: high if high % 2 else max(low, high - 1)
    )
    dataset = _dataset(
        tmp_path / "source", 1.0, tmp_path / "target" if with_target else None
    )
    samples = [dataset[i] for i in range(len(SIZES))]
    # Only the whole-frame 64-square source is resident.
    assert [s["dvd"].source is None for s in samples] == [False, True, False, False]
    assert all(
        (s["dvd"].target is None) == (not with_target or s["dvd"].source is None)
        for s in samples
    )
    batch = collate_dvd(samples)
    model = _model(1.0)
    model.feed_data(batch)
    assert model.lq is not None and model.gt is not None
    assert model.lq.shape == (len(SIZES), 3, PATCH, PATCH)
    worst = 0.0
    for i in range(len(SIZES)):
        _, difference = _check_pair(
            model.lq[i].permute(1, 2, 0).numpy(),
            model.gt[i].permute(1, 2, 0).numpy(),
            sources[i],
            targets[i],
            flags,
        )
        worst = max(worst, difference)
    print(f"LQ vs canonical response, flags {flags}, target {with_target}: {worst:.3g}")
    assert worst < 1e-5


def test_crop_draws_top_then_left_and_lands_on_the_even_grid(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sizes = [(300, 280), (260, 330)]
    sources = [
        _write(tmp_path / "source", f"{i}.png", w, h, i)
        for i, (w, h) in enumerate(sizes)
    ]
    flags = [(False, False, False), (True, False, True)]
    _force_flags(monkeypatch, flags)
    offsets = iter([37, 51, 64, 13])
    monkeypatch.setattr(random, "randint", lambda low, high: next(offsets))
    dataset = _dataset(tmp_path / "source", 1.0)
    batch = collate_dvd([dataset[0], dataset[1]])
    assert not batch["otf_padded_height"].any() and not batch["otf_padded_width"].any()
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(31))
    expected = np.random.default_rng(31)
    expected.uniform()  # the DVD draw
    limit = (GT_SIZE + 32 - GT_SIZE) // 2
    top = int(expected.integers(0, limit, endpoint=True))
    left = int(expected.integers(0, limit, endpoint=True))
    model = _model(1.0)
    model.feed_data(batch)
    assert model.lq is not None and model.gt is not None
    for i, (canvas_top, canvas_left) in enumerate([(37, 51), (64, 13)]):
        origin, difference = _check_pair(
            model.lq[i].permute(1, 2, 0).numpy(),
            model.gt[i].permute(1, 2, 0).numpy(),
            sources[i],
            sources[i],
            flags[i],
        )
        assert difference < 1e-5
        # The requested patch, canvas origin plus twice the LQ offsets, floored
        # onto the even canonical grid.
        requested = _canonical_origin(
            *sources[i].shape[:2],
            flags[i],
            canvas_top + 2 * top,
            canvas_left + 2 * left,
            GT_SIZE,
        )
        assert origin == (requested[0] // 2 * 2, requested[1] // 2 * 2)


@pytest.mark.parametrize("device", ["cpu", "cuda"])
@pytest.mark.parametrize("flags", D4)
def test_resident_and_general_paths_agree(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    device: str,
    flags: tuple[bool, bool, bool],
) -> None:
    if device == "cuda" and not torch.cuda.is_available():
        pytest.skip("needs CUDA")
    source = _write(tmp_path / "source", "0.png", GT_SIZE, GT_SIZE, 3)
    target = _write(tmp_path / "target", "0.png", GT_SIZE, GT_SIZE, 4)
    _force_flags(monkeypatch, [flags])
    sample = _dataset(tmp_path / "source", 1.0, tmp_path / "target")[0]
    resident: DvdSample = sample["dvd"]
    assert resident.source is None and resident.geometry.resident(GT_SIZE)
    general = DvdSample(
        resident.geometry,
        torch.from_numpy(source).permute(2, 0, 1).contiguous(),
        torch.from_numpy(target).permute(2, 0, 1).contiguous(),
    )
    canvas = sample["gt"][None].to(device)
    target_canvas = sample["target_gt"][None].to(device)
    pairs = [
        dvd_pair(
            [dvd],
            canvas,
            target_canvas,
            GT_SIZE,
            1.0,
            center_height=True,
            center_width=True,
        )
        for dvd in (resident, general)
    ]
    assert torch.equal(pairs[0][0], pairs[1][0])
    assert torch.equal(pairs[0][1], pairs[1][1])
    assert torch.equal(pairs[0][1][0], target_canvas[0, :, 16:80, 16:80])


@pytest.mark.parametrize("with_target", [False, True])
@pytest.mark.parametrize("layout", [torch.contiguous_format, torch.channels_last])
def test_gt_has_the_strides_of_the_ordinary_crop(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    layout: torch.memory_format,
    with_target: bool,
) -> None:
    """Compiled losses guard on strides: a DVD batch's GT must look like the
    ordinary chain's crop of the same delivered canvas."""
    _write(tmp_path / "source", "0.png", GT_SIZE, GT_SIZE, 3)
    _write(tmp_path / "target", "0.png", GT_SIZE, GT_SIZE, 4)
    _force_flags(monkeypatch, [(False, False, False)])
    sample = _dataset(
        tmp_path / "source", 1.0, tmp_path / "target" if with_target else None
    )[0]
    canvas = sample["gt"][None].contiguous(memory_format=layout)
    target = (
        sample["target_gt"][None].contiguous(memory_format=layout)
        if with_target
        else None
    )
    supervision = canvas if target is None else target
    _, gt = dvd_pair(
        [sample["dvd"]],
        canvas,
        target,
        GT_SIZE,
        1.0,
        center_height=True,
        center_width=True,
    )
    lq = canvas.new_zeros(1, 3, canvas.shape[-2] // 2, canvas.shape[-1] // 2)
    crop, _ = paired_random_crop(
        supervision, lq, GT_SIZE, 2, center_height=True, center_width=True
    )
    assert isinstance(crop, Tensor)
    assert gt.stride() == crop.stride()
    assert gt.dtype == crop.dtype
    for memory_format in (torch.contiguous_format, torch.channels_last):
        assert gt.is_contiguous(memory_format=memory_format) == crop.is_contiguous(
            memory_format=memory_format
        )
    assert torch.equal(gt, crop)


def test_too_small_sample_warns_once_and_takes_the_ordinary_chain(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _write(tmp_path / "source", "0_small.png", 50, 50, 0)
    _write(tmp_path / "source", "1_large.png", 200, 170, 1)
    dataset = _dataset(tmp_path / "source", 1.0)
    logger = Mock()
    monkeypatch.setattr(realesrgan_model, "get_root_logger", lambda: logger)
    monkeypatch.setattr(realesrgan_model, "dvd_pair", Mock(side_effect=AssertionError))
    model = _model(1.0)
    for _ in range(2):
        model.lq = None
        model.feed_data(collate_dvd([dataset[0], dataset[1]]))
        assert model.lq is not None
        assert model.lq.shape == (2, 3, PATCH, PATCH)
    assert logger.warning.call_count == 1
    message = logger.warning.call_args.args[0] % logger.warning.call_args.args[1:]
    assert "0_small.png" in message and "50x50" in message


def test_unarmed_dataset_and_loader_are_unchanged(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    for i, (w, h) in enumerate(SIZES):
        _write(tmp_path / "source", f"{i}.png", w, h, i)
    outputs = {}
    for dvd_prob in (0.0, 1.0):
        random.seed(5)
        monkeypatch.setattr(RNG, "_rng", np.random.default_rng(5))
        dataset = _dataset(tmp_path / "source", dvd_prob)
        samples = [dataset[i] for i in range(len(SIZES))]
        outputs[dvd_prob] = (
            samples,
            random.getstate(),
            RNG.get_rng().bit_generator.state,
        )
    plain, armed = outputs[0.0], outputs[1.0]
    assert all("dvd" not in sample for sample in plain[0])
    assert all("dvd" in sample for sample in armed[0])
    # The same draws, the same canvases.
    assert plain[1] == armed[1] and plain[2] == armed[2]
    for a, b in zip(plain[0], armed[0], strict=True):
        assert torch.equal(a["gt"], b["gt"])

    dataset_opt = DatasetOptions(
        name="dvd_feed",
        type="realesrgandataset",
        phase="train",
        batch_size_per_gpu=2,
        num_worker_per_gpu=0,
        prefetch_factor=None,
        persistent_workers=False,
        dataroot_gt=[str(tmp_path / "source")],
    )
    assert (
        build_dataloader(dataset, dataset_opt, num_gpu=0).collate_fn is default_collate
    )
    dataset_opt.dvd_prob = 1.0
    assert build_dataloader(dataset, dataset_opt, num_gpu=0).collate_fn is collate_dvd
    # Collation keeps the DVD geometry aligned with the sample paths.
    batch = collate_dvd(armed[0])
    assert batch["gt_path"] == [sample["gt_path"] for sample in armed[0]]
    assert [d.geometry.width for d in batch["dvd"]] == [w for w, _ in SIZES]


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
def test_cuda_prefetcher_leaves_dvd_entries_on_the_host(tmp_path: Path) -> None:
    from traiNNer.data.prefetch_dataloader import CUDAPrefetcher

    for i, (w, h) in enumerate(SIZES):
        _write(tmp_path / "source", f"{i}.png", w, h, i)
    dataset = _dataset(tmp_path / "source", 1.0)
    loader = DataLoader(dataset, batch_size=4, collate_fn=collate_dvd)
    opt = msgspec.convert({**OPTIONS, "num_gpu": 1}, ReduxOptions)
    batch = CUDAPrefetcher(loader, opt).next()
    assert batch["gt"].is_cuda
    assert isinstance(batch["dvd"], list) and len(batch["dvd"]) == 4
    assert all(d.source is None or d.source.device.type == "cpu" for d in batch["dvd"])


def test_clip_training_rejects_dvd() -> None:
    def problems(dvd_prob: float) -> list[str]:
        opt = msgspec.convert({**OPTIONS, "dvd_prob": dvd_prob}, ReduxOptions)
        return [p for p in clip_training_problems(opt) if "dvd_prob" in p]

    assert problems(0.0) == []
    assert len(problems(0.5)) == 1
