import numpy as np
import pytest
import torch

from traiNNer.metrics import calculate_metric


@pytest.mark.parametrize(
    "device",
    [
        "cpu",
        pytest.param(
            "cuda",
            marks=pytest.mark.skipif(
                not torch.cuda.is_available(), reason="needs CUDA"
            ),
        ),
    ],
)
@pytest.mark.parametrize(
    ("name", "perfect", "shifted"),
    [
        ("butteraugli", 0.0, 10.1234521866),
        ("ssimulacra2", 100.0, -40.75827407),
    ],
)
def test_perceptual_validation_score(name, perfect, shifted, device):
    # libjxl CLI scores on these cropped RGB bytes. Butteraugli uses 80 nits.
    rgb = np.random.default_rng(873).integers(0, 256, (64, 65, 3), dtype=np.uint8)
    options = {"type": f"calculate_{name}", "crop_border": 2}

    def score(restored):
        return calculate_metric(
            {"img": restored, "img2": rgb}, options, torch.device(device)
        )

    assert score(rgb) == perfect
    assert score(np.roll(rgb, 1, axis=1)) == pytest.approx(shifted, abs=0.003)
