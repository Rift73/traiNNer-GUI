"""CPU coverage for ZIP and loose OTF dataset selection."""

from pathlib import Path
from typing import Any
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile

import msgspec
import pytest
import yaml
from PIL import Image
from studio import preflight as studio_preflight
from studio.recipes import RecipeLibrary
from traiNNer.data import build_dataset
from traiNNer.utils.options import parse_options
from trainner_config.options import DatasetOptions

ROOT = Path(__file__).resolve().parents[2]


def _recipe(archive: Path) -> dict[str, Any]:
    return {
        "name": "zip-preflight",
        "scale": 2,
        "num_gpu": 0,
        "path": {},
        "network_g": {"type": "compact"},
        "high_order_degradation": True,
        "train": {"total_iter": 1},
        "logger": {"print_freq": 1, "save_checkpoint_freq": 10, "use_tb_logger": False},
        "datasets": {
            "train": {
                "name": "train",
                "type": "RealESRGANDataset_traiNNer",
                "io_backend": {"type": "zip"},
                "dataroot_gt": str(archive),
                "gt_size": 32,
                "batch_size_per_gpu": 1,
                "num_worker_per_gpu": 0,
            },
        },
    }


def test_zip_matches_loose_selection(tmp_path: Path) -> None:
    loose_root = tmp_path / "loose"
    archive = tmp_path / "images.ZIP"
    hidden = ".hidden/selected file.png"
    jpeg = "a/image.jfif"
    # Archive order differs from discovery order. The loose disk loader uses
    # neither a suffix allowlist nor a special rule for __MACOSX.
    with ZipFile(archive, "w") as source:
        source.mkdir("empty")
        for name in (hidden, "a0", jpeg, "a/.hidden.png", "__MACOSX/extra.PNG"):
            path = loose_root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            Image.new("RGB", (8, 8)).save(
                path, format="JPEG" if name == jpeg else "PNG"
            )
            source.write(path, name, ZIP_DEFLATED if name == jpeg else ZIP_STORED)

    loose_options = DatasetOptions(
        name="loose",
        type="RealESRGANDataset",
        gt_size=32,
        scale=2,
        dataroot_gt=[str(loose_root)],
    )
    text = yaml.safe_dump(_recipe(archive))
    checked = studio_preflight.preflight(text, RecipeLibrary(ROOT, tmp_path))
    assert checked["ok"], checked["issues"]
    recipe_file = tmp_path / "recipe.yml"
    recipe_file.write_text(
        studio_preflight.launch_text(text, checked["config"], ROOT), encoding="utf-8"
    )
    options, _ = parse_options(str(ROOT), argv=["-opt", str(recipe_file)])
    zip_options = options.datasets["train"]
    loose = build_dataset(loose_options)
    zipped = build_dataset(zip_options)
    assert zipped.paths == [
        Path(p).relative_to(loose_root).as_posix() for p in loose.paths
    ]

    manifest = tmp_path / "meta_info.txt"
    manifest.write_text(
        f"{hidden}\n\n./a//image.jfif (8,8,3)\n{hidden}\na/.hidden.png\n",
        encoding="utf-8",
    )
    loose_options.meta_info = zip_options.meta_info = str(manifest)
    loose = build_dataset(loose_options)
    zipped = build_dataset(zip_options)
    assert zipped.paths == [
        Path(p).relative_to(loose_root).as_posix() for p in loose.paths
    ]
    assert zipped.paths == [hidden, jpeg, hidden, "a/.hidden.png"]


@pytest.mark.parametrize(
    ("field", "value", "error_path"),
    (
        ("target_dataroot_gt", ["unused"], "target_dataroot_gt"),
        ("io_backend", {"type": "zip", "compression": "store"}, "io_backend"),
        ("type", "SingleImageDataset", "io_backend.type"),
        ("dataroot_gt", [], "dataroot_gt"),
    ),
)
def test_zip_recipe_options_match_cli(
    tmp_path: Path, field: str, value: Any, error_path: str
) -> None:
    recipe = _recipe(tmp_path / "unused.zip")
    recipe["datasets"]["train"][field] = value
    text = yaml.safe_dump(recipe)
    result = studio_preflight.preflight(text, RecipeLibrary(ROOT, tmp_path))
    label = f"datasets.train.{error_path}"
    assert not result["ok"]
    assert any(
        issue["level"] == "error" and issue["path"] == label
        for issue in result["issues"]
    )

    recipe_file = tmp_path / "recipe.yml"
    recipe_file.write_text(text, encoding="utf-8")
    with pytest.raises(ValueError):
        parse_options(str(ROOT), argv=["-opt", str(recipe_file)])


def test_zip_preflight_rechecks_only_when_inputs_change(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    archive = tmp_path / "images.zip"
    manifest = tmp_path / "selection.txt"
    manifest.write_text("selected.png\n", encoding="utf-8")
    with ZipFile(archive, "w") as source:
        source.writestr("selected.png", b"fixture")

    recipe = _recipe(archive)
    recipe["datasets"]["train"]["meta_info"] = str(manifest)
    text = yaml.safe_dump(recipe)
    library = RecipeLibrary(ROOT, tmp_path)
    scans = []
    validate = studio_preflight.validate_zip_archive

    def track_scan(path: str, names: list[str] | None = None) -> None:
        scans.append(path)
        validate(path, names)

    monkeypatch.setattr(studio_preflight, "validate_zip_archive", track_scan)
    assert studio_preflight.preflight(text, library)["ok"]
    assert studio_preflight.preflight(text, library)["ok"]
    assert scans == [str(archive)]

    manifest.write_text("missing.png\n", encoding="utf-8")
    check = studio_preflight.preflight(text, library)
    assert not check["ok"]
    assert any(
        issue["path"] == "datasets.train.dataroot_gt" for issue in check["issues"]
    )
    assert len(scans) == 2

    replacement = tmp_path / "replacement.zip"
    with ZipFile(replacement, "w") as source:
        source.writestr("missing.png", b"fixture")
    content = bytearray(replacement.read_bytes())
    method_offset = content.index(b"PK\x01\x02") + 10
    content[method_offset : method_offset + 2] = b"\xff\xff"
    replacement.write_bytes(content)
    replacement.replace(archive)

    check = studio_preflight.preflight(text, library)
    assert not check["ok"]
    assert any(
        issue["path"] == "datasets.train.dataroot_gt" for issue in check["issues"]
    )
    assert len(scans) == 3

    dataset = msgspec.convert(recipe["datasets"]["train"], type=DatasetOptions)
    with pytest.raises(ValueError):
        build_dataset(dataset)
