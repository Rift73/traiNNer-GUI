"""Exercise the production prefetch handoff without importing Torch or using CUDA."""

from __future__ import annotations
import __future__

import ast
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest


class FakeTensor:
    def __init__(self, name: str, is_cuda: bool, events: list[Any]) -> None:
        self.name = name
        self.is_cuda = is_cuda
        self.events = events
        self.recorded_streams: list[Any] = []

    def record_stream(self, stream: Any) -> None:
        assert self.is_cuda, "Host metadata must not be recorded on a CUDA stream"
        self.recorded_streams.append(stream)
        self.events.append(("record", self.name, stream))


def _prefetcher(batch: Any, events: list[Any]) -> tuple[Any, Any, Any]:
    source = (
        Path(__file__).resolve().parents[2] / "traiNNer/data/prefetch_dataloader.py"
    )
    tree = ast.parse(source.read_text())
    production_class = next(
        node
        for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "CUDAPrefetcher"
    )
    consumer = SimpleNamespace(
        wait_stream=lambda stream: events.append(("wait", stream))
    )
    cuda = SimpleNamespace(current_stream=lambda: consumer)
    namespace: dict[str, Any] = {
        "torch": SimpleNamespace(
            cuda=cuda, is_tensor=lambda value: isinstance(value, FakeTensor)
        )
    }
    # Execute the real class, omitting unrelated module imports/initialization.
    exec(
        compile(
            ast.Module(body=[production_class], type_ignores=[]),
            str(source),
            "exec",
            flags=__future__.annotations.compiler_flag,
        ),
        namespace,
    )
    cls = namespace["CUDAPrefetcher"]
    instance = cls.__new__(cls)
    instance.batch = batch
    instance.stream = object()
    instance.preload = lambda: events.append(("preload",))
    return instance, consumer, cuda


def test_handoff_records_cuda_tensors_before_prefetch_without_copying_batch() -> None:
    events: list[Any] = []
    image = FakeTensor("gt", True, events)
    kernel = FakeTensor("kernel1", True, events)
    host_flag = FakeTensor("otf_padded_height", False, events)
    batch = {
        "gt": image,
        "kernel1": kernel,
        "otf_padded_height": host_flag,
        "gt_path": ["synthetic.png"],
    }
    prefetcher, consumer, _ = _prefetcher(batch, events)
    next_image = FakeTensor("next_gt", True, events)

    def preload() -> None:
        events.append(("preload",))
        prefetcher.batch = {"gt": next_image}

    prefetcher.preload = preload
    assert prefetcher.next() is batch
    assert image.recorded_streams == [consumer]
    assert kernel.recorded_streams == [consumer]
    assert host_flag.recorded_streams == []
    assert next_image.recorded_streams == []
    assert events == [
        ("wait", prefetcher.stream),
        ("record", "gt", consumer),
        ("record", "kernel1", consumer),
        ("preload",),
    ]


@pytest.mark.parametrize("batch", [None, {}, {"gt_path": ["synthetic.png"]}])
def test_empty_or_metadata_batch_does_not_record_streams(batch: Any) -> None:
    events: list[Any] = []
    prefetcher, _, _ = _prefetcher(batch, events)
    assert prefetcher.next() is batch
    assert events == [("wait", prefetcher.stream), ("preload",)]


def test_each_handoff_uses_its_actual_consumer_stream() -> None:
    events: list[Any] = []
    first = FakeTensor("first", True, events)
    second = FakeTensor("second", True, events)
    prefetcher, consumer, cuda = _prefetcher({"gt": first}, events)
    prefetcher.next()
    next_consumer = SimpleNamespace(wait_stream=lambda _: None)
    cuda.current_stream = lambda: next_consumer
    prefetcher.batch = {"gt": second}
    prefetcher.next()
    assert first.recorded_streams == [consumer]
    assert second.recorded_streams == [next_consumer]
