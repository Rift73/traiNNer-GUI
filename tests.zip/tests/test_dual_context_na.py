"""CPU-only NA math, training gradients and legacy-checkpoint contracts."""

import copy
import os
from collections.abc import Iterator

import pytest
import torch
from torch import Tensor
from traiNNer.archs.dual_arch import DUAL, DualContextLayer, _SpatialAttention


@pytest.fixture(scope="module", autouse=True)
def cpu_only() -> Iterator[None]:
    assert os.environ.get("CUDA_VISIBLE_DEVICES") == ""
    assert not torch.cuda.is_initialized()
    torch.set_num_threads(1)
    yield
    assert not torch.cuda.is_initialized()


def reference(attention: _SpatialAttention, x: Tensor) -> Tensor:
    """Dense all-image logits with direct relative bias, not tiled RFB factors."""
    batch, channels, height, width = x.shape
    heads, dim = attention.heads, channels // attention.heads
    tokens = x.flatten(2).transpose(1, 2)
    qkv = attention.qkv(tokens).reshape(batch, height * width, 3, heads, dim)
    q, k, v = qkv.permute(2, 0, 3, 1, 4).unbind(0)
    yy, xx = torch.meshgrid(torch.arange(height), torch.arange(width), indexing="ij")
    coords = torch.stack((yy.flatten(), xx.flatten()), -1)
    relative = (coords[:, None] - coords[None]).to(x.dtype)
    phase = relative @ attention.factored_bias.frequency.T
    bias = (
        phase.cos()[None] * attention.factored_bias.amplitude_cos[:, None, None]
        + phase.sin()[None] * attention.factored_bias.amplitude_sin[:, None, None]
    ).sum(-1)
    kh, kw = min(height, attention.window), min(width, attention.window)
    sy = (coords[:, 0] - kh // 2).clamp(0, height - kh)
    sx = (coords[:, 1] - kw // 2).clamp(0, width - kw)
    mask = (
        (coords[None, :, 0] >= sy[:, None])
        & (coords[None, :, 0] < sy[:, None] + kh)
        & (coords[None, :, 1] >= sx[:, None])
        & (coords[None, :, 1] < sx[:, None] + kw)
    )
    assert torch.equal(mask.sum(-1), torch.full((height * width,), kh * kw))
    logits = (q * dim**-0.5) @ k.transpose(-2, -1) + bias
    out = logits.masked_fill(~mask, -torch.inf).softmax(-1) @ v
    return (
        out.transpose(1, 2).reshape(batch, height, width, channels).permute(0, 3, 1, 2)
    )


@pytest.mark.parametrize(
    "shape,window",
    [
        ((1, 1), 8),
        ((3, 19), 8),
        ((17, 5), 8),
        ((8, 8), 8),
        ((9, 13), 8),
        ((16, 16), 8),
        ((17, 19), 8),
        ((33, 35), 32),
        ((65, 3), 64),
        ((19, 17), 5),
    ],
)
def test_exact_per_query_neighborhoods(shape: tuple[int, int], window: int) -> None:
    torch.manual_seed(10)
    model = _SpatialAttention(64, 2, window, context_na=True).double()
    x = torch.randn(2, 64, *shape, dtype=torch.float64)
    with torch.no_grad():
        actual, expected = model.pre_gate_core(x), reference(model, x)
    torch.testing.assert_close(actual, expected, atol=2e-11, rtol=1e-10)


@pytest.mark.parametrize("shape", [(9, 13), (17, 19), (3, 65)])
def test_all_projection_and_rfb_gradients(shape: tuple[int, int]) -> None:
    torch.manual_seed(11)
    model = _SpatialAttention(32, 1, 8, context_na=True).double()
    oracle = copy.deepcopy(model)
    x = torch.randn(2, 32, *shape, dtype=torch.float64, requires_grad=True)
    xr = x.detach().clone().requires_grad_()
    actual, expected = model.pre_gate_core(x), reference(oracle, xr)
    signal = torch.randn_like(actual)
    (actual * signal).sum().backward()
    (expected * signal).sum().backward()
    torch.testing.assert_close(actual, expected, atol=2e-11, rtol=1e-10)
    torch.testing.assert_close(x.grad, xr.grad, atol=2e-11, rtol=1e-10)
    for name, p in model.named_parameters():
        q = oracle.get_parameter(name)
        if name.startswith(("qkv.", "factored_bias.")):
            assert p.grad is not None and p.grad.isfinite().all(), name
            assert p.grad.abs().max() > 0, name
            torch.testing.assert_close(p.grad, q.grad, atol=2e-10, rtol=1e-9)
        else:
            assert p.grad is None and q.grad is None


def test_toggle_preserves_state_rng_and_changes_multiwindow_function() -> None:
    torch.manual_seed(12)
    legacy = _SpatialAttention(32, 1, 8, context_na=False).double()
    rng = torch.get_rng_state()
    torch.manual_seed(12)
    na = _SpatialAttention(32, 1, 8, context_na=True).double()
    assert torch.equal(rng, torch.get_rng_state())
    assert na.load_state_dict(legacy.state_dict(), strict=True).missing_keys == []
    for name, value in na.state_dict().items():
        assert torch.equal(value, legacy.state_dict()[name])
    single = torch.randn(2, 32, 5, 7, dtype=torch.float64)
    torch.testing.assert_close(na(single), legacy(single), atol=0, rtol=0)
    multiple = torch.randn(2, 32, 9, 13, dtype=torch.float64)
    assert not torch.allclose(na(multiple), legacy(multiple), atol=1e-8, rtol=1e-8)


def test_dynamo_fullgraph_forward_backward() -> None:
    model = _SpatialAttention(32, 1, 8, context_na=True)
    compiled = torch.compile(model, backend="eager", fullgraph=True)
    x = torch.randn(2, 32, 17, 19, requires_grad=True)
    actual = compiled(x)
    torch.testing.assert_close(actual, model(x))
    actual.square().mean().backward()
    assert x.grad is not None and x.grad.isfinite().all()


def test_c128_bf16_channels_last_backward() -> None:
    model = _SpatialAttention(128, 4, 8, context_na=True).to(
        memory_format=torch.channels_last
    )
    x = (
        torch.randn(2, 128, 17, 19)
        .to(memory_format=torch.channels_last)
        .requires_grad_()
    )
    with torch.autocast("cpu", dtype=torch.bfloat16):
        actual = model(x)
    assert actual.dtype == torch.bfloat16 and actual.isfinite().all()
    actual.float().square().mean().backward()
    assert x.grad is not None and x.grad.isfinite().all()
    for name, p in model.named_parameters():
        assert p.grad is not None and p.grad.isfinite().all(), name


def test_checkpointing_and_export_keep_na() -> None:
    kw = {
        "scale": 2,
        "embed_dim": 32,
        "depths": (3, 3),
        "layer_indices": ((0, 1, 2), (3, 4, 5)),
        "c_windows": (4, 8),
    }
    model = DUAL(**kw, use_checkpoint=True)
    eager = DUAL(**kw, use_checkpoint=False)
    eager.load_state_dict(model.state_dict(), strict=True)
    x = torch.randn(1, 3, 9, 13, requires_grad=True)
    xr = x.detach().clone().requires_grad_()
    actual, expected = model(x), eager(xr)
    torch.testing.assert_close(actual, expected)
    actual.square().mean().backward()
    expected.square().mean().backward()
    torch.testing.assert_close(x.grad, xr.grad)
    for name, p in model.named_parameters():
        assert p.grad is not None and p.grad.isfinite().all(), name
        torch.testing.assert_close(p.grad, eager.get_parameter(name).grad)
    model.eval().prepare_for_export()
    model.prepare_for_compile(input_dtype=torch.bfloat16)
    assert all(
        m.attention.context_na
        for m in model.modules()
        if isinstance(m, DualContextLayer)
    )
    assert model.context_na is True


@pytest.mark.parametrize("enabled", [False, True])
def test_deprecated_yaml_alias(enabled: bool) -> None:
    with (
        torch.device("meta"),
        pytest.warns(DeprecationWarning, match="aliases context_na"),
    ):
        model = DUAL(context_overlap=enabled)
    assert model.context_na is enabled and model.context_overlap is enabled
    for m in model.modules():
        if isinstance(m, DualContextLayer):
            assert m.attention.context_na is enabled
    with pytest.warns(DeprecationWarning, match="aliases context_na"):
        attention = _SpatialAttention(32, 1, 8, context_overlap=enabled)
    assert attention.context_na is enabled
    attention.context_overlap = not enabled
    assert attention.context_na is not enabled


def test_disabled_option_only_controls_context_layers() -> None:
    with torch.device("meta"):
        model = DUAL(context_na=False)
    assert not model.context_na
    assert all(
        not m.context_na for m in model.modules() if isinstance(m, _SpatialAttention)
    )


@pytest.mark.parametrize("pos_bias", ["rib", "none"])
def test_non_rfb_is_explicit_legacy_only(pos_bias: str) -> None:
    with pytest.raises(ValueError, match="requires RFB"):
        _SpatialAttention(32, 1, 8, pos_bias=pos_bias, context_na=True)
    with torch.device("meta"):
        DUAL(c_pos_bias=pos_bias, context_na=False)
