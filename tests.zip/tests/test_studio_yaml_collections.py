from studio.yaml_edit import read_recipe, render


def test_edit_loss_list_keeps_neighbors_and_scientific_literals():
    recipe = (
        "train:\n"
        "  losses:\n"
        "  - type: l1loss\n"
        "  optim_g: {type: AdamW, lr: !!float 1e-4} # saved optimizer\n"
    )
    losses = [{"type": "l1loss", "loss_weight": 1}, {"type": "vosrloss", "loss_weight": 0.1}]
    edited = render(recipe, [{"path": ["train", "losses"], "value": losses}])
    assert "    - type: vosrloss\n      loss_weight: 0.1" in edited
    assert "optim_g: {type: AdamW, lr: !!float 1e-4} # saved optimizer" in edited
    formatted = render(edited, [], format_all=True)
    assert "optim_g: # saved optimizer\n    type: AdamW\n    lr: !!float 1e-4" in formatted
    assert read_recipe(formatted)["train"] == {
        "losses": losses, "optim_g": {"type": "AdamW", "lr": 0.0001},
    }
