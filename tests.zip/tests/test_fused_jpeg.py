"""fused_jpeg against DiffJPEG(differentiable=False) and its generator use.

The fused kernel computes the colour transforms and the DCT in a different
order from DiffJPEG's tensordots, so a coefficient near a rounding boundary
can quantize to the neighbouring step: the mean error stays far below one
8-bit level, single pixels can differ by a few levels.
"""

import contextlib
from collections.abc import Callable

import pytest
import torch
from torch import Tensor
from traiNNer.utils import DiffJPEG
from traiNNer.utils.fused_jpeg import _HAS_TRITON, fused_jpeg, fused_jpeg_fits
from traiNNer.utils.rng import RNG

needs_triton = pytest.mark.skipif(
    not torch.cuda.is_available() or not _HAS_TRITON, reason="needs CUDA and Triton"
)


def _image(b: int, h: int, w: int, seed: int) -> Tensor:
    """Smooth colour fields with edges and a little noise, in [0, 1], on CUDA."""
    generator = torch.Generator(device="cuda").manual_seed(seed)
    y = torch.linspace(0, 1, h, device="cuda")[:, None]
    x = torch.linspace(0, 1, w, device="cuda")[None, :]
    phase = torch.rand(b, 3, 1, 1, device="cuda", generator=generator) * 6
    smooth = 0.5 + 0.35 * torch.sin(9 * x + phase) * torch.cos(7 * y - phase)
    edges = ((x * 5 + y * 3 + phase).floor() % 2) * 0.2
    noise = torch.rand(b, 3, h, w, device="cuda", generator=generator) * 0.06
    return (smooth + edges + noise).clamp(0, 1)


def _levels(actual: Tensor, expected: Tensor) -> tuple[float, float]:
    """Mean and maximum absolute difference in 8-bit levels."""
    difference = (actual - expected).abs() * 255
    return difference.mean().item(), difference.max().item()


@needs_triton
@pytest.mark.parametrize(
    ("b", "h", "w"), [(8, 64, 64), (4, 37, 53), (2, 16, 16), (3, 1, 70), (2, 130, 200)]
)
def test_close_to_diffjpeg(b: int, h: int, w: int) -> None:
    image = _image(b, h, w, seed=h * w)
    generator = torch.Generator(device="cuda").manual_seed(b)
    quality = torch.empty(b, device="cuda").uniform_(10, 100, generator=generator)
    quality[0] = 50  # the boundary of quality_to_factor's two branches
    assert fused_jpeg_fits(image, quality)
    actual = fused_jpeg(image, quality)
    expected = DiffJPEG(differentiable=False).cuda()(image, quality=quality)
    assert actual.shape == expected.shape
    assert actual.is_contiguous()
    mean, peak = _levels(actual, expected)
    assert mean <= 0.1, mean
    assert peak <= 16, peak


@needs_triton
def test_channels_last_input() -> None:
    image = _image(4, 48, 80, seed=1)
    quality = torch.full((4,), 30.0, device="cuda")
    expected = fused_jpeg(image, quality)
    actual = fused_jpeg(image.to(memory_format=torch.channels_last), quality)
    assert actual.is_contiguous()
    assert torch.equal(actual, expected)


@pytest.mark.parametrize(
    ("device", "dtype", "shape", "quality_shape"),
    [
        ("cpu", torch.float32, (2, 3, 16, 16), (2,)),
        ("cuda", torch.float16, (2, 3, 16, 16), (2,)),
        ("cuda", torch.float32, (2, 4, 16, 16), (2,)),
        ("cuda", torch.float32, (2, 3, 16, 16), (1,)),
        ("cuda", torch.float32, (2, 3, 16, 16), ()),
    ],
)
def test_falls_back(
    device: str,
    dtype: torch.dtype,
    shape: tuple[int, ...],
    quality_shape: tuple[int, ...],
) -> None:
    if not _HAS_TRITON or (device == "cuda" and not torch.cuda.is_available()):
        pytest.skip("needs CUDA and Triton")
    image = torch.rand(shape, device=device).to(dtype)
    quality = torch.full(quality_shape, 50.0, device=device)
    assert not fused_jpeg_fits(image, quality)


def _stage(jpeg: Callable[[Tensor, Tensor], Tensor], image: Tensor) -> Tensor:
    """The OTF JPEG stage: per-image qualities drawn as the trainer draws them."""
    quality = image.new_zeros(image.size(0)).uniform_(20, 95)
    return jpeg(torch.clamp(image, 0, 1), quality)


@needs_triton
def test_keeps_the_generator_states() -> None:
    image = _image(6, 48, 48, seed=2)
    jpeger = DiffJPEG(differentiable=False).cuda()
    with contextlib.suppress(RuntimeError):  # already initialised
        RNG.init_rng(5)
    project = RNG.get_rng().bit_generator.state
    results = []
    for jpeg in (fused_jpeg, lambda x, q: jpeger(x, quality=q)):
        RNG.get_rng().bit_generator.state = project
        torch.manual_seed(3)
        torch.cuda.manual_seed(11)
        out = _stage(jpeg, image)
        states = (
            RNG.get_rng().bit_generator.state,
            torch.get_rng_state(),
            torch.cuda.get_rng_state(),
        )
        results.append((out, states))
    (fused_out, fused_states), (stock_out, stock_states) = results
    assert fused_states[0] == stock_states[0]
    assert torch.equal(fused_states[1], stock_states[1])
    assert torch.equal(fused_states[2], stock_states[2])
    mean, _ = _levels(fused_out, stock_out)
    assert mean <= 0.1, mean
