// Compile as a Windows console executable with the launcher's include path and
// link windows_host.cpp and the launcher's Windows SDK libraries.
#include "updates.cpp"

#include <initializer_list>
#include <iostream>
#include <stdexcept>

namespace {

namespace json = winrt::Windows::Data::Json;

json::JsonObject windows_zip(double id) {
    auto asset = json::JsonObject::Parse(LR"({
        "name": "traiNNer-GUI-Windows-x64.zip",
        "state": "uploaded",
        "size": 4096,
        "digest": "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
    })");
    asset.SetNamedValue(L"id", json::JsonValue::CreateNumberValue(id));
    return asset;
}

json::JsonObject release(const wchar_t* tag, bool prerelease,
                         std::initializer_list<json::JsonObject> assets, bool draft = false) {
    json::JsonArray entries;
    for (const auto& asset : assets) entries.Append(asset);
    json::JsonObject result;
    result.SetNamedValue(L"tag_name", json::JsonValue::CreateStringValue(tag));
    result.SetNamedValue(L"prerelease", json::JsonValue::CreateBooleanValue(prerelease));
    result.SetNamedValue(L"draft", json::JsonValue::CreateBooleanValue(draft));
    result.SetNamedValue(L"assets", entries);
    return result;
}

json::JsonArray page(std::initializer_list<json::JsonObject> releases) {
    json::JsonArray result;
    for (const auto& item : releases) result.Append(item);
    return result;
}

void check(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

void check_discovery() {
    const auto preview_baseline = updates::parse_version("v0.1.0-preview.3").value();
    const auto stable_baseline = updates::parse_version("v0.0.9").value();

    const auto current = page({release(L"v0.1.0-preview.3", true, {windows_zip(303)})});
    std::optional<updates::ListedAsset> preview;
    updates::consider_releases(current, preview_baseline, preview);
    check(!preview, "The installed Preview tag qualified as an update.");

    const updates::Release original{"v0.1.0-preview.3", preview_baseline,
                                    updates::original_preview3_asset};
    const auto manual = updates::update_baseline(preview_baseline, original);
    const auto old = page({release(L"v0.1.0-preview.3", false,
                                   {windows_zip(updates::original_preview3_asset)})});
    updates::consider_releases(old, manual, preview);
    check(!preview, "The superseded ZIP was offered again.");
    updates::consider_releases(current, manual, preview);
    check(preview && updates::asset_metadata(*preview).release.id == 303,
          "Opening the replacement failed to discover its same-tag ZIP.");
    const auto installed = updates::asset_metadata(*preview).release;
    preview.reset();
    updates::consider_releases(current, updates::update_baseline(preview_baseline, installed), preview);
    check(!preview, "An installed replacement tried to reinstall itself.");

    auto source_archive = windows_zip(601);
    source_archive.SetNamedValue(L"name", json::JsonValue::CreateStringValue(L"trainner-gui-source.tar.gz"));
    auto unfinished_zip = windows_zip(602);
    unfinished_zip.SetNamedValue(L"state", json::JsonValue::CreateStringValue(L"starter"));
    auto zip_without_digest = windows_zip(309);
    zip_without_digest.Remove(L"digest");

    const auto first = page({
        release(L"v0.1.0-preview.9", true, {zip_without_digest}),
        release(L"v9.0.0", false, {windows_zip(900)}, true),
        release(L"v8.0.0", true, {windows_zip(800)}),
        release(L"v0.1.0-preview.12", true, {source_archive, unfinished_zip}),
    });
    const auto second = page({
        release(L"v0.1.0-preview.10", false, {source_archive, unfinished_zip, windows_zip(310)}),
    });
    const auto third = page({release(L"v0.1.0-preview.8", true, {windows_zip(308)})});

    updates::consider_releases(first, preview_baseline, preview);
    check(preview && preview->tag == "v0.1.0-preview.9",
          "Expected the published Preview with an uploaded Windows ZIP.");
    bool rejected_digest = false;
    try {
        (void)updates::asset_metadata(*preview);
    } catch (const std::runtime_error&) {
        rejected_digest = true;
    }
    check(rejected_digest, "The selected asset qualified without a SHA-256 digest.");

    updates::consider_releases(second, preview_baseline, preview);
    updates::consider_releases(third, preview_baseline, preview);
    check(preview && preview->tag == "v0.1.0-preview.10",
          "Preview discovery failed to keep the numerically newest eligible tag across pages.");
    const auto asset = updates::asset_metadata(*preview);
    check(asset.release.id == 310 && asset.size == 4096 &&
              asset.digest == "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
          "The selected ZIP's asset ID, size, or SHA-256 was incorrect.");

    std::optional<updates::ListedAsset> stable;
    for (const auto& releases : {first, second, third})
        updates::consider_releases(releases, stable_baseline, stable);
    check(!stable, "A draft, prerelease, or Preview tag qualified for a stable installation.");

    const auto graduation = page({release(L"v0.1.0", false, {windows_zip(400)})});
    updates::consider_releases(graduation, stable_baseline, stable);
    updates::consider_releases(graduation, preview_baseline, preview);
    check(stable && stable->tag == "v0.1.0", "The published stable tag did not qualify.");
    check(preview && preview->tag == "v0.1.0", "The stable tag did not supersede its Preview.");
}

} // namespace

int main() {
    try {
        winrt::init_apartment();
        check_discovery();
    } catch (const winrt::hresult_error& error) {
        std::cerr << "Updater discovery smoke failed. " << winrt::to_string(error.message()) << '\n';
        return 1;
    } catch (const std::exception& error) {
        std::cerr << "Updater discovery smoke failed. " << error.what() << '\n';
        return 1;
    }
    std::cout << "Updater discovery smoke passed.\n";
}
