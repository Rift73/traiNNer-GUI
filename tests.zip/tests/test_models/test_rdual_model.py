"""RDUALModel: clip degradations and one clip training step on the CPU.

Tiny clips (T=3, LR 16x16, scale 2), L1 + GAN with a small U-Net
discriminator; vosrloss with a stand-in teacher on clips of T=4. Skipped
without the NeuFlow v2 weights.
"""

import contextlib
import os
import threading
import time
from collections.abc import Callable
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from typing import Any

import msgspec
import numpy as np
import pytest
import torch
from safetensors.torch import load_file
from torch import Tensor, nn
from torch.nn import functional
from traiNNer.archs.rdual_arch import RDUAL
from traiNNer.data import degradations
from traiNNer.data.clip_hr import clip_axes, hr_clip
from traiNNer.data.prefetch_dataloader import CPUPrefetcher
from traiNNer.data.realesrgan_dataset import sample_degradation_kernels
from traiNNer.losses.vosr_loss import VOSRLoss
from traiNNer.models import build_model, rdual_model, realesrgan_model
from traiNNer.models.rdual_model import (
    NEUFLOW_PRETRAIN_PATH,
    RDUALModel,
    check_clip_training_options,
)
from traiNNer.models.realesrgan_model import DegradeAheadPrefetcher, RealESRGANModel
from traiNNer.utils.misc import set_random_seed
from traiNNer.utils.redux_options import LogOptions, ReduxOptions
from traiNNer.utils.rng import RNG

pytestmark = pytest.mark.skipif(
    not os.path.exists(NEUFLOW_PRETRAIN_PATH),
    reason=f"needs {NEUFLOW_PRETRAIN_PATH}",
)

FRAMES = 3
LQ_SIZE = 16


def _options(**changes: Any) -> dict[str, Any]:
    options: dict[str, Any] = {
        "name": "rdual_model",
        "scale": 2,
        "num_gpu": 0,
        "is_train": True,
        "path": {},
        "high_order_degradation": True,
        "thicklines_prob": 0.0,
        "compress_prob": 0.0,
        "compress_prob2": 0.0,
        "compress_video_approx_prob": 0.0,
        "network_g": {"type": "rdual"},
        "network_d": {"type": "dunet", "num_feat": 8},
        "datasets": {
            "train": {
                "name": "clips",
                "type": "videoclipdataset",
                "phase": "train",
                "scale": 2,
                "gt_size": LQ_SIZE * 2,
                "lq_size": LQ_SIZE,
                "batch_size_per_gpu": 2,
                "accum_iter": 1,
            }
        },
        "train": {
            "total_iter": 2,
            "optim_g": {"type": "AdamW", "lr": 1e-3},
            "optim_d": {"type": "AdamW", "lr": 1e-3},
            "losses": [
                {"type": "l1loss", "loss_weight": 1.0},
                {"type": "ganloss", "gan_type": "vanilla", "loss_weight": 0.1},
            ],
        },
    }
    for key, value in changes.items():
        if key == "accum_iter":
            options["datasets"]["train"]["accum_iter"] = value
        elif key == "path":
            options["path"].update(value)
        elif key == "train":
            options["train"].update(value)
        else:
            options[key] = value
    return options


@pytest.fixture(autouse=True)
def _cpu_otf(monkeypatch: pytest.MonkeyPatch) -> None:
    with contextlib.suppress(RuntimeError):  # already initialised
        RNG.init_rng(0)
    torch.manual_seed(0)
    # The model moves its JPEG module to CUDA at construction.
    monkeypatch.setattr(nn.Module, "cuda", lambda module, device=None: module)
    # On the CPU some OTF ops return channels-last tensors, which filter2d's
    # .view() rejects; the same filter on a contiguous copy gives the same values.
    filter2d = realesrgan_model.filter2d
    monkeypatch.setattr(
        realesrgan_model,
        "filter2d",
        lambda img, kernel: filter2d(img.contiguous(), kernel),
    )


def _model(**changes: Any) -> RDUALModel:
    model = build_model(msgspec.convert(_options(**changes), ReduxOptions))
    assert isinstance(model, RDUALModel)
    return model


def _clips(batch: int = 2) -> dict[str, Tensor]:
    gen = torch.Generator().manual_seed(1)
    still = torch.rand(batch, 1, 3, LQ_SIZE * 2, LQ_SIZE * 2 + FRAMES, generator=gen)
    # A pan of one pixel per frame
    gt = torch.cat(
        [still[..., t : t + LQ_SIZE * 2] for t in range(FRAMES)], dim=1
    ).contiguous()
    return {"gt": gt, "shot_ids": torch.zeros(batch, FRAMES, dtype=torch.int64)}


def test_feed_data_shapes_without_pool() -> None:
    model = _model()
    model.feed_data(_clips())
    assert model.lq is not None
    assert model.gt is not None
    assert model.shot_ids is not None
    assert model.lq.shape == (2, FRAMES, 3, LQ_SIZE, LQ_SIZE)
    assert model.gt.shape == (2, FRAMES, 3, LQ_SIZE * 2, LQ_SIZE * 2)
    assert model.shot_ids.shape == (2, FRAMES)
    assert model.queue_lr is None
    assert model.queue_gt is None


def test_feed_data_makes_gt_from_yuv_windows(monkeypatch: pytest.MonkeyPatch) -> None:
    options = _options()
    options["datasets"]["train"].update({"descale_size": (96, 54), "hr_size": (48, 36)})
    model = build_model(msgspec.convert(options, ReduxOptions))
    assert isinstance(model, RDUALModel)
    dataset_opt = model.opt.datasets["train"]
    rows, cols = clip_axes(72, 128, dataset_opt)
    gen = torch.Generator().manual_seed(2)
    h, w = rows.size, cols.size
    data = {
        "gt_y": torch.randint(60, 200, (2, FRAMES, 1, h, w), generator=gen),
        "gt_u": torch.randint(100, 156, (2, FRAMES, 1, h // 2, w // 2), generator=gen),
        "gt_v": torch.randint(100, 156, (2, FRAMES, 1, h // 2, w // 2), generator=gen),
        "gt_geometry": torch.tensor(
            [
                [72, 128, 0, 0, int(rows.origins[0]), int(cols.origins[0]), 0, 0, 0],
                [72, 128, 4, 16, int(rows.origins[4]), int(cols.origins[16]), 1, 0, 1],
            ]
        ),
        "shot_ids": torch.zeros(2, FRAMES, dtype=torch.int64),
    }
    data.update({k: data[k].to(torch.uint8) for k in ("gt_y", "gt_u", "gt_v")})
    fed = []

    def record(self: RDUALModel, clip: dict[str, Tensor]) -> Any:
        fed.append(clip["gt"])
        self.gt = clip["gt"]
        self.lq = clip["gt"][..., ::2, ::2]
        yield from ()

    monkeypatch.setattr(RDUALModel, "_feed_steps", record)
    model.feed_data(data)
    for b, clip in enumerate(fed):
        expected = hr_clip(
            data["gt_y"][b],
            data["gt_u"][b],
            data["gt_v"][b],
            data["gt_geometry"][b],
            dataset_opt,
        )
        assert clip.shape == (FRAMES, 3, LQ_SIZE * 2, LQ_SIZE * 2)
        assert torch.equal(clip, expected)
    assert len(fed) == 2


def test_video_codec_runs_in_temporal_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[dict[str, Any]] = []
    prepare = realesrgan_model.prepare_video_batch

    def recording(tensor: Tensor, *args: Any, **kwargs: Any) -> Any:
        calls.append({"frames": tensor.shape[0], **kwargs})
        return prepare(tensor, *args, **kwargs)

    monkeypatch.setattr(realesrgan_model, "prepare_video_batch", recording)
    model = _model(
        compress_prob=1.0,
        compress_prob2=1.0,
        compress_algorithms=["h264"],
        compress_algorithm_probs=[1.0],
        compress_algorithms2=["h264"],
        compress_algorithm_probs2=[1.0],
    )
    model.feed_data(_clips())
    assert len(calls) == 4  # two stages for each of the two clips
    for call in calls:
        assert call["frames"] == FRAMES
        assert call["temporal"] is True
        assert 0 <= call["lead_in"] <= FRAMES - 1


# Every stage compresses; sizes stay even. Only codecs that give the same
# frames every time for the same input (x264 in temporal mode does not), with
# JPEG between them.
CODEC_STAGES: dict[str, Any] = {
    "compress_prob": 1.0,
    "compress_prob2": 1.0,
    "compress_algorithms": ["mpeg2", "mpeg4", "jpeg"],
    "compress_algorithm_probs": [1.0, 1.0, 1.0],
    "compress_algorithms2": ["mpeg2", "mpeg4", "jpeg"],
    "compress_algorithm_probs2": [1.0, 1.0, 1.0],
    "resize_prob": [0.0, 0.0, 1.0],
    "resize_prob2": [0.0, 0.0, 1.0],
}
VIDEO_ONLY = {
    **CODEC_STAGES,
    "compress_algorithms": ["h264"],
    "compress_algorithm_probs": [1.0],
    "compress_algorithms2": ["mpeg2"],
    "compress_algorithm_probs2": [1.0],
}


def _seeded(monkeypatch: pytest.MonkeyPatch, seed: int) -> None:
    set_random_seed(seed)
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(seed))


def _seeded_lq(
    monkeypatch: pytest.MonkeyPatch, model: RDUALModel, data: Any, seed: int
) -> Tensor:
    _seeded(monkeypatch, seed)
    model.feed_data(data)
    assert model.lq is not None
    return model.lq.clone()


def _wrap_round_trips(
    monkeypatch: pytest.MonkeyPatch,
    wrap: Callable[[Callable[[], Tensor]], Callable[[], Tensor]],
) -> None:
    """Pass every video-codec round trip of feed_data through wrap."""
    prepare = realesrgan_model.prepare_video_batch

    def wrapped(*args: Any, **kwargs: Any) -> Any:
        round_trip, finish = prepare(*args, **kwargs)
        return wrap(round_trip), finish

    monkeypatch.setattr(realesrgan_model, "prepare_video_batch", wrapped)


class _InlinePool(ThreadPoolExecutor):
    """Runs each job when it is submitted, one after another."""

    def submit(self, fn: Callable[..., Any], /, *args: Any, **kwargs: Any) -> Future:
        future: Future = Future()
        future.set_result(fn(*args, **kwargs))
        return future


def test_codec_waves_do_not_depend_on_thread_timing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model = _model(**CODEC_STAGES)
    data = _clips(4)
    pool = model.degradation_pool
    model.degradation_pool = _InlinePool(max_workers=1)
    inline = [_seeded_lq(monkeypatch, model, data, seed) for seed in range(3)]
    model.degradation_pool = pool
    # Delays drawn on the calling thread from a generator of their own.
    delays = np.random.default_rng(7)

    def delayed(round_trip: Callable[[], Tensor]) -> Callable[[], Tensor]:
        delay = float(delays.uniform(0.0, 0.03))

        def job() -> Tensor:
            time.sleep(delay)
            return round_trip()

        return job

    _wrap_round_trips(monkeypatch, delayed)
    pooled = [_seeded_lq(monkeypatch, model, data, seed) for seed in range(3)]
    for a, b in zip(inline, pooled, strict=True):
        assert torch.equal(a, b)


def test_round_trips_of_a_wave_run_at_the_same_time(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    lock = threading.Lock()
    running = [0]
    peak = [0]

    def counted(round_trip: Callable[[], Tensor]) -> Callable[[], Tensor]:
        def job() -> Tensor:
            with lock:
                running[0] += 1
                peak[0] = max(peak[0], running[0])
            time.sleep(0.05)
            try:
                return round_trip()
            finally:
                with lock:
                    running[0] -= 1

        return job

    _wrap_round_trips(monkeypatch, counted)
    model = _model(**VIDEO_ONLY)
    model.feed_data(_clips(3))
    assert peak[0] >= 2


def test_round_trip_error_comes_out_of_feed_data(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def failing(round_trip: Callable[[], Tensor]) -> Callable[[], Tensor]:
        def job() -> Tensor:
            raise RuntimeError("codec round trip failed")

        return job

    _wrap_round_trips(monkeypatch, failing)
    model = _model(**VIDEO_ONLY)
    with pytest.raises(RuntimeError, match="codec round trip failed"):
        model.feed_data(_clips(2))


def test_one_clip_degrades_as_image_training(monkeypatch: pytest.MonkeyPatch) -> None:
    model = _model(**CODEC_STAGES)
    data = _clips(1)
    for seed in range(4):
        lq = _seeded_lq(monkeypatch, model, data, seed)
        _seeded(monkeypatch, seed)
        kernels = sample_degradation_kernels(model.opt.datasets["train"])
        kernel1, kernel2, sinc_kernel = (k.repeat(FRAMES, 1, 1) for k in kernels)
        # The image training chain, its jobs run on this thread.
        batch = RealESRGANModel.start_batch(
            model,
            {
                "gt": data["gt"][0],
                "kernel1": kernel1,
                "kernel2": kernel2,
                "sinc_kernel": sinc_kernel,
            },
            pooled=False,
        )
        while not batch.finished:
            model.advance_batch(batch)
        assert torch.equal(lq[0], batch.done[0]["lq"])


# Two codec stages in every clip.
TWO_CODECS = {
    **CODEC_STAGES,
    "compress_algorithms": ["mpeg2"],
    "compress_algorithm_probs": [1.0],
    "compress_algorithms2": ["mpeg4"],
    "compress_algorithm_probs2": [1.0],
}


def _raw_batches(count: int, clips: int = 2) -> list[dict[str, Tensor]]:
    """Distinct raw batches; batch k has shot_ids k."""
    batches = []
    for k in range(count):
        gen = torch.Generator().manual_seed(10 + k)
        gt = torch.rand(clips, FRAMES, 3, LQ_SIZE * 2, LQ_SIZE * 2, generator=gen)
        shot_ids = torch.full((clips, FRAMES), k, dtype=torch.int64)
        batches.append({"gt": gt, "shot_ids": shot_ids})
    return batches


def _flight(
    model: RDUALModel, batches: list[dict[str, Tensor]]
) -> DegradeAheadPrefetcher:
    return DegradeAheadPrefetcher(CPUPrefetcher(batches), model)


def _delivered(
    monkeypatch: pytest.MonkeyPatch,
    model: RDUALModel,
    batches: list[dict[str, Tensor]],
    seed: int,
) -> list[dict[str, Tensor]]:
    _seeded(monkeypatch, seed)
    flight = _flight(model, batches)
    delivered = []
    while (data := flight.next()) is not None:
        delivered.append(data)
    return delivered


def test_flight_without_lead_feeds_batches_one_by_one(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(RDUALModel, "ahead_stride", 0)
    model = _model(**CODEC_STAGES)
    batches = _raw_batches(3)
    delivered = _delivered(monkeypatch, model, batches, 4)
    _seeded(monkeypatch, 4)
    for batch, data in zip(batches, delivered, strict=True):
        model.feed_data(batch)
        assert torch.equal(model.lq, data["lq"])
        assert torch.equal(model.gt, data["gt"])


def test_flight_does_not_depend_on_thread_timing(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model = _model(**CODEC_STAGES)
    batches = _raw_batches(4, clips=3)
    pool = model.degradation_pool
    model.degradation_pool = _InlinePool(max_workers=1)
    inline = _delivered(monkeypatch, model, batches, 6)
    model.degradation_pool = pool
    delays = np.random.default_rng(8)

    def delayed(round_trip: Callable[[], Tensor]) -> Callable[[], Tensor]:
        delay = float(delays.uniform(0.0, 0.03))

        def job() -> Tensor:
            time.sleep(delay)
            return round_trip()

        return job

    _wrap_round_trips(monkeypatch, delayed)
    pooled = _delivered(monkeypatch, model, batches, 6)
    assert len(inline) == len(pooled) == 4
    for a, b in zip(inline, pooled, strict=True):
        assert torch.equal(a["lq"], b["lq"])
        assert torch.equal(a["gt"], b["gt"])


def test_flight_delivers_each_batch_once_in_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model = _model(**TWO_CODECS)
    batches = _raw_batches(4)
    flight = _flight(model, batches)
    for _ in range(2):  # two epochs
        flight.reset()
        for k in range(4):
            data = flight.next()
            assert data is not None
            assert torch.equal(data["shot_ids"], batches[k]["shot_ids"])
            assert data["lq"].shape == (2, FRAMES, 3, LQ_SIZE, LQ_SIZE)
        assert flight.next() is None
    # A reset in the middle of an epoch drops the batches in flight.
    flight.reset()
    flight.next()
    flight.next()
    flight.reset()
    data = flight.next()
    assert data is not None
    assert torch.equal(data["shot_ids"], batches[0]["shot_ids"])
    assert len(flight.in_flight) == 2


def test_flight_returns_before_younger_round_trips_finish(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    release = threading.Event()
    gate = [False]
    running = [0]
    lock = threading.Lock()

    def gated(round_trip: Callable[[], Tensor]) -> Callable[[], Tensor]:
        blocked = gate[0]

        def job() -> Tensor:
            if blocked:
                with lock:
                    running[0] += 1
                assert release.wait(timeout=30)
                with lock:
                    running[0] -= 1
            return round_trip()

        return job

    _wrap_round_trips(monkeypatch, gated)
    model = _model(**TWO_CODECS)
    batches = _raw_batches(4)
    flight = _flight(model, batches)
    assert flight.next() is not None
    gate[0] = True  # round trips prepared from now on wait for release
    data = flight.next()
    assert data is not None
    assert torch.equal(data["shot_ids"], batches[1]["shot_ids"])
    time.sleep(0.2)
    with lock:
        assert running[0] >= 2  # younger batches' round trips still running
    release.set()
    data = flight.next()
    assert data is not None
    assert torch.equal(data["shot_ids"], batches[2]["shot_ids"])


def test_flight_round_trip_error_comes_out_of_next(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def failing(round_trip: Callable[[], Tensor]) -> Callable[[], Tensor]:
        def job() -> Tensor:
            raise RuntimeError("codec round trip failed in flight")

        return job

    _wrap_round_trips(monkeypatch, failing)
    flight = _flight(_model(**TWO_CODECS), _raw_batches(3))
    with pytest.raises(RuntimeError, match="codec round trip failed in flight"):
        flight.next()


def test_feed_data_installs_a_delivered_batch_without_draws(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model = _model()
    data = {
        "lq": torch.rand(2, FRAMES, 3, LQ_SIZE, LQ_SIZE),
        "gt": torch.rand(2, FRAMES, 3, LQ_SIZE * 2, LQ_SIZE * 2),
        "shot_ids": torch.zeros(2, FRAMES, dtype=torch.int64),
    }
    draws: list[str] = []

    class LoggedRNG:
        def __getattr__(self, name: str) -> Any:
            draws.append(name)
            raise AssertionError(f"feed_data drew {name}")

    monkeypatch.setattr(RNG, "_rng", LoggedRNG())
    model.feed_data(data)
    assert draws == []
    assert model.lq is data["lq"]
    assert model.gt is data["gt"]
    assert model.shot_ids is data["shot_ids"]


def test_settings_are_drawn_once_per_clip(monkeypatch: pytest.MonkeyPatch) -> None:
    drawn: list[Tensor] = []
    gaussian = degradations.generate_gaussian_noise_pt
    poisson = degradations.generate_poisson_noise_pt

    def recording_gaussian(
        img: Tensor, sigma: Tensor, gray: Tensor, **kwargs: Any
    ) -> Tensor:
        drawn.extend((sigma, gray))
        return gaussian(img, sigma, gray, **kwargs)

    def recording_poisson(
        img: Tensor, scale: Tensor, gray: Tensor, **kwargs: Any
    ) -> Tensor:
        drawn.extend((scale, gray))
        return poisson(img, scale, gray, **kwargs)

    monkeypatch.setattr(degradations, "generate_gaussian_noise_pt", recording_gaussian)
    monkeypatch.setattr(degradations, "generate_poisson_noise_pt", recording_poisson)
    model = _model(
        gaussian_noise_prob=1.0,
        noise_range=(1.0, 20.0),
        gaussian_noise_prob2=0.0,
        poisson_scale_range2=(0.05, 2.0),
        gray_noise_prob=0.5,
        gray_noise_prob2=0.5,
        compress_prob=1.0,
        compress_algorithms=["jpeg"],
        compress_algorithm_probs=[1.0],
    )
    qualities: list[Tensor] = []
    jpeger = model.jpeger

    def recording_jpeg(img: Tensor, quality: Tensor) -> Tensor:
        qualities.append(quality)
        return jpeger(img, quality=quality)

    model.jpeger = recording_jpeg
    model.feed_data(_clips())
    assert len(drawn) == 8  # two noise stages for each of the two clips
    assert len(qualities) == 2
    for values in drawn + qualities:
        assert values.shape == (FRAMES,)
        assert torch.equal(values, values[:1].expand(FRAMES))


def _parameters(net: nn.Module) -> list[Tensor]:
    return [p.detach().clone() for p in net.parameters()]


def _changed(net: nn.Module, before: list[Tensor]) -> bool:
    return any(
        not torch.equal(p, b) for p, b in zip(net.parameters(), before, strict=True)
    )


def _flow_state(net: nn.Module) -> dict[str, Tensor]:
    assert isinstance(net, RDUAL)
    return {k: v.clone() for k, v in net.flow.state_dict().items()}


def test_flow_weights_fill_generator_and_ema(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    model = _model(train={"ema_decay": 0.999})
    assert model.net_g_ema is not None
    upstream = load_file(NEUFLOW_PRETRAIN_PATH)
    for net in (model.get_bare_model(model.net_g), model.net_g_ema.ema_model):
        assert isinstance(net, RDUAL)
        assert bool(net.flow_loaded)
        for key, value in upstream.items():
            assert torch.equal(net.flow.state_dict()[key], value)

    # The saved generator carries the flow, so a start from it loads no file.
    model.opt.logger = LogOptions(
        print_freq=1, save_checkpoint_freq=1, use_tb_logger=False
    )
    model.save_network(model.net_g, "net_g", str(tmp_path), 1, "params")
    saved = load_file(str(tmp_path / "net_g_1.safetensors"))
    flow_keys = [k for k in saved if k.startswith("flow.")]
    assert len(flow_keys) == len(upstream)
    assert bool(saved["flow_loaded"])

    def no_file(*args: Any, **kwargs: Any) -> None:
        raise AssertionError("flow weights were read although the checkpoint has them")

    monkeypatch.setattr(rdual_model, "load_file", no_file)
    restarted = _model(
        train={"ema_decay": 0.999},
        path={"pretrain_network_g": str(tmp_path / "net_g_1.safetensors")},
    )
    assert restarted.net_g_ema is not None
    for net in (
        restarted.get_bare_model(restarted.net_g),
        restarted.net_g_ema.ema_model,
    ):
        assert isinstance(net, RDUAL)
        assert bool(net.flow_loaded)
        assert torch.equal(
            net.flow.state_dict()[flow_keys[0][len("flow.") :]], saved[flow_keys[0]]
        )


def test_one_step_trains_both_networks() -> None:
    model = _model()
    assert model.net_d is not None
    before_g, before_d = _parameters(model.net_g), _parameters(model.net_d)
    before_flow = _flow_state(model.get_bare_model(model.net_g))
    model.feed_data(_clips())
    model.optimize_parameters(1, 0, True)

    assert model.training_step_accepted
    assert model.output is not None
    assert model.output.shape == (2, FRAMES, 3, LQ_SIZE * 2, LQ_SIZE * 2)
    for key in ("l_g_l1", "l_g_gan", "l_g_total", "l_d_real", "l_d_fake"):
        assert key in model.log_dict
        assert torch.isfinite(torch.as_tensor(model.log_dict[key]))
    assert _changed(model.net_g, before_g)
    assert _changed(model.net_d, before_d)
    after_flow = _flow_state(model.get_bare_model(model.net_g))
    assert all(torch.equal(after_flow[k], v) for k, v in before_flow.items())


def test_accumulation_steps_every_second_call(monkeypatch: pytest.MonkeyPatch) -> None:
    model = _model(accum_iter=2)
    assert model.optimizer_d is not None
    steps = {"g": 0, "d": 0}
    for name, optimizer in (("g", model.optimizer_g), ("d", model.optimizer_d)):
        step = optimizer.step

        def counting(
            *args: Any, _name: str = name, _step: Any = step, **kwargs: Any
        ) -> Any:
            steps[_name] += 1
            return _step(*args, **kwargs)

        monkeypatch.setattr(optimizer, "step", counting)

    model.feed_data(_clips(1))
    model.optimize_parameters(1, 0, False)
    assert steps == {"g": 0, "d": 0}
    model.feed_data(_clips(1))
    model.optimize_parameters(1, 1, True)
    assert steps == {"g": 1, "d": 1}


@pytest.mark.parametrize(
    ("changes", "match"),
    [
        ({"high_order_degradation": False}, "high_order_degradation"),
        ({"train": {"use_moa": True}}, "use_moa"),
        ({"otf_hf_noise_prob": 0.5}, "otf_hf_noise_prob"),
        (
            {"val": {"val_enabled": True, "save_img": False}},
            "validation is not built for clips",
        ),
    ],
)
def test_unsupported_options_are_rejected(changes: dict[str, Any], match: str) -> None:
    with pytest.raises(ValueError, match=match):
        _model(**changes)


# ------------------------------ vosrloss on clips ------------------------------ #

VOSR_FRAMES = 4
VOSR_WEIGHT = 0.1


class _IdentityWindow:
    """Stands in for the TensorRT window on the CPU (the recording teacher replaces its use)."""

    def __init__(self, engine_dir: str, plugin: str, lanes: int = 2) -> None:
        self.device = torch.device("cpu")


class _RecordingTeacher:
    """Restores clip b of the key frames as the constant image 0.2 + 0.1 b, an inference tensor like
    VosrTeacher.restore, so a VOSR target shows which clip it belongs to and where it is still."""

    def __init__(self) -> None:
        self.base = 0.2
        self.calls: list[tuple[int, ...]] = []

    def values(self, batch: int) -> Tensor:
        return self.base + 0.1 * torch.arange(batch, dtype=torch.float32)

    def value(self, clip: int) -> float:
        return float(self.values(clip + 1)[clip])

    def restore(self, lq_rgb: Tensor, scale: int) -> Tensor:
        self.calls.append(tuple(lq_rgb.shape))
        values = self.values(lq_rgb.shape[0])
        height, width = lq_rgb.shape[-2] * scale, lq_rgb.shape[-1] * scale
        with torch.inference_mode():
            return values[:, None, None, None].expand(-1, 3, height, width).clone()


def _vosr_losses(still_frames: int) -> dict[str, Any]:
    return {
        "losses": [
            {"type": "l1loss", "loss_weight": 1.0},
            {"type": "ganloss", "gan_type": "vanilla", "loss_weight": 0.1},
            {
                "type": "vosrloss",
                "loss_weight": VOSR_WEIGHT,
                "engine_dir": "engines",
                "plugin": "plugin.so",
                "criterion": "l1",
                "still_frames": still_frames,
            },
        ]
    }


class _VosrRun:
    """An RDUALModel with vosrloss and a recording teacher; records every VOSR distance call with its frame,
    and every running-state update."""

    def __init__(self, monkeypatch: pytest.MonkeyPatch, still_frames: int) -> None:
        from traiNNer.losses import vosr2_trt

        monkeypatch.setattr(vosr2_trt, "Vosr2Window", _IdentityWindow)
        self.model = _model(train=_vosr_losses(still_frames))
        vosr = self.model.losses["l_g_vosr"]
        assert isinstance(vosr, VOSRLoss)
        self.vosr = vosr
        self.teacher = _RecordingTeacher()
        monkeypatch.setattr(vosr, "teacher", self.teacher)
        self.frame = -1
        self.terms: list[tuple[int, Tensor, Tensor]] = []
        self.states: list[tuple[tuple[Any, ...], tuple[Tensor, Tensor]]] = []

        backward_clip = RDUAL.backward_clip

        def recording_clip(
            net: RDUAL, frames: Tensor, guidance: Any, loss: Any, **kwargs: Any
        ) -> Tensor:
            def frame_loss(output: Tensor, t: int) -> Tensor:
                self.frame = t
                return loss(output, t)

            return backward_clip(net, frames, guidance, frame_loss, **kwargs)

        monkeypatch.setattr(RDUAL, "backward_clip", recording_clip)
        distance = vosr.distance

        def recording_distance(output: Tensor, target: Tensor) -> Tensor:
            self.terms.append((self.frame, output.detach().clone(), target.clone()))
            return distance(output, target)

        monkeypatch.setattr(vosr, "distance", recording_distance)
        balance_state = rdual_model.vosr_balance_state

        def recording_state(*args: Any) -> tuple[Tensor, Tensor]:
            state = balance_state(*args)
            self.states.append((args, state))
            return state

        monkeypatch.setattr(rdual_model, "vosr_balance_state", recording_state)

    def step(self, gt: Tensor, lq_offsets: Tensor, shot_ids: Tensor) -> float:
        """One call on true frames gt (B,T,3,H,W), each LR frame gt made smaller plus its offset (B,T);
        returns the call's VOSR scale."""
        small = functional.interpolate(
            gt.flatten(0, 1), size=(LQ_SIZE, LQ_SIZE), mode="bicubic", antialias=True
        ).view(*gt.shape[:3], LQ_SIZE, LQ_SIZE)
        self.model.gt = gt
        self.model.lq = small + lq_offsets[..., None, None, None]
        self.model.shot_ids = shot_ids
        self.model.log_dict = {}
        self.terms = []
        self.model.optimize_parameters(1, 0, True)
        return float(self.model.log_dict.get("vosr_scale", torch.nan)) / gt.shape[0]

    def masks(self) -> dict[int, dict[int, Tensor]]:
        """Per clip and frame of the last call, the still mask (1,H,W) of each VOSR term."""
        masks: dict[int, dict[int, Tensor]] = {}
        for t, output, target in self.terms:
            for row in range(output.shape[0]):
                clips = [
                    b
                    for b in range(len(self.model.output))
                    if bool((target[row] == self.teacher.value(b)).any())
                ]
                assert len(clips) == 1
                still = (target[row] == self.teacher.value(clips[0])).all(
                    0, keepdim=True
                )
                # Where the picture moved the target is the output itself
                assert torch.equal(target[row][:, ~still[0]], output[row][:, ~still[0]])
                masks.setdefault(clips[0], {})[t] = still.float()
        return masks


def _frames(batch: int) -> Tensor:
    """Identical true frames in 0.3..0.7 for every clip."""
    gen = torch.Generator().manual_seed(3)
    image = torch.rand(batch, 1, 3, LQ_SIZE * 2, LQ_SIZE * 2, generator=gen)
    return (0.3 + 0.4 * image).expand(-1, VOSR_FRAMES, -1, -1, -1).contiguous()


def test_vosr_options_check() -> None:
    def options(**train: Any) -> ReduxOptions:
        return msgspec.convert(_options(train=train), ReduxOptions)

    check_clip_training_options(options(**_vosr_losses(2)))
    with pytest.raises(ValueError, match="vosr_target"):
        check_clip_training_options(
            options(vosr_target={"engine_dir": "engines", "plugin": "plugin.so"})
        )
    losses = [*_options()["train"]["losses"], {"type": "ldlloss", "loss_weight": 1.0}]
    with pytest.raises(ValueError, match="ldlloss"):
        check_clip_training_options(options(losses=losses))


def test_vosr_still_frames_must_not_be_negative() -> None:
    with pytest.raises(ValueError, match="still_frames"):
        VOSRLoss(1.0, "engines", "plugin.so", still_frames=-1)


def test_vosr_key_frame_is_best_of_drawn_shot(monkeypatch: pytest.MonkeyPatch) -> None:
    run = _VosrRun(monkeypatch, still_frames=0)
    gt = _frames(2)
    # Clip 0: shots {0,1} and {2,3}, the clip's best frame (2) in the second shot
    offsets = torch.tensor([[0.3, 0.1, 0.05, 0.2], [0.2, 0.1, 0.15, 0.25]])
    shot_ids = torch.tensor([[0, 0, 1, 1], [7, 7, 7, 7]])
    keys = set()
    for seed in range(8):
        torch.manual_seed(seed)
        run.step(gt, offsets, shot_ids)
        masks = run.masks()
        # still_frames 0: the key frame only, with an all-ones mask
        assert list(masks[1]) == [1]
        assert len(masks[0]) == 1
        for clip in masks.values():
            for mask in clip.values():
                assert bool((mask == 1).all())
        keys.add(next(iter(masks[0])))
    assert keys == {1, 2}
    # The teacher runs once per call, on the B key frames
    assert run.teacher.calls == [(2, 3, LQ_SIZE, LQ_SIZE)] * 8


def test_vosr_still_masks(monkeypatch: pytest.MonkeyPatch) -> None:
    run = _VosrRun(monkeypatch, still_frames=3)
    gt = _frames(2)
    # Clip 0: frame 2 changes in one block, frame 3 everywhere; frame 0 is the key
    gt[0, 2, :, 8:12, 8:12] += 0.2
    gt[0, 3] = 1 - gt[0, 3]
    offsets = torch.tensor([[0.0, 0.1, 0.1, 0.1], [0.1, 0.0, 0.1, 0.1]])
    # Clip 1: identical frames in two shots
    shot_ids = torch.tensor([[0, 0, 0, 0], [4, 4, 5, 5]])
    run.step(gt, offsets, shot_ids)
    masks = run.masks()
    assert sorted(masks[0]) == [0, 1, 2]  # frame 3 is below the minimum still share
    for t in (0, 1):
        assert bool((masks[0][t] == 1).all())
    # The 4x4 block changed by 51 levels: its box mean exceeds 2 levels where the
    # 9x9 box covers at least 4 of its pixels, so within the block grown by 3 pixels,
    # and nowhere beyond the block grown by the margin
    inner = torch.zeros_like(masks[0][2], dtype=torch.bool)
    inner[:, 5:15, 5:15] = True
    outer = torch.zeros_like(inner)
    outer[:, 4:16, 4:16] = True
    assert bool((masks[0][2][inner] == 0).all())
    assert bool((masks[0][2][~outer] == 1).all())
    # No reuse across shots: clip 1 trains exactly the frames of its key shot
    assert sorted(masks[1]) in ([0, 1], [2, 3])
    for mask in masks[1].values():
        assert bool((mask == 1).all())


def test_vosr_gradient_is_zero_where_the_picture_moved(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    run = _VosrRun(monkeypatch, still_frames=3)
    gt = _frames(1)
    gt[0, 2, :, 8:12, 8:12] += 0.2
    offsets = torch.tensor([[0.0, 0.1, 0.1, 0.1]])
    run.step(gt, offsets, torch.zeros(1, VOSR_FRAMES, dtype=torch.int64))
    masks = run.masks()
    assert sorted(masks[0]) == [0, 1, 2, 3]
    # The VOSR distance of reuse frame 2, as the frame loss computed it
    _, output, target = next(term for term in run.terms if term[0] == 2)
    output.requires_grad_()
    VOSRLoss.distance(run.vosr, output, target).backward()
    assert output.grad is not None
    moved = (masks[0][2] == 0).expand_as(output.grad[0])[None]
    assert bool(moved[..., 5:15, 5:15].all())
    assert bool((output.grad[moved] == 0).all())
    assert bool((output.grad[~moved] != 0).all())


def test_vosr_balance(monkeypatch: pytest.MonkeyPatch) -> None:
    run = _VosrRun(monkeypatch, still_frames=2)
    gt = _frames(2)
    offsets = torch.tensor([[0.0, 0.1, 0.1, 0.1], [0.1, 0.0, 0.1, 0.1]])
    shot_ids = torch.zeros(2, VOSR_FRAMES, dtype=torch.int64)

    # The first call only measures and starts the running state
    assert run.step(gt, offsets, shot_ids) == 0.0
    assert run.model.training_step_accepted
    (distance, _, state), first = run.states[-1]
    assert state is None
    shares = [
        VOSRLoss.distance(run.vosr, output, target) * (output.shape[0] / 2)
        for _, output, target in run.terms
    ]
    assert float(distance) == pytest.approx(float(sum(shares)) / VOSR_FRAMES, rel=1e-6)

    scale = run.step(gt, offsets, shot_ids)
    assert run.model.training_step_accepted
    assert run.states[-1][0][2] is first
    assert scale == pytest.approx(VOSR_WEIGHT * float(first[0] / first[1]), rel=1e-6)
    second = run.states[-1][1]

    # A rejected non-finite call keeps the committed state
    run.teacher.base = torch.nan
    run.step(gt, offsets, shot_ids)
    assert not run.model.training_step_accepted
    run.teacher.base = 0.2
    scale = run.step(gt, offsets, shot_ids)
    assert run.states[-1][0][2] is second
    assert scale == pytest.approx(VOSR_WEIGHT * float(second[0] / second[1]), rel=1e-6)


def test_without_vosr_the_vosr_path_is_not_entered(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def unexpected(*args: Any, **kwargs: Any) -> None:
        raise AssertionError("the VOSR path ran without vosrloss")

    monkeypatch.setattr(rdual_model, "vosr_balance_state", unexpected)
    monkeypatch.setattr(VOSRLoss, "distance", unexpected)
    model = _model()
    model.feed_data(_clips())
    model.optimize_parameters(1, 0, True)
    assert model.training_step_accepted
    assert "vosr_scale" not in model.log_dict


def test_vosr_training_steps(monkeypatch: pytest.MonkeyPatch) -> None:
    run = _VosrRun(monkeypatch, still_frames=2)
    model = run.model
    before = _parameters(model.net_g)
    for call in range(5):
        model.log_dict = {}
        model.feed_data(_clips())
        model.optimize_parameters(call + 1, 0, True)
        assert model.training_step_accepted
        for key in ("l_g_l1", "l_g_gan", "l_g_vosr", "l_g_total", "vosr_scale"):
            assert torch.isfinite(torch.as_tensor(model.log_dict[key]))
        # The running state is committed after each call and read by the next
        assert len(run.states) == call + 1
        if call > 0:
            assert run.states[call][0][2] is run.states[call - 1][1]
            assert float(model.log_dict["l_g_vosr"]) != 0.0
    assert _changed(model.net_g, before)
