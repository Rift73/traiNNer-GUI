"""RSRModel: model selection, option checks and clip training steps on the CPU.

Tiny clips (T=3, LR 16x16, scale 2), L1 + GAN with a small U-Net
discriminator, as the RDUALModel tests.
"""

import contextlib
from typing import Any

import msgspec
import pytest
import torch
from torch import Tensor, nn
from traiNNer.archs.rsr_arch import RSR, StepFunctions
from traiNNer.models import build_model, realesrgan_model
from traiNNer.models.rsr_model import RSRModel
from traiNNer.utils.redux_options import ReduxOptions
from traiNNer.utils.rng import RNG

FRAMES = 3
LQ_SIZE = 16
TEMPORAL = ("attention.key_value_past.", "attention.key_value_future.")


def _options(**changes: Any) -> dict[str, Any]:
    options: dict[str, Any] = {
        "name": "rsr_model",
        "scale": 2,
        "num_gpu": 0,
        "is_train": True,
        "path": {},
        "high_order_degradation": True,
        "thicklines_prob": 0.0,
        "compress_prob": 0.0,
        "compress_prob2": 0.0,
        "network_g": {"type": "rsr_compact"},
        "network_d": {"type": "dunet", "num_feat": 8},
        "datasets": {
            "train": {
                "name": "clips",
                "type": "videoclipdataset",
                "phase": "train",
                "scale": 2,
                "gt_size": LQ_SIZE * 2,
                "lq_size": LQ_SIZE,
                "batch_size_per_gpu": 2,
                "accum_iter": 1,
            }
        },
        "train": {
            "total_iter": 2,
            "optim_g": {"type": "AdamW", "lr": 1e-3},
            "optim_d": {"type": "AdamW", "lr": 1e-3},
            "losses": [
                {"type": "l1loss", "loss_weight": 1.0},
                {"type": "ganloss", "gan_type": "vanilla", "loss_weight": 0.1},
            ],
        },
    }
    for key, value in changes.items():
        if key == "accum_iter":
            options["datasets"]["train"]["accum_iter"] = value
        elif key == "train":
            options["train"].update(value)
        else:
            options[key] = value
    return options


@pytest.fixture(autouse=True)
def _cpu_otf(monkeypatch: pytest.MonkeyPatch) -> None:
    with contextlib.suppress(RuntimeError):  # already initialised
        RNG.init_rng(0)
    torch.manual_seed(0)
    # The model moves its JPEG module to CUDA at construction.
    monkeypatch.setattr(nn.Module, "cuda", lambda module, device=None: module)
    # On the CPU some OTF ops return channels-last tensors, which filter2d's
    # .view() rejects; the same filter on a contiguous copy gives the same values.
    filter2d = realesrgan_model.filter2d
    monkeypatch.setattr(
        realesrgan_model,
        "filter2d",
        lambda img, kernel: filter2d(img.contiguous(), kernel),
    )


def _model(**changes: Any) -> RSRModel:
    model = build_model(msgspec.convert(_options(**changes), ReduxOptions))
    assert isinstance(model, RSRModel)
    return model


def _clips(batch: int = 2) -> dict[str, Tensor]:
    gen = torch.Generator().manual_seed(1)
    still = torch.rand(batch, 1, 3, LQ_SIZE * 2, LQ_SIZE * 2 + FRAMES, generator=gen)
    # A pan of one pixel per frame
    gt = torch.cat(
        [still[..., t : t + LQ_SIZE * 2] for t in range(FRAMES)], dim=1
    ).contiguous()
    return {"gt": gt, "shot_ids": torch.zeros(batch, FRAMES, dtype=torch.int64)}


def _parameters(net: nn.Module) -> dict[str, Tensor]:
    return {name: p.detach().clone() for name, p in net.named_parameters()}


def _changed(net: nn.Module, before: dict[str, Tensor]) -> set[str]:
    return {
        name for name, p in net.named_parameters() if not torch.equal(p, before[name])
    }


def test_rsr_compact_selects_rsr_model() -> None:
    model = _model()
    assert isinstance(model.get_bare_model(model.net_g), RSR)
    assert isinstance(model.step_functions, StepFunctions)
    model.feed_data(_clips())
    assert model.lq is not None
    assert model.shot_ids is not None
    assert model.lq.shape == (2, FRAMES, 3, LQ_SIZE, LQ_SIZE)
    assert model.shot_ids.shape == (2, FRAMES)


def test_one_step_trains_both_networks_and_the_temporal_read() -> None:
    model = _model()
    assert model.net_d is not None
    before_g, before_d = _parameters(model.net_g), _parameters(model.net_d)
    model.feed_data(_clips())
    model.optimize_parameters(1, 0, True)

    assert model.training_step_accepted
    assert model.output is not None
    assert model.output.shape == (2, FRAMES, 3, LQ_SIZE * 2, LQ_SIZE * 2)
    for key in ("l_g_l1", "l_g_gan", "l_g_total", "l_d_real", "l_d_fake"):
        assert key in model.log_dict
        assert torch.isfinite(torch.as_tensor(model.log_dict[key]))
    changed = _changed(model.net_g, before_g)
    for prefix in TEMPORAL:
        assert any(name.startswith(prefix) for name in changed), prefix
    assert _changed(model.net_d, before_d)


def test_accumulation_steps_every_second_call(monkeypatch: pytest.MonkeyPatch) -> None:
    model = _model(accum_iter=2)
    assert model.optimizer_d is not None
    steps = {"g": 0, "d": 0}
    for name, optimizer in (("g", model.optimizer_g), ("d", model.optimizer_d)):
        step = optimizer.step

        def counting(
            *args: Any, _name: str = name, _step: Any = step, **kwargs: Any
        ) -> Any:
            steps[_name] += 1
            return _step(*args, **kwargs)

        monkeypatch.setattr(optimizer, "step", counting)

    model.feed_data(_clips(1))
    model.optimize_parameters(1, 0, False)
    assert steps == {"g": 0, "d": 0}
    model.feed_data(_clips(1))
    model.optimize_parameters(1, 1, True)
    assert steps == {"g": 1, "d": 1}


@pytest.mark.parametrize(
    ("changes", "match"),
    [
        ({"high_order_degradation": False}, "high_order_degradation"),
        ({"train": {"use_moa": True}}, "use_moa"),
        ({"otf_hf_noise_prob": 0.5}, "otf_hf_noise_prob"),
        (
            {"val": {"val_enabled": True, "save_img": False}},
            "validation is not built for clips",
        ),
        (
            {
                "train": {
                    "losses": [
                        {"type": "l1loss", "loss_weight": 1.0},
                        {
                            "type": "vosrloss",
                            "loss_weight": 0.1,
                            "engine_dir": "engines",
                            "plugin": "plugin.so",
                        },
                    ]
                }
            },
            "vosrloss loss is not supported for RSR",
        ),
    ],
)
def test_unsupported_options_are_rejected(changes: dict[str, Any], match: str) -> None:
    with pytest.raises(ValueError, match=r"^RSR clip training .*" + match):
        _model(**changes)
