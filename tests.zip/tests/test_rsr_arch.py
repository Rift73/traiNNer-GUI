"""CPU tests of RSR, the recurrent WSR Compact (traiNNer.archs.rsr_arch)."""

from __future__ import annotations

import copy
import math
from collections.abc import Callable

import pytest
import torch
from torch import Tensor, nn
from traiNNer.archs.rsr_arch import RSR, StepFunctions, rsr_compact
from traiNNer.archs.wsr_arch import wsr_compact

NEW_KEYS = {
    "attention.key_value_past.weight",
    "attention.key_value_past.bias",
    "attention.key_value_future.weight",
    "attention.key_value_future.bias",
    "attention.null_key",
    "attention.null_bias",
    "attention.temporal_gain",
}


def _open_weights(model: nn.Module, seed: int) -> None:
    """Perturb every parameter so WSR's zero-initialized paths are active."""
    generator = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn(parameter.shape, generator=generator) * 0.02)


def _open_temporal(model: RSR, seed: int, value_scale: float = 0.1) -> None:
    """Randomise the temporal values, their gain and the null token."""
    generator = torch.Generator().manual_seed(seed)
    attention = model.attention
    rows = attention.query_channels
    with torch.no_grad():
        for projection in (attention.key_value_past, attention.key_value_future):
            projection.weight[rows:].copy_(
                torch.randn(projection.weight[rows:].shape, generator=generator)
                * value_scale
            )
            projection.bias[rows:].copy_(
                torch.randn(projection.bias[rows:].shape, generator=generator)
                * value_scale
            )
        attention.temporal_gain.copy_(
            1 + 0.25 * torch.randn(attention.temporal_gain.shape, generator=generator)
        )
        attention.null_key.copy_(
            torch.randn(attention.null_key.shape, generator=generator)
        )
        attention.null_bias.copy_(
            torch.randn(attention.null_bias.shape, generator=generator)
        )


def _pair(scale: int, seed: int = 0) -> tuple[nn.Module, RSR]:
    """A WSR Compact with open weights and an RSR holding the same weights."""
    torch.manual_seed(seed)
    wsr = wsr_compact(scale=scale).eval()
    _open_weights(wsr, seed + 1)
    rsr = rsr_compact(scale=scale).eval()
    rsr.load_state_dict(wsr.state_dict(), strict=False)
    return wsr, rsr


def _temporal_model(scale: int = 2, seed: int = 0, value_scale: float = 0.1) -> RSR:
    _, rsr = _pair(scale, seed)
    _open_temporal(rsr, seed + 2, value_scale)
    return rsr


def _clip(batch: int, frames: int, height: int, width: int, seed: int) -> Tensor:
    generator = torch.Generator().manual_seed(seed)
    return torch.rand(batch, frames, 3, height, width, generator=generator)


def _chain(model: RSR, clip: Tensor) -> Tensor:
    """The two sweeps written out with encode / step_encoded."""
    frames = [clip[:, t] for t in range(clip.shape[1])]
    encoded = [model.encode(frame) for frame in frames]
    reverse: dict[int, Tensor] = {}
    for t in range(len(frames) - 1, 0, -1):
        _, reverse[t] = model.step_encoded(
            frames[t], encoded[t], future=reverse.get(t + 1), output=False
        )
    outputs: list[Tensor] = []
    past: Tensor | None = None
    for t in range(len(frames)):
        output, past = model.step_encoded(
            frames[t], encoded[t], past, reverse.get(t + 1)
        )
        assert output is not None
        outputs.append(output)
    return torch.stack(outputs, dim=1)


@pytest.mark.parametrize("scale", [1, 2, 4])
def test_keys_extend_wsr_compact(scale: int) -> None:
    wsr = wsr_compact(scale=scale).state_dict()
    rsr = rsr_compact(scale=scale).state_dict()
    assert set(rsr) - set(wsr) == NEW_KEYS
    assert all(rsr[k].shape == v.shape for k, v in wsr.items())
    result = rsr_compact(scale=scale).load_state_dict(wsr, strict=False)
    assert set(result.missing_keys) == NEW_KEYS
    assert not result.unexpected_keys


@pytest.mark.parametrize("scale", [1, 2, 4])
@pytest.mark.parametrize("size", [(32, 64), (37, 45)])
def test_zero_start_equals_wsr_compact(scale: int, size: tuple[int, int]) -> None:
    wsr, rsr = _pair(scale)
    clip = _clip(2, 3, *size, seed=scale)
    with torch.no_grad():
        result = rsr(clip)
        assert result.shape == (2, 3, 3, size[0] * scale, size[1] * scale)
        for t in range(clip.shape[1]):
            frame = clip[:, t].contiguous()
            expected = wsr(frame)
            assert torch.equal(result[:, t], expected)
            assert torch.equal(rsr(frame), expected)


def test_forward_equals_hand_chain_and_reads_both_ways() -> None:
    model = _temporal_model()
    clip = _clip(2, 4, 37, 45, seed=3)
    with torch.no_grad():
        result = model(clip)
        assert torch.equal(result, _chain(model, clip))
        last = clip.clone()
        last[:, -1] = torch.rand_like(last[:, -1])
        first = clip.clone()
        first[:, 0] = torch.rand_like(first[:, 0])
        assert not torch.equal(model(last)[:, 0], result[:, 0])
        assert not torch.equal(model(first)[:, -1], result[:, -1])
        # The temporal path is active: frames differ from the no-neighbour result.
        assert not torch.equal(result[:, 1], model(clip[:, 1].contiguous()))


def test_absent_equals_masked() -> None:
    model = _temporal_model()
    clip = _clip(2, 3, 37, 45, seed=4)
    with torch.no_grad():
        frame = clip[:, 1]
        encoded = model.encode(frame)
        past = model.encode(clip[:, 0])[0]
        future = model.encode(clip[:, 2])[0]
        alone, alone_state = model.step_encoded(frame, encoded)
        none = torch.zeros(2, dtype=torch.bool)
        masked, masked_state = model.step_encoded(
            frame, encoded, past, future, none, none
        )
        assert masked is not None
        assert torch.equal(masked, alone)
        assert torch.equal(masked_state, alone_state)
        # A source absent for one sample only equals omitting it for that sample,
        # up to the summation order of the longer temporal softmax.
        both, _ = model.step_encoded(frame, encoded, past, future)
        only_past, _ = model.step_encoded(frame, encoded, past)
        only_future, _ = model.step_encoded(frame, encoded, None, future)
        assert both is not None and only_past is not None and only_future is not None
        assert not torch.equal(both, only_past)
        assert not torch.equal(both, only_future)
        split = torch.tensor([True, False])
        noise = torch.randn_like(past) * 3
        for mixed_past, mixed_future, mixed_past_valid, mixed_future_valid, omitted in (
            (past, future, None, split, only_past),
            (past, future, split, None, only_future),
        ):
            mixed, _ = model.step_encoded(
                frame,
                encoded,
                mixed_past,
                mixed_future,
                mixed_past_valid,
                mixed_future_valid,
            )
            assert mixed is not None
            assert torch.equal(mixed[0], both[0])
            torch.testing.assert_close(mixed[1], omitted[1], rtol=0, atol=1e-5)
            # The masked source cannot reach the masked sample: exact invariance.
            changed, _ = model.step_encoded(
                frame,
                encoded,
                mixed_past + noise if mixed_past_valid is not None else mixed_past,
                mixed_future + noise
                if mixed_future_valid is not None
                else mixed_future,
                mixed_past_valid,
                mixed_future_valid,
            )
            assert changed is not None
            assert torch.equal(changed[1], mixed[1])
            assert not torch.equal(changed[0], mixed[0])


def test_shot_ids_cut_the_state() -> None:
    model = _temporal_model()
    clip = _clip(2, 4, 32, 40, seed=5)
    with torch.no_grad():
        distinct = torch.arange(8).view(2, 4)
        result = model(clip, distinct)
        for t in range(4):
            assert torch.equal(result[:, t], model(clip[:, t].contiguous()))
        # Sample 0 changes shot after frame 1; sample 1 is one shot.
        shots = torch.tensor([[0, 0, 1, 1], [5, 5, 5, 5]])
        result = model(clip, shots)
        whole = model(clip)
        head = model(clip[:, :2])
        tail = model(clip[:, 2:])
        # Masked versus omitted tokens: equal up to softmax summation order.
        torch.testing.assert_close(result[0, :2], head[0], rtol=0, atol=1e-5)
        torch.testing.assert_close(result[0, 2:], tail[0], rtol=0, atol=1e-5)
        assert torch.equal(result[1], whole[1])
        assert not torch.equal(result[0], whole[0])
        # Isolation is exact: one half's content never reaches the other half.
        other = clip.clone()
        other[0, 2:] = torch.rand_like(other[0, 2:])
        changed = model(other, shots)
        assert torch.equal(changed[0, :2], result[0, :2])
        assert not torch.equal(changed[0, 2:], result[0, 2:])
        other = clip.clone()
        other[0, :2] = torch.rand_like(other[0, :2])
        changed = model(other, shots)
        assert torch.equal(changed[0, 2:], result[0, 2:])
        assert torch.equal(changed[1], result[1])


@pytest.mark.parametrize(
    ("chunk", "lookahead"), [(1, 5), (2, 5), (3, 5), (5, 5), (2, 3), (4, 1)]
)
def test_infer_equals_forward_when_covered(chunk: int, lookahead: int) -> None:
    model = _temporal_model()
    clip = _clip(2, 5, 24, 40, seed=6)
    with torch.no_grad():
        expected = model(clip)
    assert torch.equal(model.infer(clip, chunk, lookahead), expected)


def test_infer_with_shot_ids_and_short_lookahead() -> None:
    model = _temporal_model()
    clip = _clip(2, 6, 24, 40, seed=7)
    shots = torch.tensor([[0, 0, 0, 1, 1, 1], [2, 2, 2, 2, 2, 2]])
    with torch.no_grad():
        assert torch.equal(model.infer(clip, 2, 4, shots), model(clip, shots))
        short = model.infer(clip, 2, 1)
        assert short.shape == (2, 6, 3, 48, 80)
        # The first chunk sees exactly the clip up to its look-ahead.
        assert torch.equal(short[:, :2], model(clip[:, :3])[:, :2])


def test_temporal_read_is_bounded_by_the_gain() -> None:
    model = _temporal_model()
    attention = model.attention
    clip = _clip(2, 2, 37, 45, seed=11)
    bound = float(attention.temporal_gain.detach().abs().max())
    with torch.no_grad():
        current = model.encode(clip[:, 1])[0]
        state = model.encode(clip[:, 0])[0]
        own = attention(current)
        for factor in (1.0, 1000.0):
            read = attention(current, state * factor, -state * factor) - own
            assert torch.isfinite(read).all()
            assert float(read.abs().max()) > 0
            # The subtraction of the own read adds rounding of its magnitude.
            assert float(read.abs().max()) <= bound + 1e-5 * float(own.abs().max())


def test_long_chain_state_stays_bounded() -> None:
    model = _temporal_model(value_scale=1.0)
    clip = _clip(1, 48, 16, 16, seed=12)
    with torch.no_grad():
        output = model.infer(clip, chunk=16, lookahead=8)
        assert torch.isfinite(output).all()
        # The forward recurrence alone, its state read back every frame.
        norms: list[float] = []
        state: Tensor | None = None
        for t in range(clip.shape[1]):
            frame = clip[:, t]
            _, state = model.step_encoded(frame, model.encode(frame), state, state)
            norms.append(float(state.norm()))
    middle = sum(norms[12:24]) / 12
    last = sum(norms[36:]) / 12
    assert all(math.isfinite(n) for n in norms)
    assert last < 1.25 * middle


def test_export_copy_matches() -> None:
    model = _temporal_model()
    clip = _clip(2, 3, 37, 45, seed=8)
    exported = copy.deepcopy(model).eval().prepare_for_export()
    assert isinstance(exported, RSR)
    with torch.no_grad():
        expected = model(clip)
        torch.testing.assert_close(exported(clip), expected, rtol=0, atol=1e-4)
        encoded = exported.encode(clip[:, 1])
        state = exported.encode(clip[:, 0])[0]
        output, _ = exported.step_encoded(clip[:, 1], encoded, state, state)
        assert output is not None
        assert output.shape == (2, 3, 74, 90)


def test_gradients_reach_temporal_values() -> None:
    torch.manual_seed(9)
    model = rsr_compact(scale=2).train()
    clip = _clip(2, 3, 32, 32, seed=9)
    output = model(clip)
    assert output.shape == (2, 3, 3, 64, 64)
    output.square().mean().backward()
    rows = model.attention.query_channels
    for projection in (
        model.attention.key_value_past,
        model.attention.key_value_future,
    ):
        assert projection.weight.grad is not None
        assert projection.weight.grad[rows:].abs().sum() > 0
    assert all(
        torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None
    )


# Memory-saving clip training: backward_clip().


def _frame_loss(targets: Tensor) -> Callable[[Tensor, int], Tensor]:
    def loss(output: Tensor, t: int) -> Tensor:
        # A detached leaf: the loss cannot reach the model through it.
        assert output.requires_grad and output.grad_fn is None
        return (output - targets[:, t]).square().mean() * (1.0 + 0.5 * t)

    return loss


def _gradients(model: nn.Module) -> dict[str, Tensor | None]:
    return {
        name: None if p.grad is None else p.grad.clone()
        for name, p in model.named_parameters()
    }


def _assert_gradients(
    actual: dict[str, Tensor | None],
    expected: dict[str, Tensor | None],
    relative: float = 2e-4,
) -> None:
    assert actual.keys() == expected.keys()
    for name, value in expected.items():
        other = actual[name]
        if value is None:
            assert other is None or not other.any(), name
        else:
            assert other is not None, name
            # Summed weight gradients carry the rounding of their largest terms.
            atol = relative / 200 + relative * float(value.abs().max())
            torch.testing.assert_close(
                other,
                value,
                rtol=relative / 2,
                atol=atol,
                msg=lambda m, name=name: f"{name}: {m}",
            )


def _reference(
    model: RSR, frames: Tensor, targets: Tensor, shot_ids: Tensor | None
) -> tuple[Tensor, dict[str, Tensor | None], Tensor]:
    """forward() plus one backward of the summed per-frame losses."""
    model.zero_grad(set_to_none=True)
    leaf = frames.clone().requires_grad_()
    output = model(leaf, shot_ids)
    total = sum(
        (
            (output[:, t] - targets[:, t]).square().mean() * (1.0 + 0.5 * t)
            for t in range(frames.shape[1])
        ),
        torch.zeros(()),
    )
    total.backward()
    assert leaf.grad is not None
    gradients = _gradients(model)
    model.zero_grad(set_to_none=True)
    return output.detach(), gradients, leaf.grad


def _clip_case(
    model: RSR,
    frames: Tensor,
    shot_ids: Tensor | None,
    keep: str,
    functions: StepFunctions | None = None,
    relative: float = 2e-4,
) -> None:
    targets = torch.rand(
        *frames.shape[:3],
        frames.shape[3] * model.scale,
        frames.shape[4] * model.scale,
        dtype=frames.dtype,
    )
    expected, expected_gradients, expected_input = _reference(
        model, frames, targets, shot_ids
    )
    leaf = frames.clone().requires_grad_()
    output = model.backward_clip(
        leaf,
        _frame_loss(targets),
        shot_ids=shot_ids,
        keep=keep,
        functions=functions,
        encode_chunk=3,
        grad_chunk=2,
    )
    assert not output.requires_grad
    torch.testing.assert_close(
        output, expected, rtol=relative / 10, atol=relative / 100
    )
    _assert_gradients(
        {**_gradients(model), "frames": leaf.grad},
        {**expected_gradients, "frames": expected_input},
        relative,
    )
    model.zero_grad(set_to_none=True)


CUT_FIVE = [[0, 0, 1, 1, 1], [3, 3, 3, 3, 4]]


@pytest.mark.parametrize("keep", ["none", "reverse", "both"])
@pytest.mark.parametrize(
    ("frames", "size", "shots"),
    [
        (1, (24, 32), None),
        (2, (24, 32), None),
        (4, (24, 32), None),
        (5, (24, 32), CUT_FIVE),
        (4, (21, 27), None),
        # Several 32-pixel tiles in width, neither side divisible by four.
        (3, (37, 70), [[0, 1, 1], [5, 5, 5]]),
    ],
)
def test_backward_clip_matches_autograd(
    keep: str, frames: int, size: tuple[int, int], shots: list[list[int]] | None
) -> None:
    model = _temporal_model(scale=2).train()
    clip = _clip(2, frames, *size, seed=10 + frames)
    shot_ids = None if shots is None else torch.tensor(shots)
    _clip_case(model, clip, shot_ids, keep)


@pytest.mark.parametrize("keep", ["none", "reverse", "both"])
def test_backward_clip_is_exact_in_float64(keep: str) -> None:
    # FP64 removes the FP32 rounding: the procedure itself is exact.
    model = _temporal_model(scale=2).train().double()
    clip = _clip(2, 5, 21, 27, seed=40).double()
    _clip_case(model, clip, torch.tensor(CUT_FIVE), keep, relative=1e-9)


def test_backward_clip_eval_mode() -> None:
    model = _temporal_model(scale=2).eval()
    _clip_case(model, _clip(2, 4, 24, 32, seed=20), None, "none")


def test_backward_clip_accumulates_and_frees() -> None:
    model = _temporal_model(scale=2).train()
    clip = _clip(2, 4, 24, 32, seed=21)
    targets = torch.rand(2, 4, 3, 48, 64)
    _, expected, _ = _reference(model, clip, targets, None)
    for _ in range(2):
        model.backward_clip(clip, _frame_loss(targets), keep="none")
    twice = {
        name: None if value is None else 2 * value for name, value in expected.items()
    }
    _assert_gradients(_gradients(model), twice)


def test_step_functions_are_wrapped_once_and_reused() -> None:
    # FP64: at FP32 the T=3 clip's frame gradient differs in 18 of 13824
    # elements between the masked and the omitted neighbour, most likely a
    # ReLU input close to zero; FP64 checks the procedure without that noise.
    model = _temporal_model(scale=2).train().double()
    wrapped: list[str] = []
    calls: dict[str, int] = {}

    def compile_counting(function: Callable) -> Callable:
        name = function.__name__
        wrapped.append(name)
        calls[name] = 0

        def counted(*args: object) -> object:
            calls[name] += 1
            return function(*args)

        return counted

    functions = model.step_functions(compile_counting)
    assert sorted(wrapped) == ["encode", "forward_state", "full", "reverse"]

    def no_rebuild(compile: Callable | None = None) -> StepFunctions:
        raise AssertionError("backward_clip built its step functions again")

    model.step_functions = no_rebuild
    for count in (3, 5):
        before = dict(calls)
        clip = _clip(2, count, 24, 32, seed=30 + count).double()
        _clip_case(model, clip, None, "none", functions, relative=1e-9)
        # The wrapped callables are the ones called, every one of them.
        assert all(calls[name] > before[name] for name in calls)
    assert len(wrapped) == 4


def test_infer_with_shot_changes_on_chunk_edges() -> None:
    model = _temporal_model()
    clip = _clip(2, 6, 24, 40, seed=7)
    with torch.no_grad():
        # A short look-ahead is exact only where every sample cuts at the edge.
        for shots, settings in (
            ([[0, 0, 0, 1, 1, 1], [2, 2, 2, 3, 3, 3]], ((3, 3), (3, 4), (3, 1))),
            ([[0, 0, 0, 1, 1, 1], [2, 2, 2, 2, 2, 2]], ((3, 3), (3, 4))),
        ):
            shot_ids = torch.tensor(shots)
            expected = model(clip, shot_ids)
            for chunk, lookahead in settings:
                actual = model.infer(clip, chunk, lookahead, shot_ids)
                assert torch.equal(actual, expected), (shots, chunk, lookahead)
        # Every chunk edge is a shot change: no look-ahead is needed at all.
        shot_ids = torch.tensor([[0, 0, 1, 1, 2, 2], [3, 3, 4, 4, 5, 5]])
        expected = model(clip, shot_ids)
        actual = model.infer(clip, 2, 0, shot_ids)
        # The chunk's end omits the future that forward() masks: rounding only.
        torch.testing.assert_close(actual, expected, rtol=0, atol=1e-5)


def test_backward_clip_under_bf16_autocast() -> None:
    model = _temporal_model(scale=2).train()
    clip = _clip(1, 3, 24, 32, seed=50)
    targets = torch.rand(1, 3, 3, 48, 64)

    def loss(output: Tensor, t: int) -> Tensor:
        return (output.float() - targets[:, t]).abs().mean()

    output = model.backward_clip(
        clip,
        loss,
        autocast=lambda: torch.autocast("cpu", dtype=torch.bfloat16),
    )
    assert torch.isfinite(output).all()
    for name, parameter in model.named_parameters():
        if not parameter.requires_grad:
            continue  # Conv3XC's cached eval convolution is never trained.
        assert parameter.grad is not None, name
        assert torch.isfinite(parameter.grad).all(), name
