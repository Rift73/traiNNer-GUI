from pathlib import Path
from unittest.mock import Mock

import pytest
from studio import run_process
from studio.server import Services
from studio.workspace import PROJECT_DIR_ENV, PROJECT_ID_ENV


def test_queue_reorder_persists_and_dispatches_new_order(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv(PROJECT_DIR_ENV, raising=False)
    monkeypatch.delenv(PROJECT_ID_ENV, raising=False)
    monkeypatch.setattr(run_process, "cli_trainer_running", lambda: False)
    state = tmp_path / "state"
    services = Services(tmp_path, state)

    def stop_at_launch(
        attempt: Path, _lease: int, experiment: Path, *_args: object, **_kwargs: object
    ) -> None:
        experiment.mkdir(parents=True)
        run_process.write_record(attempt / "result.json", {"status": "stopped"})

    launch = Mock(side_effect=stop_at_launch)
    monkeypatch.setattr(run_process, "launch", launch)

    def pending_ids(snapshot: dict) -> list[str]:
        pending = (
            entry for entry in snapshot["entries"] if entry["status"] == "pending"
        )
        return [
            entry["id"] for entry in sorted(pending, key=lambda entry: entry["order"])
        ]

    for name in ("queue-first", "queue-second", "queue-third"):
        entry = services.post(
            "/api/queue",
            {
                "yaml": f"name: {name}\nnetwork_g: {{type: compact}}\npath: {{}}\n"
                "train: {total_iter: 100}\n"
            },
        )
        services.post("/api/queue/release", {"id": entry["id"]})

    displayed_order = pending_ids(services.get("/api/queue", {}))
    first, second, third = displayed_order
    new_order = [third, first, second]
    route = "/api/queue/reorder"
    request = {"expected": displayed_order, "order": new_order}
    snapshot = services.post(route, request)
    assert pending_ids(snapshot) == new_order
    retry_snapshot = services.post(route, request)
    assert pending_ids(retry_snapshot) == new_order

    stale_request = {"expected": displayed_order, "order": [second, first, third]}
    with pytest.raises(FileExistsError):
        services.post(route, stale_request)
    with pytest.raises(ValueError):
        services.post(route, {"expected": new_order, "order": [third, first, first]})

    reopened = Services(tmp_path, state)
    assert pending_ids(reopened.get("/api/queue", {})) == new_order
    monkeypatch.setattr(reopened.queue, "prepare", lambda text: text)
    launch.assert_not_called()

    dispatched = reopened.queue.dispatch_once()
    assert dispatched is not None
    assert dispatched["id"] == third
    launch.assert_called_once()
    assert reopened.runs.detail(dispatched["runId"])["queueEntryId"] == third
