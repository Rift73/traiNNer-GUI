"""Recurrent DUAL clip procedure: backward_clip() against forward() plus autograd."""

import weakref
from collections import Counter
from collections.abc import Callable
from typing import Any

import pytest
import torch
from torch import Tensor
from traiNNer.archs import rdual_arch
from traiNNer.archs.rdual_arch import RDUAL

torch.set_num_threads(4)

KEEPS = ("none", "reverse", "both")
Grads = dict[str, Tensor]


def make_model() -> RDUAL:
    torch.manual_seed(5)
    model = RDUAL(scale=2, use_checkpoint=True).train()
    with torch.no_grad():
        model.temporal.output.weight.normal_(std=0.02)
        model.temporal.cosine.normal_(std=0.01)
        model.temporal.sine.normal_(std=0.01)
    return model


def make_clip(
    batch: int, count: int, height: int = 8, width: int = 8
) -> tuple[Tensor, Tensor, Tensor]:
    generator = torch.Generator().manual_seed(17 + count)
    frames = torch.rand(batch, count, 3, height, width, generator=generator)
    guidance = (
        torch.randn(
            batch,
            count - 1,
            2,
            2,
            ((height + 3) // 4) * 2,
            ((width + 3) // 4) * 2,
            generator=generator,
        )
        * 0.6
    )
    targets = torch.rand(batch, count, 3, 2 * height, 2 * width, generator=generator)
    return frames, guidance, targets


def frame_loss(targets: Tensor) -> Callable[[Tensor, int], Tensor]:
    def loss(output: Tensor, t: int) -> Tensor:
        error = ((output - targets[:, t]).square() + 1e-12).sqrt().mean()
        return error * (1.0 + 0.75 * t)

    return loss


def grads(model: RDUAL) -> Grads:
    return {
        name: parameter.grad.clone()
        for name, parameter in model.named_parameters()
        if parameter.grad is not None
    }


def reference(
    model: RDUAL,
    frames: Tensor,
    guidance: Tensor,
    loss: Callable[[Tensor, int], Tensor],
    **validity: Tensor,
) -> tuple[Tensor, Grads, Tensor]:
    model.zero_grad(set_to_none=True)
    x = frames.clone().requires_grad_()
    out = model(x, guidance, **validity)
    total = sum(loss(out[:, t], t) for t in range(frames.shape[1]))
    assert isinstance(total, Tensor)
    total.backward()
    assert x.grad is not None
    return out.detach(), grads(model), x.grad.clone()


def procedure(
    model: RDUAL,
    frames: Tensor,
    guidance: Tensor,
    loss: Callable[[Tensor, int], Tensor],
    **options: Any,
) -> tuple[Tensor, Grads, Tensor]:
    model.zero_grad(set_to_none=True)
    x = frames.clone().requires_grad_()
    out = model.backward_clip(x, guidance, loss, **options)
    assert x.grad is not None
    return out, grads(model), x.grad.clone()


def relative(x: Tensor, y: Tensor) -> float:
    return ((x - y).norm() / y.norm().clamp_min(1e-12)).item()


def check(
    name: str, got: tuple[Tensor, Grads, Tensor], want: tuple[Tensor, Grads, Tensor]
) -> None:
    out, parameters, inputs = got
    want_out, want_parameters, want_inputs = want
    assert out.shape == want_out.shape and not out.requires_grad
    extra = [n for n, g in parameters.items() if n not in want_parameters and g.any()]
    assert not extra, extra
    missing = [n for n in want_parameters if n not in parameters]
    assert not missing, missing
    worst = max(relative(parameters[n], g) for n, g in want_parameters.items())
    errors = (worst, relative(inputs, want_inputs), relative(out, want_out))
    print(
        f"RELERR {name} parameter {errors[0]:.3g} input {errors[1]:.3g} output {errors[2]:.3g}"
    )
    assert errors[0] <= 1e-5 and errors[1] <= 1e-5 and errors[2] <= 1e-6, errors


VALIDITY = {
    "plain": lambda batch: {},
    "scene_cut": lambda batch: {"shot_ids": torch.tensor([[0, 0, 1, 1]] * batch)},
    "invalid_frame": lambda batch: {
        "frame_valid": torch.tensor([[True, True, False, True]] * batch)
    },
    "mixed_batch": lambda batch: {
        "frame_valid": torch.tensor(
            [[True, True, True, True], [True, False, True, True]]
        ),
        "shot_ids": torch.tensor([[0, 1, 1, 1], [0, 0, 0, 0]]),
    },
}


@pytest.mark.parametrize("scenario", list(VALIDITY))
@pytest.mark.parametrize("keep", KEEPS)
def test_matches_forward(keep: str, scenario: str) -> None:
    model = make_model()
    batch = 2 if scenario == "mixed_batch" else 1
    frames, guidance, targets = make_clip(batch, 4)
    validity = VALIDITY[scenario](batch)
    loss = frame_loss(targets)
    want = reference(model, frames, guidance, loss, **validity)
    got = procedure(model, frames, guidance, loss, keep=keep, **validity)
    check(f"keep={keep} {scenario}", got, want)


@pytest.mark.parametrize("keep", KEEPS)
def test_matches_forward_with_cue_bias(keep: str) -> None:
    model = make_model()
    with torch.no_grad():
        model.temporal.key.weight[31::32].normal_(std=0.02)
        model.temporal.cue_score[2].weight.normal_(std=0.5)
        model.temporal.cue_score[2].bias.normal_(std=0.5)
    frames, guidance, targets = make_clip(1, 4)
    loss = frame_loss(targets)
    want = reference(model, frames, guidance, loss)
    assert want[1]["temporal.cue_score.0.weight"].abs().sum() > 0
    got = procedure(model, frames, guidance, loss, keep=keep)
    check(f"keep={keep} cue bias", got, want)


@pytest.mark.parametrize("keep", KEEPS)
def test_padded_frames(keep: str) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 3, height=10, width=6)
    loss = frame_loss(targets)
    want = reference(model, frames, guidance, loss)
    got = procedure(model, frames, guidance, loss, keep=keep)
    check(f"keep={keep} padded 10x6", got, want)


@pytest.mark.parametrize(
    ("encode_chunk", "grad_chunk"), [(5, 1), (5, 2), (5, 5), (2, 3), (3, 7)]
)
@pytest.mark.parametrize("keep", KEEPS)
def test_five_frames_chunks(keep: str, encode_chunk: int, grad_chunk: int) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 5)
    validity = {"shot_ids": torch.tensor([[0, 0, 0, 1, 1]])}
    loss = frame_loss(targets)
    want = reference(model, frames, guidance, loss, **validity)
    got = procedure(
        model,
        frames,
        guidance,
        loss,
        keep=keep,
        encode_chunk=encode_chunk,
        grad_chunk=grad_chunk,
        **validity,
    )
    check(f"keep={keep} T=5 encode={encode_chunk} grad={grad_chunk}", got, want)


@pytest.mark.parametrize("keep", KEEPS)
def test_loss_called_once_per_frame(keep: str) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    inner = frame_loss(targets)
    calls: list[int] = []

    def loss(output: Tensor, t: int) -> Tensor:
        assert output.shape == (1, 3, 16, 16)
        calls.append(t)
        return inner(output, t)

    procedure(model, frames, guidance, loss, keep=keep)
    assert sorted(calls) == [0, 1, 2, 3]


@pytest.mark.parametrize("keep", ["all", "None"])
def test_invalid_keep(keep: str) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    with pytest.raises(ValueError, match="keep"):
        model.backward_clip(frames, guidance, frame_loss(targets), keep=keep)


@pytest.mark.parametrize("keep", KEEPS)
def test_gradients_accumulate(keep: str) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    loss = frame_loss(targets)
    _, once, once_input = procedure(model, frames, guidance, loss, keep=keep)
    model.zero_grad(set_to_none=True)
    x = frames.clone().requires_grad_()
    for _ in range(2):
        model.backward_clip(x, guidance, loss, keep=keep)
    twice = grads(model)
    assert set(twice) == set(once)
    worst = max(relative(twice[n], 2 * g) for n, g in once.items())
    assert worst <= 1e-6, worst
    assert x.grad is not None and relative(x.grad, 2 * once_input) <= 1e-6


@pytest.mark.parametrize("keep", KEEPS)
def test_wrapped_functions(keep: str) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    loss = frame_loss(targets)
    calls: Counter[str] = Counter()

    def counting(function: Callable) -> Callable:
        name = getattr(function, "__name__", "")

        def wrapped(*args: object) -> object:
            calls[name] += 1
            return function(*args)

        return wrapped

    eager = procedure(
        model, frames, guidance, loss, keep=keep, functions=model.step_functions()
    )
    wrapped = procedure(
        model,
        frames,
        guidance,
        loss,
        keep=keep,
        functions=model.step_functions(counting),
    )
    check(f"keep={keep} wrapped", wrapped, eager)
    assert calls["encode"] == 1 + 2  # one no-gradient call, two gradient chunks
    assert calls["compose_kernels"] == 2  # on entry and again on exit
    assert calls["full"] == 4
    assert calls["reverse"] == (6 if keep == "none" else 3)
    assert calls["forward_state"] == (0 if keep == "both" else 3)


@pytest.mark.parametrize("keep", KEEPS)
def test_loss_graph_released_before_the_next_frame(keep: str) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    inner = frame_loss(targets)
    previous: list[weakref.ref[Tensor]] = []

    def loss(output: Tensor, t: int) -> Tensor:
        assert all(ref() is None for ref in previous)
        value = inner(output, t)
        previous.append(weakref.ref(value))
        return value

    procedure(model, frames, guidance, loss, keep=keep)
    assert all(ref() is None for ref in previous)


@pytest.mark.parametrize("keep", KEEPS)
def test_frames_without_gradients(keep: str) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    loss = frame_loss(targets)
    want = reference(model, frames, guidance, loss)
    model.zero_grad(set_to_none=True)
    out = model.backward_clip(frames, guidance, loss, keep=keep)
    assert frames.grad is None
    worst = max(
        relative(p.grad, want[1][n])
        for n, p in model.named_parameters()
        if n in want[1]
    )
    assert worst <= 1e-5 and relative(out, want[0]) <= 1e-6, worst


def step(model: RDUAL, frame: Tensor, *args: Tensor | None) -> tuple[Tensor, Tensor]:
    """One 8x8 frame, whose padded output is already its own size."""
    out, state = model.step_encoded(model.encode(frame), *args)
    assert out is not None
    return out, state


def frame_by_frame(model: RDUAL, frames: Tensor) -> None:
    state = None
    for t in range(frames.shape[1]):
        flow = torch.zeros(1, 5, 4, 4) if t else None
        out, state = step(model, frames[:, t], state, flow)
        out.square().mean().backward()
        state = state.detach()


def test_fold_cache_recomposes_on_exit_and_keeps_its_guard() -> None:
    model = make_model()
    frames = torch.rand(1, 3, 3, 8, 8)
    model.zero_grad(set_to_none=True)
    frame_by_frame(model, frames)
    want = grads(model)
    calls: list[bool] = []

    def compose() -> list[Tensor]:
        calls.append(torch.is_grad_enabled())
        return model.compose_kernels()

    model.zero_grad(set_to_none=True)
    with model.fold_cache(compose):
        frame_by_frame(model, frames)
    assert calls == [False, True]
    got = grads(model)
    assert set(got) == set(want)
    assert max(relative(got[n], g) for n, g in want.items()) <= 1e-5
    folded = [
        m for m in model.modules() if isinstance(m, rdual_arch.EDBBReparamConv3x3)
    ]
    assert all(
        m.fold_kernel.grad is None and not m.fold_kernel.requires_grad for m in folded
    )

    calls.clear()
    model.zero_grad(set_to_none=True)
    with torch.no_grad():
        plain = step(model, frames[:, 0])[0]
        with model.fold_cache(compose):
            torch.testing.assert_close(
                step(model, frames[:, 0])[0], plain, rtol=0, atol=1e-6
            )
    assert calls == [False]
    assert all(p.grad is None for p in model.parameters())

    calls.clear()
    with (
        pytest.raises(RuntimeError, match="without a backward"),
        model.fold_cache(compose),
    ):
        step(model, frames[:, 0])
    assert calls == [False]


def run_logged(
    model: RDUAL, keep: str, monkeypatch: pytest.MonkeyPatch, marks: bool
) -> tuple[list[str], tuple[Tensor, Grads, Tensor]]:
    log: list[str] = []

    def logging(function: Callable) -> Callable:
        name = getattr(function, "__name__", "")

        def wrapped(*args: object) -> object:
            log.append(name)
            return function(*args)

        return wrapped

    monkeypatch.setattr(
        torch.compiler, "cudagraph_mark_step_begin", lambda: log.append("mark")
    )
    if marks:
        monkeypatch.setattr(rdual_arch, "_marks_cuda_graph_steps", lambda frames: True)
    frames, guidance, targets = make_clip(1, 4)
    got = procedure(
        model,
        frames,
        guidance,
        frame_loss(targets),
        keep=keep,
        functions=model.step_functions(logging),
    )
    return log, got


def test_no_step_marks_for_cpu_frames(monkeypatch: pytest.MonkeyPatch) -> None:
    log, _ = run_logged(make_model(), "none", monkeypatch, marks=False)
    assert "mark" not in log and log


def marked(*names: str) -> list[str]:
    return [item for name in names for item in ("mark", name)]


STEP_ORDER = {
    "none": marked("compose_kernels", "encode")
    + marked(*["reverse"] * 3, *["forward_state"] * 3, *["full"] * 4, *["reverse"] * 3)
    + marked("encode", "encode", "compose_kernels"),
    "reverse": marked("compose_kernels", "encode")
    + ["reverse"] * 3
    + ["forward_state"] * 3
    + ["full"] * 4
    + marked("encode", "encode", "compose_kernels"),
    "both": marked("compose_kernels", "encode")
    + ["reverse"] * 3
    + ["full"] * 4
    + marked("encode", "encode", "compose_kernels"),
}


@pytest.mark.parametrize("keep", list(STEP_ORDER))
def test_step_marks_follow_the_frames(
    keep: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    want = reference(model, frames, guidance, frame_loss(targets))
    log, got = run_logged(model, keep, monkeypatch, marks=True)
    assert log == STEP_ORDER[keep]
    check(f"keep={keep} marked", got, want)
    assert all(p.grad is not None for p in model.parameters() if p.requires_grad)


def watch_full_steps(
    monkeypatch: pytest.MonkeyPatch,
) -> tuple[list[tuple[tuple[Tensor, ...], set[int]]], Callable]:
    """Steps marked per frame; at each full step, its flattened arguments and
    the ids of the leaves made so far that already hold a gradient buffer."""
    made: list[Tensor] = []
    calls: list[tuple[tuple[Tensor, ...], set[int]]] = []
    original = Tensor.requires_grad_

    def requires_grad_(self: Tensor, requires_grad: bool = True) -> Tensor:
        made.append(self)
        return original(self, requires_grad)

    monkeypatch.setattr(Tensor, "requires_grad_", requires_grad_)

    def watching(function: Callable) -> Callable:
        if getattr(function, "__name__", "") != "full":
            return function

        def wrapped(*args: Any) -> object:
            buffered = {id(x) for x in made if x.grad is not None}
            calls.append((tuple(flatten(args)), buffered))
            return function(*args)

        return wrapped

    monkeypatch.setattr(rdual_arch, "_marks_cuda_graph_steps", lambda frames: True)
    monkeypatch.setattr(torch.compiler, "cudagraph_mark_step_begin", lambda: None)
    return calls, watching


def test_held_mode_leaves_get_no_gradient_buffers(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    loss = frame_loss(targets)
    want = reference(model, frames, guidance, loss)
    calls, watching = watch_full_steps(monkeypatch)
    got = procedure(
        model,
        frames,
        guidance,
        loss,
        keep="both",
        functions=model.step_functions(watching),
    )
    assert len(calls) == 4
    for args, buffered in calls:
        # Encoded features, the state and the donor.
        leaves = [x for x in args if x.requires_grad]
        assert len(leaves) == 7
        assert not any(id(x) in buffered for x in leaves)
    check("keep=both watched", got, want)


def test_replay_buffers_each_frames_leaves_just_before_its_step(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    loss = frame_loss(targets)
    want = reference(model, frames, guidance, loss)
    calls, watching = watch_full_steps(monkeypatch)
    got = procedure(
        model,
        frames,
        guidance,
        loss,
        keep="none",
        functions=model.step_functions(watching),
    )
    check("keep=none watched", got, want)
    # Frames are replayed last to first.
    order = [3, 2, 1, 0]
    features = {t: args[:5] for t, (args, _) in zip(order, calls, strict=True)}
    for t, (args, buffered) in zip(order, calls, strict=True):
        assert all(id(x) in buffered for x in features[t])
        done = order[: order.index(t)]
        for later in set(order) - set(done) - {t}:
            assert not any(id(x) in buffered for x in features[later]), (t, later)
        # The state and the donor are leaves too.
        leaves = [x for x in args[5:] if x.requires_grad]
        assert len(leaves) == 2
        assert all(id(x) in buffered for x in leaves)


def flatten(value: object) -> list[Tensor]:
    if isinstance(value, Tensor):
        return [value]
    if isinstance(value, tuple | list):
        return [t for item in value for t in flatten(item)]
    return []


def test_nothing_kept_aliases_a_step_output(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Stand-in for a CUDA graph's memory pool: every call overwrites the
    # tensors the previous call returned.
    issued: list[Tensor] = []

    def pooled(function: Callable) -> Callable:
        def wrapped(*args: object) -> object:
            with torch.no_grad():
                for tensor in issued:
                    tensor.detach().fill_(float("nan"))
            issued.clear()
            result = function(*args)
            issued.extend(
                t for t in flatten(result) if not (t.is_leaf and t.requires_grad)
            )
            return result

        return wrapped

    monkeypatch.setattr(rdual_arch, "_marks_cuda_graph_steps", lambda frames: True)
    monkeypatch.setattr(torch.compiler, "cudagraph_mark_step_begin", lambda: None)
    model = make_model()
    frames, guidance, targets = make_clip(1, 4)
    loss = frame_loss(targets)
    want = reference(model, frames, guidance, loss)
    got = procedure(
        model,
        frames,
        guidance,
        loss,
        keep="none",
        functions=model.step_functions(pooled),
    )
    check("pooled", got, want)
