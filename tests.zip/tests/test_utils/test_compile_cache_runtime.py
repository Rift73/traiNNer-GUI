from __future__ import annotations

import pickle
from pathlib import Path
from typing import Any

from traiNNer.utils import compile_cache


def test_dynamo_precompile_cache_is_scoped_by_abi() -> None:
    from torch._dynamo.package import DynamoCache

    first = compile_cache.scope_dynamo_precompile_cache("drft-abi-a")
    repeated = compile_cache.scope_dynamo_precompile_cache("drft-abi-a")
    second = compile_cache.scope_dynamo_precompile_cache("drft-abi-b")

    assert first == repeated
    assert first != second
    assert DynamoCache.path_prefix() == second
    assert Path(second).is_dir()


def test_missing_cached_guard_gradient_is_restored_as_none(
    monkeypatch: Any,
) -> None:
    from torch._dynamo import guards as dynamo_guards

    received_grads: list[Any] = []

    def capture_unpickle_tensor(
        cls: type[Any],
        meta_tensor: Any,
        device: Any,
        pytype: type,
        dispatch_keys_raw: int,
        grad: Any,
    ) -> Any:
        del cls, meta_tensor, device, pytype, dispatch_keys_raw
        received_grads.append(grad)
        return object()

    monkeypatch.setattr(
        dynamo_guards.GuardsStatePickler,
        "_unpickle_tensor",
        classmethod(capture_unpickle_tensor),
    )

    compile_cache.install_dynamo_guard_grad_compatibility()
    sentinel = dynamo_guards._Missing("tensor guard tree")  # noqa: SLF001
    result = dynamo_guards.GuardsStatePickler._unpickle_tensor(  # noqa: SLF001
        object(),
        object(),
        object,
        0,
        sentinel,
    )

    assert result is not None
    assert received_grads == [None]
    method = dynamo_guards.GuardsStatePickler._unpickle_tensor  # noqa: SLF001
    serialized = pickle.dumps(method)
    restored = pickle.loads(serialized)
    assert restored.__func__ is (  # pyright: ignore[reportFunctionMemberAccess]
        method.__func__
    )


def test_static_autotuner_gets_stable_filename(monkeypatch: Any) -> None:
    from torch._inductor.triton_bundler import TritonBundler

    captured: list[tuple[str, Any]] = []

    def capture(cls: type[TritonBundler], key: str, kernel: Any) -> None:
        del cls
        captured.append((key, kernel))

    monkeypatch.setattr(
        TritonBundler,
        "put_static_autotuner",
        classmethod(capture),
    )
    compile_cache.install_stable_triton_autotune_identity()

    class FakeKernel:
        def __init__(self) -> None:
            self.compile_results: list[Any] = []
            self.inductor_meta: dict[str, Any] = {}
            self._could_rblock_scale = False
            self.filename: str | None = None
            self.autotune_cache_info: dict[str, Any] | None = None
            self.save_cache_hook: Any = None

    kernel = FakeKernel()
    TritonBundler.put_static_autotuner("stable-source-key", kernel)

    assert captured == [("stable-source-key", kernel)]
    assert kernel.filename is not None
    assert "stable_autotune_identity_v2" in kernel.filename
    assert Path(kernel.filename).name.startswith("stable-source-key-")
