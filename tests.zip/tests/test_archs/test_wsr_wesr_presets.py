"""CPU checks for the WSR Halo and context-only backbones."""

from __future__ import annotations

import copy
import math
from collections.abc import Iterator

import pytest
import torch
import torch.nn.functional as F  # noqa: N812
from torch import Tensor, nn
from traiNNer.archs.wsr_arch import WESR, BlockTokenAttention, WideContextSR

C1_SHAPES = (
    (1, 3, 1, 1),
    (1, 3, 1, 7),
    (1, 3, 7, 1),
    (1, 3, 7, 9),
    (2, 3, 17, 23),
    (1, 3, 64, 64),
    (1, 3, 65, 65),
    (2, 3, 98, 118),
    (2, 3, 99, 101),
    (2, 3, 130, 190),
)
ATTENTION_CONFIGS = (
    pytest.param(32, 1, id="c32-h1"),
    pytest.param(16, 1, id="c16-h1"),
    pytest.param(48, 3, id="c48-h3"),
    pytest.param(8, 1, id="c8-h1"),
    pytest.param(32, 2, id="c32-h2"),
)


@pytest.fixture(autouse=True)
def bounded_cpu_state() -> Iterator[None]:
    previous_threads = torch.get_num_threads()
    torch.set_num_threads(2)
    try:
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(1024)
            yield
    finally:
        torch.set_num_threads(previous_threads)


def _default(family: str, *, scale: int = 4) -> nn.Module:
    constructor = WideContextSR if family == "wsr" else WESR
    return constructor(scale=scale)


def _small(family: str, scale: int) -> nn.Module:
    dimensions = {"width": 16, "hidden": 32, "context_width": 16, "depth": 4}
    if family == "wsr":
        return WideContextSR(**dimensions, sft_count=2, scale=scale)
    assert family == "wesr"
    return WESR(**dimensions, gates=2, heads=1, scale=scale)


def _activate(model: nn.Module, *, perturb_biases: bool = False) -> None:
    """Activate every zero-initialized branch without any optimizer steps."""
    tensors = [model.merge.weight, model.merge.bias]
    for gate in model.gates:
        tensors.extend((gate.project.weight, gate.project.bias, gate.local_scale))
    attention = getattr(model, "attention", None)
    if attention is not None:
        split = attention.query.out_channels
        tensors.extend(
            (attention.key_value.weight[split:], attention.key_value.bias[split:])
        )
    with torch.random.fork_rng(devices=[]), torch.no_grad():
        torch.manual_seed(31415)
        for tensor in tensors:
            tensor.normal_(0, 0.02)
        if perturb_biases:
            for name, parameter in model.named_parameters():
                if name.endswith("bias"):
                    parameter.uniform_(-0.1, 0.1)
        if attention is not None:
            for head, logit in enumerate(attention.logit_scale):
                logit.fill_(math.log(7 if head % 2 == 0 else 250))


def _plain(model: nn.Module, x: Tensor) -> Tensor:
    if isinstance(model, WESR):
        current = model.stem(x) + model.first_project(F.relu(model.first_expand(x)))
        for block in model.blocks:
            current = block(current)
        return F.pixel_shuffle(model.reconstruct(current) + model.base(x), model.scale)
    shallow = model.stem(x)
    current = shallow
    for block in model.blocks:
        current = block(current)
    return F.pixel_shuffle(
        model.reconstruct(model.deep(current) + shallow), model.scale
    )


def _valid_key_reference(attention: BlockTokenAttention, x: Tensor) -> Tensor:
    """Explicit per-head reference over the real donors in each tile's halo."""
    batch, channels, height, width = x.shape
    heads = attention.logit_scale.numel()
    dimension = channels // heads
    q_channels = channels - heads
    queries = attention.query(x).reshape(batch, heads, dimension - 1, height, width)
    kv = attention.key_value(F.pad(x, (0, (-width) % 4, 0, (-height) % 4)))
    coarse_height, coarse_width = kv.shape[-2:]
    keys = kv[:, :q_channels].reshape(
        batch, heads, dimension - 1, coarse_height, coarse_width
    )
    values = kv[:, q_channels:].reshape(
        batch, heads, dimension, coarse_height, coarse_width
    )
    output = torch.empty_like(x).reshape(batch, heads, dimension, height, width)
    for row in range(0, height, attention.window):
        for col in range(0, width, attention.window):
            bottom = min(row + attention.window, height)
            right = min(col + attention.window, width)
            key_row, key_col = max(0, row // 4 - 4), max(0, col // 4 - 4)
            key_bottom = min(coarse_height, (row + attention.window) // 4 + 4)
            key_right = min(coarse_width, (col + attention.window) // 4 + 4)
            for head in range(heads):
                query = queries[:, head, :, row:bottom, col:right].flatten(2)
                query = query.transpose(1, 2)
                key = keys[
                    :,
                    head,
                    :,
                    key_row:key_bottom,
                    key_col:key_right,
                ].flatten(2)
                value = (
                    values[
                        :,
                        head,
                        :,
                        key_row:key_bottom,
                        key_col:key_right,
                    ]
                    .flatten(2)
                    .transpose(1, 2)
                )
                query = query / query.square().sum(-1, keepdim=True).sqrt().clamp_min(
                    1e-6
                )
                key = key / key.square().sum(1, keepdim=True).sqrt().clamp_min(1e-6)
                scale = attention.logit_scale[head].clamp(max=math.log(100)).exp()
                result = ((query @ key) * scale).softmax(-1) @ value
                output[:, head, :, row:bottom, col:right] = result.transpose(
                    1, 2
                ).reshape(batch, dimension, bottom - row, right - col)
    return output.reshape_as(x)


def _activate_attention(attention: BlockTokenAttention) -> None:
    with torch.no_grad():
        split = attention.query.out_channels
        attention.key_value.weight[split:].normal_(0, 0.02)
        attention.key_value.bias[split:].uniform_(-0.1, 0.1)
        for head, logit in enumerate(attention.logit_scale):
            logit.fill_(math.log(7 if head % 2 == 0 else 250))


@pytest.mark.parametrize("family", ("wsr", "wesr"))
@pytest.mark.parametrize("scale", (1, 2))
def test_default_new_scale_active_fp64_fold(family: str, scale: int) -> None:
    original = _default(family, scale=scale).double()
    _activate(original, perturb_biases=True)
    folded = copy.deepcopy(original).eval().prepare_for_export()
    assert folded.prepare_for_export() is folded
    with torch.inference_mode():
        for shape in C1_SHAPES:
            x = torch.randn(shape, dtype=torch.float64)
            reference = original(x)
            result = folded(x)
            assert result.shape == (shape[0], 3, scale * shape[2], scale * shape[3])
            torch.testing.assert_close(result, reference, atol=1e-10, rtol=0)


@pytest.mark.parametrize("family", ("wsr", "wesr"))
@pytest.mark.parametrize("scale", (1, 2, 4))
def test_default_scale_pristine_plain_identity(family: str, scale: int) -> None:
    torch.manual_seed(1024)
    model = _default(family, scale=scale)
    with torch.inference_mode():
        for shape in ((1, 3, 1, 1), (1, 3, 7, 9)):
            x = torch.rand(shape)
            actual = model(x)
            assert actual.shape == (shape[0], 3, scale * shape[2], scale * shape[3])
            assert torch.equal(actual, _plain(model, x))


@pytest.mark.parametrize("family", ("wsr", "wesr"))
@pytest.mark.parametrize("scale", (1, 2))
@pytest.mark.parametrize("configuration", ("small", "default"))
def test_cross_scale_checkpoint_strict_load_fails(
    family: str, scale: int, configuration: str
) -> None:
    source = _small(family, 4) if configuration == "small" else _default(family)
    target = (
        _small(family, scale)
        if configuration == "small"
        else _default(family, scale=scale)
    )
    with pytest.raises(RuntimeError, match="size mismatch"):
        target.load_state_dict(source.state_dict(), strict=True)


@pytest.mark.parametrize("channels,heads", ATTENTION_CONFIGS)
def test_generalized_attention_valid_key_reference(channels: int, heads: int) -> None:
    attention = BlockTokenAttention(channels, heads=heads).double()
    _activate_attention(attention)
    deployed = copy.deepcopy(attention).eval().prepare_for_export()
    with torch.inference_mode():
        for height, width in ((1, 1), (7, 9), (65, 65), (99, 101)):
            x = torch.randn(1, channels, height, width, dtype=torch.float64)
            reference = _valid_key_reference(attention, x)
            torch.testing.assert_close(attention(x), reference, atol=1e-10, rtol=0)
            torch.testing.assert_close(deployed(x), reference, atol=1e-10, rtol=0)


@pytest.mark.parametrize("amplitude", (0.0, 1e-8, 1e-5))
def test_attention_zero_and_near_zero_queries(amplitude: float) -> None:
    attention = BlockTokenAttention(16, heads=1).double()
    _activate_attention(attention)
    with torch.no_grad():
        attention.query.weight.zero_()
        attention.query.bias.fill_(amplitude)
        x = torch.randn(1, 16, 7, 9, dtype=torch.float64)
        reference = _valid_key_reference(attention, x)
        actual = attention(x)
        assert torch.isfinite(actual).all()
        torch.testing.assert_close(actual, reference, atol=1e-10, rtol=0)


@pytest.mark.parametrize("channels,heads", ATTENTION_CONFIGS)
@pytest.mark.parametrize("scale", (1, 2, 4))
def test_generalized_wesr_fold(channels: int, heads: int, scale: int) -> None:
    kwargs = {
        "width": channels,
        "hidden": channels * 2,
        "context_width": 16,
        "depth": 4,
        "gates": 2,
        "heads": heads,
        "scale": scale,
    }
    torch.manual_seed(1024)
    original = WESR(**kwargs).double()
    _activate(original, perturb_biases=True)
    folded = copy.deepcopy(original).eval().prepare_for_export()
    with torch.inference_mode():
        for shape in ((1, 3, 1, 1), (1, 3, 7, 9), (1, 3, 33, 35)):
            x = torch.randn(shape, dtype=torch.float64)
            result = folded(x)
            assert result.shape == (shape[0], 3, scale * shape[2], scale * shape[3])
            torch.testing.assert_close(result, original(x), atol=1e-10, rtol=0)


@pytest.mark.parametrize("channels,heads", ATTENTION_CONFIGS)
def test_generalized_wesr_channels_last_active_gradients(
    channels: int, heads: int
) -> None:
    contiguous = WESR(
        width=channels,
        hidden=2 * channels,
        context_width=16,
        depth=4,
        gates=2,
        heads=heads,
    ).double()
    _activate(contiguous)
    assert all(t.ndim != 5 for t in (*contiguous.parameters(), *contiguous.buffers()))
    formatted = copy.deepcopy(contiguous).to(memory_format=torch.channels_last)
    x = torch.rand(1, 3, 7, 9, dtype=torch.float64)
    outputs = []
    gradients = []
    for model, value in (
        (contiguous, x.clone().requires_grad_()),
        (
            formatted,
            x.clone().contiguous(memory_format=torch.channels_last).requires_grad_(),
        ),
    ):
        output = model(value)
        assert torch.isfinite(output).all()
        output.square().mean().backward()
        assert value.grad is not None and torch.isfinite(value.grad).all()
        current = {}
        for name, parameter in model.named_parameters():
            if not parameter.requires_grad:
                assert parameter.grad is None, name
                continue
            assert parameter.grad is not None, name
            assert torch.isfinite(parameter.grad).all(), name
            assert parameter.grad.abs().sum() > 0, name
            current[name] = parameter.grad.detach().clone()
        outputs.append(output.detach())
        gradients.append(current)
    torch.testing.assert_close(outputs[0], outputs[1], atol=1e-10, rtol=0)
    for name in gradients[0]:
        torch.testing.assert_close(
            gradients[0][name], gradients[1][name], atol=1e-10, rtol=0
        )


@pytest.mark.parametrize("family", ("wsr", "wesr"))
@pytest.mark.parametrize("scale", (0, 3, 5))
def test_unsupported_output_scale_rejected(family: str, scale: int) -> None:
    with pytest.raises(ValueError, match=r"1.*2.*4"):
        _default(family, scale=scale)


@pytest.mark.parametrize(
    "channels,heads",
    ((64, 0), (64, -1), (64, 3), (64, 16), (8, 2), (24, 2), (7, 1), (0, 1)),
)
def test_invalid_attention_dimensions_rejected(channels: int, heads: int) -> None:
    with pytest.raises(ValueError):
        BlockTokenAttention(channels, heads=heads)


@pytest.mark.parametrize(
    "kwargs",
    (
        {"width": 7},
        {"hidden": 32},
        {"context_width": 7},
        {"heads": 0},
        {"heads": 3},
        {"heads": 16},
        {"depth": 2},
        {"depth": 3, "gates": 2},
    ),
)
def test_wesr_invalid_dimensions_and_schedule(kwargs: dict[str, int]) -> None:
    with pytest.raises(ValueError):
        WESR(**kwargs)


@pytest.mark.parametrize("family", ("wsr", "wesr"))
@pytest.mark.parametrize("kwargs", ({"num_in_ch": 1}, {"num_out_ch": 1}))
def test_non_rgb_rejected(family: str, kwargs: dict[str, int]) -> None:
    constructor = WideContextSR if family == "wsr" else WESR
    with pytest.raises(ValueError):
        constructor(**kwargs)
