"""The aligned x2 DVD response and its pair geometry.

Geometry: the canonical origin and the orientation helpers against a
brute-force flip and rotation of a coordinate-coded image, and the real
context rule. Operator: unit gain, no displacement of an impulse, strength 0
as the plain centred Catmull-Rom halving, and the CUDA kernel against the
torch version of the same math.
"""

import itertools

import numpy as np
import pytest
import torch
from torch import Tensor
from traiNNer.data.dvd_response import (
    DVD_CONTEXT_LQ,
    DvdGeometry,
    dvd_response,
    orient,
    unorient,
)

D4 = list(itertools.product([False, True], repeat=3))


def _brute_orient(
    image: np.ndarray, hflip: bool, vflip: bool, clockwise: bool
) -> np.ndarray:
    if hflip:
        image = image[:, ::-1]
    if vflip:
        image = image[::-1, :]
    if clockwise:
        image = np.rot90(image, k=-1)
    return np.ascontiguousarray(image)


@pytest.mark.parametrize(("hflip", "vflip", "clockwise"), D4)
def test_orientation_and_canonical_origin_match_brute_force(
    hflip: bool, vflip: bool, clockwise: bool
) -> None:
    height, width, size = 23, 37, 9
    coded = np.arange(height * width, dtype=np.int64).reshape(height, width)
    oriented = _brute_orient(coded, hflip, vflip, clockwise)
    geometry = DvdGeometry(width, height, 0, 0, size, hflip, vflip, clockwise)

    image = torch.from_numpy(coded)[None]
    assert torch.equal(orient(image, geometry)[0], torch.from_numpy(oriented))
    assert torch.equal(unorient(orient(image, geometry), geometry), image)

    for top in range(oriented.shape[0] - size + 1):
        for left in range(oriented.shape[1] - size + 1):
            square = oriented[top : top + size, left : left + size]
            expected = (int((square % width).min()), int((square // width).min()))
            assert geometry.canonical_origin(left, top, size) == expected
            x, y = expected
            # The canonical square holds exactly the oriented square's pixels.
            canonical = torch.from_numpy(coded[y : y + size, x : x + size])[None]
            assert torch.equal(orient(canonical, geometry)[0], torch.from_numpy(square))


def _context(geometry: DvdGeometry, gt_size: int) -> list[tuple[int, int]]:
    """Per axis, the HR pixels of real image between every legal patch and
    the window's edges that are not even image edges (None when it is one)."""
    window = geometry.window()
    lo_x, hi_x, lo_y, hi_y = geometry.bounds(gt_size)
    margins = []
    for start, length, extent, lo, hi in (
        (window.left, window.width, geometry.width, lo_x, hi_x),
        (window.top, window.height, geometry.height, lo_y, hi_y),
    ):
        assert start % 2 == 0 and length % 2 == 0
        assert 0 <= start and start + length <= extent
        before = 2 * lo if start else None
        after = length - 2 * hi - gt_size if start + length != extent else None
        margins.append((before, after))
    return margins


def test_interior_crop_has_context_on_every_side() -> None:
    geometry = DvdGeometry(1000, 900, 200, 150, 416, False, True, False)
    assert geometry.has_context(384)
    for before, after in _context(geometry, 384):
        assert before is not None and before >= 2 * DVD_CONTEXT_LQ
        assert after is not None and after >= 2 * DVD_CONTEXT_LQ


def test_even_image_edges_use_the_edge_rule() -> None:
    # A whole 384-square source centred in its 416 canvas: every edge is real.
    geometry = DvdGeometry(384, 384, -16, -16, 416, True, False, True)
    assert geometry.has_context(384)
    assert geometry.resident(384)
    assert geometry.bounds(384) == (0, 0, 0, 0)
    assert _context(geometry, 384) == [(None, None), (None, None)]
    # A canvas at the image's left edge keeps the edge rule there only.
    geometry = DvdGeometry(800, 384, 0, -16, 416, False, False, False)
    (left, right), (top, bottom) = _context(geometry, 384)
    assert left is None and right >= 2 * DVD_CONTEXT_LQ
    assert top is None and bottom is None
    assert not geometry.resident(384)


def test_odd_size_trims_the_last_pixel_and_needs_context_there() -> None:
    # 385 wide: the trimmed column makes the right edge artificial.
    assert not DvdGeometry(385, 384, -16, -16, 416, False, False, False).has_context(
        384
    )
    geometry = DvdGeometry(405, 384, -16, -16, 416, False, False, False)
    assert geometry.window().width == 404
    (_, right), _ = _context(geometry, 384)
    assert right is not None and right >= 2 * DVD_CONTEXT_LQ


def test_too_small_source_has_no_legal_crop() -> None:
    assert not DvdGeometry(300, 300, -58, -58, 416, False, False, False).has_context(
        384
    )
    assert not DvdGeometry(382, 400, -17, -8, 416, False, False, False).has_context(384)
    # Real edges only: a 384 x 400 source fits exactly across, with room down.
    assert DvdGeometry(384, 400, -16, -8, 416, False, False, False).has_context(384)


def test_flat_field_has_unit_gain() -> None:
    colour = torch.tensor([0.3, 0.55, 0.8]).view(1, 3, 1, 1)
    low = dvd_response(colour.expand(2, 3, 40, 52).contiguous())
    assert low.shape == (2, 3, 20, 26)
    assert (low - colour).abs().max().item() < 1e-5


def _centroid(plane: Tensor) -> tuple[float, float]:
    total = plane.sum()
    ys = torch.arange(plane.shape[0], dtype=torch.float64)[:, None]
    xs = torch.arange(plane.shape[1], dtype=torch.float64)[None, :]
    return float((plane * xs).sum() / total), float((plane * ys).sum() / total)


def test_impulse_keeps_its_centroid_in_luma_and_chroma() -> None:
    # A red 2x2 HR block on grey: its centred x2 position is LQ (17, 14).
    image = torch.full((1, 3, 64, 72), 0.5, dtype=torch.float64)
    image[0, 0, 28:30, 34:36] = 0.6
    low = dvd_response(image.float()).double()[0] - 0.5
    luma = 0.299 * low[0] + 0.587 * low[1] + 0.114 * low[2]
    for plane in (luma, low[0] - luma, low[2] - luma):
        x, y = _centroid(plane)
        assert abs(x - 17) < 0.02 and abs(y - 14) < 0.02


def _plain_halving(image: np.ndarray) -> np.ndarray:
    """Centred x2 Catmull-Rom from the cubic itself, mirrored borders."""

    def cubic(d: float) -> float:
        d = abs(d)
        if d < 1:
            return 1.5 * d**3 - 2.5 * d**2 + 1
        return -0.5 * d**3 + 2.5 * d**2 - 4 * d + 2 if d < 2 else 0.0

    # Output sample x sits at source 2x + 0.5; taps 2x - 3 .. 2x + 4.
    taps = np.array([cubic((j - 3.5) / 2) / 2 for j in range(8)])
    padded = np.pad(image, ((0, 0), (3, 4), (3, 4)), mode="reflect")
    _, h, w = image.shape
    rows = np.stack([padded[:, 2 * y : 2 * y + 8] for y in range(h // 2)], 1)
    vertical = np.einsum("cykx,k->cyx", rows, taps)
    columns = np.stack([vertical[:, :, 2 * x : 2 * x + 8] for x in range(w // 2)], 2)
    return np.clip(np.einsum("cyxk,k->cyx", columns, taps), 0, 1)


def test_strength_zero_is_the_plain_halving() -> None:
    generator = torch.Generator().manual_seed(5)
    image = torch.rand(1, 3, 30, 44, generator=generator)
    low = dvd_response(image, strength=0)
    reference = _plain_halving(image[0].double().numpy())
    assert np.abs(low[0].double().numpy() - reference).max() < 1e-5


def _test_images() -> list[Tensor]:
    generator = torch.Generator().manual_seed(11)
    smooth = torch.rand(2, 3, 64, 96, generator=generator)
    saturated = (torch.rand(1, 3, 48, 40, generator=generator) > 0.5).float()
    tiny = torch.rand(1, 3, 4, 6, generator=generator)
    return [smooth, saturated, tiny]


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
@pytest.mark.parametrize("strength", [1.0, 0.5, 0.0])
@pytest.mark.parametrize("channels_last", [False, True])
def test_kernel_matches_torch_version(strength: float, channels_last: bool) -> None:
    memory_format = torch.channels_last if channels_last else torch.contiguous_format
    for image in _test_images():
        expected = dvd_response(image, strength)
        device = image.cuda().contiguous(memory_format=memory_format)
        low = dvd_response(device, strength)
        assert low.is_cuda and low.dtype == torch.float32
        difference = (low.cpu() - expected).abs().max().item()
        print(
            f"kernel vs torch {tuple(image.shape)} strength {strength}: {difference:.3g}"
        )
        assert difference < 1e-5


def test_rejects_odd_sizes_and_bad_strength() -> None:
    with pytest.raises(ValueError, match="even"):
        dvd_response(torch.zeros(1, 3, 5, 6))
    with pytest.raises(ValueError, match="strength"):
        dvd_response(torch.zeros(1, 3, 4, 6), strength=1.5)
