"""Real optimizer-path regressions; tiny networks, no user artifacts."""
# ruff: noqa: SLF001

from collections.abc import Callable
from contextlib import nullcontext
from copy import deepcopy
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest
import torch
import torch.distributed as dist
from ema_pytorch import EMA
from torch import nn
from torch.amp import GradScaler
from torch.nn.parallel import DistributedDataParallel
from torch.optim import AdamW, Optimizer
from traiNNer.losses.gan_loss import GANLoss
from traiNNer.models.base_model import BaseModel
from traiNNer.models.sr_model import MAX_CONSECUTIVE_NONFINITE_ATTEMPTS, SRModel
from traiNNer.training_recovery import PersistentNonfiniteError
from traiNNer.utils.redux_options import PathOptions, ReduxOptions, TrainOptions


class PixelLoss(nn.Module):
    loss_weight = 1.0

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).square().mean()


class BadDictionaryLoss(PixelLoss):
    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> dict:
        return {"bad": super().forward(pred, target) * float("nan")}


class BrokenDGAN(GANLoss):
    def forward(
        self, pred: torch.Tensor, target_is_real: bool, is_disc: bool = False
    ) -> torch.Tensor:
        loss = super().forward(pred, target_is_real, is_disc)
        return loss * float("nan") if is_disc else loss


class BrokenGGAN(GANLoss):
    def forward(
        self, pred: torch.Tensor, target_is_real: bool, is_disc: bool = False
    ) -> torch.Tensor:
        loss = super().forward(pred, target_is_real, is_disc)
        return loss if is_disc else loss * float("nan")


def make_model(
    *,
    accum_iters: int = 1,
    adaptive_d: bool = False,
    device: str = "cpu",
    discriminator: bool = True,
) -> SRModel:
    opt = ReduxOptions(
        name="numerical-safety",
        scale=1,
        num_gpu=0 if device == "cpu" else 1,
        path=PathOptions(),
        is_train=True,
        dist=False,
        compile_mode="default",
        train=TrainOptions(total_iter=38_000),
    )
    model = object.__new__(SRModel)
    BaseModel.__init__(model, opt)
    model.net_g = nn.Conv2d(3, 3, 1).to(device)
    model.net_g_ema = SimpleNamespace(ema_model=deepcopy(model.net_g), update=Mock())
    # The trainer's CUDA configs run fused AdamW; CPU keeps the default.
    model.optimizer_g = AdamW(
        model.net_g.parameters(), lr=0.01, fused=True if device == "cuda" else None
    )
    if discriminator:
        model.net_d = nn.Conv2d(3, 1, 1).to(device)
        model.optimizer_d = AdamW(model.net_d.parameters(), lr=0.01)
        model.optimizer_d_index = 1
        model.optimizers = [model.optimizer_g, model.optimizer_d]
        model.optimizers_skipped = [False, False]
    else:
        model.net_d = None
        model.optimizer_d = None
        model.optimizer_d_index = None
        model.optimizers = [model.optimizer_g]
        model.optimizers_skipped = [False]
    model.scaler_g = GradScaler(device, enabled=False)
    model.scaler_d = GradScaler(device, enabled=False)
    model.use_compile = False
    model.compile_discriminator = False
    model.cudagraph_stable_gradients = False
    model.cudagraph_stable_discriminator_gradients = False
    model._adaptive_d_window_start = None
    model.distillation = False
    model.accum_iters = accum_iters
    model.grad_clip = False
    model.adaptive_d = adaptive_d
    model.adaptive_d_ema_decay = 0.999
    model.adaptive_d_threshold = 1.02
    model.l_g_gan_ema = torch.tensor(0.7, device=device)
    model._neosr_lq_labels = frozenset()
    model.losses = {"l_g_pixel": PixelLoss()}
    if discriminator:
        model.losses["l_g_gan"] = GANLoss(0.1)
    model.lq = torch.linspace(0, 1, 3 * 8 * 8, device=device).reshape(1, 3, 8, 8)
    model.gt = model.lq * 0.8 + 0.1
    model.output = None
    return model


@pytest.mark.parametrize("fault", ["d_loss", "d_gradient", "dictionary_loss"])
def test_nonfinite_attempt_cannot_update_either_network(fault: str) -> None:
    torch.manual_seed(1)
    model = make_model()
    before_g = deepcopy(model.net_g.state_dict())
    before_d = deepcopy(model.net_d.state_dict())
    if fault == "d_loss":
        model.losses["l_g_gan"] = BrokenDGAN(0.1)
    elif fault == "d_gradient":
        model.net_d.weight.register_hook(lambda grad: grad * float("nan"))
    else:
        model.losses["l_g_pixel"] = BadDictionaryLoss()
    model.optimize_parameters(1, 0, True)
    assert not model.training_step_accepted
    for net, before in ((model.net_g, before_g), (model.net_d, before_d)):
        for name, value in net.state_dict().items():
            torch.testing.assert_close(value, before[name], rtol=0, atol=0)
    assert not model.optimizer_g.state
    assert not model.optimizer_d.state
    model.net_g_ema.update.assert_not_called()


def test_rejected_attempt_does_not_advance_adaptive_discriminator_ema() -> None:
    model = make_model(adaptive_d=True)
    model.net_g.weight.register_hook(lambda grad: grad * float("nan"))
    before = model.l_g_gan_ema.clone()
    model.optimize_parameters(1, 0, True)
    assert not model.training_step_accepted
    torch.testing.assert_close(model.l_g_gan_ema, before, rtol=0, atol=0)


@pytest.mark.parametrize("fault", ["dictionary_loss", "gan_loss"])
def test_nan_loss_cannot_poison_adaptive_discriminator_history(fault: str) -> None:
    model = make_model(adaptive_d=True)
    before = model.l_g_gan_ema.clone()
    if fault == "gan_loss":
        model.losses["l_g_gan"] = BrokenGGAN(0.1)
    else:
        model.losses["l_g_pixel"] = BadDictionaryLoss()
    model.optimize_parameters(1, 0, True)
    assert not model.training_step_accepted
    assert torch.isfinite(model.l_g_gan_ema)
    torch.testing.assert_close(model.l_g_gan_ema, before, rtol=0, atol=0)
    model.losses = {"l_g_pixel": PixelLoss(), "l_g_gan": GANLoss(0.1)}
    model.optimize_parameters(1, 0, True)
    assert model.training_step_accepted
    assert torch.isfinite(model.l_g_gan_ema)


@pytest.mark.parametrize("initial,skip_fraction", [(0.0, 1.0), (100.0, 0.0)])
def test_adaptive_d_log_is_not_divided_again_by_accumulation(
    initial: float, skip_fraction: float
) -> None:
    model = make_model(adaptive_d=True, accum_iters=4)
    model.l_g_gan_ema.fill_(initial)
    history = []
    for micro in range(4):
        model.optimize_parameters(1, micro, micro == 3)
        assert model.training_step_accepted
        history.append(model.l_g_gan_ema.clone())
    log = model.get_current_log()
    assert log["adaptive_d_skip_fraction"] == skip_fraction
    torch.testing.assert_close(log["adaptive_d_loss_ema"], torch.stack(history).mean())


def test_adaptive_discriminator_state_survives_save_resume(tmp_path: Path) -> None:
    model = make_model(adaptive_d=True)
    model.l_g_gan_ema = torch.tensor(0.417)
    model.net_g_ema = None
    model.opt.path.training_states = str(tmp_path)
    model.save_training_state(0, 38_000)
    state = torch.load(tmp_path / "38000.state", weights_only=True)
    resumed = make_model(adaptive_d=True)
    resumed.l_g_gan_ema.zero_()
    resumed.net_g_ema = None
    resumed.resume_training(state)
    torch.testing.assert_close(resumed.l_g_gan_ema, model.l_g_gan_ema, rtol=0, atol=0)


@pytest.mark.parametrize("fault", ["d_loss", "d_gradient", "g_gradient"])
@pytest.mark.parametrize("scaler_enabled", [False, True])
def test_late_accumulation_failure_rolls_back_and_next_window_recovers(
    fault: str, scaler_enabled: bool
) -> None:
    torch.manual_seed(3)
    model = make_model(accum_iters=4, adaptive_d=True)
    model.scaler_g = GradScaler("cpu", enabled=scaler_enabled)
    model.scaler_d = GradScaler("cpu", enabled=scaler_enabled)
    before_g = deepcopy(model.net_g.state_dict())
    before_d = deepcopy(model.net_d.state_dict())
    before_controller = model.l_g_gan_ema.clone()
    for micro in range(3):
        model.optimize_parameters(1, micro, False)
        assert model.training_step_accepted
    handle = None
    if fault == "d_loss":
        model.losses["l_g_gan"] = BrokenDGAN(0.1)
    elif fault == "d_gradient":
        handle = model.net_d.weight.register_hook(lambda grad: grad * float("nan"))
    else:
        handle = model.net_g.weight.register_hook(lambda grad: grad * float("nan"))
    model.optimize_parameters(1, 3, True)
    assert not model.training_step_accepted
    torch.testing.assert_close(model.l_g_gan_ema, before_controller, rtol=0, atol=0)
    for net, before in ((model.net_g, before_g), (model.net_d, before_d)):
        for name, value in net.state_dict().items():
            torch.testing.assert_close(value, before[name], rtol=0, atol=0)
        assert all(
            p.grad is None or torch.count_nonzero(p.grad) == 0 for p in net.parameters()
        )
    if handle is not None:
        handle.remove()
    model.losses["l_g_gan"] = GANLoss(0.1)
    for micro in range(4):
        model.optimize_parameters(1, micro, micro == 3)
        assert model.training_step_accepted
    assert all(int(s["step"]) == 1 for s in model.optimizer_g.state.values())
    assert all(int(s["step"]) == 1 for s in model.optimizer_d.state.values())
    assert any(
        not torch.equal(v, before_g[k]) for k, v in model.net_g.state_dict().items()
    )
    model.net_g_ema.update.assert_called_once()


def test_accumulated_optimizer_logs_average_applied_steps() -> None:
    torch.manual_seed(4)
    model = make_model(accum_iters=2, adaptive_d=True)
    model.scaler_g = GradScaler("cpu", init_scale=2.0, growth_interval=1)
    model.scaler_d = GradScaler("cpu", init_scale=8.0, growth_interval=1)
    norms = {model.optimizer_g: [], model.optimizer_d: []}

    def record_norm(optimizer: Optimizer, _args: tuple, _kwargs: dict) -> None:
        grads = [
            p.grad.flatten() for group in optimizer.param_groups for p in group["params"]
        ]
        norms[optimizer].append(torch.linalg.vector_norm(torch.cat(grads)))

    for optimizer in norms:
        optimizer.register_step_pre_hook(record_norm)

    lq, gt = model.lq, model.gt
    for step, batch_size, gan_ema in ((1, 1, 100.0), (2, 3, 0.0)):
        # Adaptive D applies only on the first boundary.
        model.l_g_gan_ema.fill_(gan_ema)
        model.lq = lq.repeat(batch_size, 1, 1, 1)
        model.gt = gt.repeat(batch_size, 1, 1, 1)
        model.optimize_parameters(step - 1, 1, False)
        model.optimize_parameters(step, 0, True)
        assert model.training_step_accepted

    logs = model.get_current_log()
    assert model.loss_samples == 8
    assert [len(norms[opt]) for opt in (model.optimizer_g, model.optimizer_d)] == [2, 1]
    assert logs["scale_g"] == 6.0  # Mean of 4 and 8.
    assert logs["scale_d"] == 16.0
    for role, optimizer in (("g", model.optimizer_g), ("d", model.optimizer_d)):
        torch.testing.assert_close(
            logs[f"grad_norm_{role}"], torch.stack(norms[optimizer]).mean()
        )


def _check_ddp_sr_updates(rank: int, rendezvous: str) -> None:
    torch.set_num_threads(1)
    dist.init_process_group(
        "gloo", init_method=rendezvous, rank=rank, world_size=2,
        timeout=timedelta(seconds=8),
    )
    try:
        model = make_model(accum_iters=2, adaptive_d=True)
        model.opt.dist = True
        with torch.no_grad():
            nn.init.dirac_(model.net_g.weight)
            model.net_g.bias.zero_()
            model.net_d.weight.zero_()
            model.net_d.weight[0, 0] = 4
            model.net_d.bias.fill_(-2)
        model.net_g = DistributedDataParallel(model.net_g)
        model.net_d = DistributedDataParallel(model.net_d)
        model.scaler_g = GradScaler("cpu", init_scale=16.0)
        model.scaler_d = GradScaler("cpu", init_scale=16.0)
        batch = 1 if rank == 0 else 3
        model.lq = torch.full((batch, 3, 2, 2), float(rank))
        model.gt = torch.zeros_like(model.lq)

        # The local GAN losses are softplus(2) and softplus(-2). Their
        # sample-weighted mean is below 0.8, their unweighted mean above it.
        model.l_g_gan_ema.fill_(0.8 / 21)
        mean_loss = (
            nn.functional.softplus(torch.tensor(2.0))
            + 3 * nn.functional.softplus(torch.tensor(-2.0))
        ) / 4
        expected = model.l_g_gan_ema.clone()
        for boundary in (False, True):
            model.optimize_parameters(int(boundary), int(not boundary), boundary)
            expected = 0.999 * expected + 0.001 * mean_loss
            torch.testing.assert_close(model.l_g_gan_ema, expected)
            assert model.training_step_accepted
        assert model.optimizers_skipped == [False, False]
        model.lq = 1 - model.lq
        model.optimize_parameters(1, 1, False)
        model.optimize_parameters(2, 0, True)
        assert model.training_step_accepted and model.optimizers_skipped == [False, True]

        model.lq = 1 - model.lq

        def committed() -> tuple:
            return (
                model.net_g.state_dict(), model.net_d.state_dict(),
                model.optimizer_g.state_dict()["state"], model.optimizer_d.state_dict()["state"],
                model.l_g_gan_ema, model.loss_samples,
            )

        for role, fault in (("g", "loss"), ("d", "loss"), ("g", "gradient"), ("d", "gradient")):
            before = deepcopy(committed())
            scalers = {"g": model.scaler_g, "d": model.scaler_d}
            scaler_states = {name: scaler.state_dict() for name, scaler in scalers.items()}
            model.optimize_parameters(2, 1, False)
            assert model.training_step_accepted
            inject = nullcontext()
            if rank == 1:
                if fault == "gradient":
                    # An ordinary backward hook would spread the NaN through DDP
                    # first and couldn't check an overflow seen by only one scaler.
                    def overflow(
                        optimizer: Optimizer,
                        unscale: Callable[[Optimizer], None] = scalers[role].unscale_,
                    ) -> None:
                        optimizer.param_groups[0]["params"][0].grad.fill_(float("inf"))
                        unscale(optimizer)

                    inject = patch.object(scalers[role], "unscale_", overflow)
                elif role == "g":
                    model.gt.fill_(float("nan"))
                else:
                    model.losses["l_g_gan"] = BrokenDGAN(0.1)
            with inject:
                model.optimize_parameters(3, 0, True)
            assert not model.training_step_accepted and model.reset_accumulation_requested
            network = "generator" if role == "g" else "discriminator"
            assert model.training_step_rejection_reason == f"nonfinite_{network}_{fault}"
            assert model.optimizers_skipped == [True, True]
            torch.testing.assert_close(committed(), before, rtol=0, atol=0)
            for name, scaler in scalers.items():
                expected_state = scaler_states[name]
                if fault == "gradient" and name == role:
                    expected_state["scale"] *= expected_state["backoff_factor"]
                    expected_state["_growth_tracker"] = 0
                assert scaler.state_dict() == expected_state
            model.gt.zero_()
            model.losses["l_g_gan"] = GANLoss(0.1)

        model.optimize_parameters(2, 1, False)
        model.optimize_parameters(3, 0, True)
        assert model.training_step_accepted and model.optimizers_skipped == [False, False]
        assert model.loss_samples == 6 * batch
        assert model.get_current_log()["adaptive_d_skip_fraction"].item() == pytest.approx(1 / 3)
        replicas = [None, None]
        dist.all_gather_object(replicas, committed()[:-1])  # sample counts are rank-local
        torch.testing.assert_close(replicas[0], replicas[1], rtol=0, atol=0)
        assert all(s["step"] == 3 for s in model.optimizer_g.state.values())
        assert all(s["step"] == 2 for s in model.optimizer_d.state.values())
    finally:
        dist.destroy_process_group()


@pytest.mark.skipif(not dist.is_gloo_available(), reason="requires CPU Gloo")
def test_ddp_sr_coordinates_adaptive_skip_and_rejection(tmp_path: Path) -> None:
    torch.multiprocessing.spawn(
        _check_ddp_sr_updates, args=((tmp_path / "gloo").as_uri(),), nprocs=2
    )


def test_finite_gan_update_matches_direct_reference() -> None:
    torch.manual_seed(4)
    model = make_model(accum_iters=4)
    reference_g, reference_d = deepcopy(model.net_g), deepcopy(model.net_d)
    optimizer_g = AdamW(reference_g.parameters(), lr=0.01)
    optimizer_d = AdamW(reference_d.parameters(), lr=0.01)
    gan = GANLoss(0.1)
    for micro in range(4):
        for p in reference_d.parameters():
            p.requires_grad_(False)
        output = reference_g(model.lq)
        loss_g = (
            (output - model.gt).square().mean() + 0.1 * gan(reference_d(output), True)
        ) / 4
        loss_g.backward()
        if micro == 3:
            optimizer_g.step()
        for p in reference_d.parameters():
            p.requires_grad_(True)
        loss_d = (
            gan(reference_d(model.gt), True, True)
            + gan(reference_d(output.detach()), False, True)
        ) / 4
        loss_d.backward()
        if micro == 3:
            optimizer_d.step()
        model.optimize_parameters(1, micro, micro == 3)
    for net, reference in ((model.net_g, reference_g), (model.net_d, reference_d)):
        for name, value in net.state_dict().items():
            torch.testing.assert_close(
                value, reference.state_dict()[name], rtol=0, atol=0
            )


def test_partial_accumulation_save_uses_last_committed_controller(
    tmp_path: Path,
) -> None:
    model = make_model(accum_iters=4, adaptive_d=True)
    model.net_g_ema = None
    model.opt.path.training_states = str(tmp_path)
    committed = model.l_g_gan_ema.clone()
    model.optimize_parameters(100, 1, False)
    assert not torch.equal(model.l_g_gan_ema, committed)
    model.save_training_state(0, 100)
    state = torch.load(tmp_path / "100.state", weights_only=True)
    torch.testing.assert_close(state["adaptive_d_loss_ema"], committed, rtol=0, atol=0)


def test_repeated_discriminator_fault_enters_existing_recovery_protocol() -> None:
    model = make_model()
    model.losses["l_g_gan"] = BrokenDGAN(0.1)
    for _ in range(19):
        model.optimize_parameters(101, 0, True)
        assert not model.training_step_accepted
    with pytest.raises(PersistentNonfiniteError) as failure:
        model.optimize_parameters(101, 0, True)
    assert failure.value.reason == "nonfinite_discriminator_loss"
    assert failure.value.candidate_iter == 101
    assert failure.value.count == 20
    assert not model.optimizer_g.state and not model.optimizer_d.state


requires_cuda = pytest.mark.skipif(
    not torch.cuda.is_available(), reason="the deferred guard needs CUDA"
)


class PoisonedPixelLoss(PixelLoss):
    def __init__(self, poisoned: list[bool]) -> None:
        super().__init__()
        self.poisoned = poisoned

    def forward(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        loss = super().forward(pred, target)
        return loss * float("nan") if self.poisoned[0] else loss


def make_deferred_model(deferred: bool) -> SRModel:
    torch.manual_seed(6)
    model = make_model(device="cuda", discriminator=False)
    assert model._deferred_nonfinite_guard_applies()
    model.deferred_nonfinite_guard = deferred
    return model


def feed_update(model: SRModel, update: int) -> None:
    generator = torch.Generator().manual_seed(40 + update)
    model.lq = torch.rand(1, 3, 8, 8, generator=generator).cuda()
    model.gt = model.lq * 0.8 + 0.1


def assert_same_optimizer_state(
    first: dict[int, dict[str, torch.Tensor]],
    second: dict[int, dict[str, torch.Tensor]],
) -> None:
    assert first.keys() == second.keys()
    for index, state in first.items():
        assert state.keys() == second[index].keys()
        for key, value in state.items():
            torch.testing.assert_close(value, second[index][key], rtol=0, atol=0)


def assert_same_weights(first: nn.Module, second: nn.Module) -> None:
    second_state = second.state_dict()
    for name, value in first.state_dict().items():
        torch.testing.assert_close(value, second_state[name], rtol=0, atol=0)


@requires_cuda
def test_deferred_guard_matches_todays_update_when_finite() -> None:
    models = [make_deferred_model(deferred) for deferred in (False, True)]
    for model in models:
        model.net_g_ema = EMA(
            model.net_g, beta=0.999, update_every=1, power=0.75, use_foreach=True
        )
        # As the trainer keeps them: the step counters live on the CPU.
        model.net_g_ema.step = model.net_g_ema.step.cpu()
        model.net_g_ema.initted = model.net_g_ema.initted.cpu()
    for update in range(1, 7):
        for model in models:
            feed_update(model, update)
            model.optimize_parameters(update, 0, True)
            assert model.training_step_accepted
    assert models[1]._deferred_updates
    logs = [model.get_current_log() for model in models]
    assert not models[1]._deferred_updates
    assert models[0].loss_samples == models[1].loss_samples == 6
    assert logs[0].keys() == logs[1].keys()
    for key, value in logs[0].items():
        torch.testing.assert_close(logs[1][key], value, rtol=0, atol=0)
    assert_same_weights(models[0].net_g, models[1].net_g)
    assert_same_optimizer_state(
        models[0].optimizer_g.state_dict()["state"],
        models[1].optimizer_g.state_dict()["state"],
    )
    assert_same_weights(models[0].net_g_ema.ema_model, models[1].net_g_ema.ema_model)


@requires_cuda
@pytest.mark.parametrize("bad_update", [1, 3])
@pytest.mark.parametrize("fault", ["loss", "gradient"])
def test_deferred_guard_skips_a_nonfinite_update_on_the_device(
    fault: str, bad_update: int
) -> None:
    # Today's path rejects the same update at once: the reference.
    models = [make_deferred_model(deferred) for deferred in (False, True)]
    poisoned = [False]
    for model in models:
        if fault == "loss":
            model.losses["l_g_pixel"] = PoisonedPixelLoss(poisoned)
        else:
            model.net_g.weight.register_hook(
                lambda grad: grad * float("nan") if poisoned[0] else grad
            )
    accepted: list[list[bool]] = [[], []]
    for update in range(1, 6):
        poisoned[0] = update == bad_update
        for index, model in enumerate(models):
            before = deepcopy(model.optimizer_g.state_dict()["state"])
            before_g = deepcopy(model.net_g.state_dict())
            feed_update(model, update)
            model.optimize_parameters(update, 0, True)
            accepted[index].append(model.training_step_accepted)
            if update != bad_update:
                continue
            for name, value in model.net_g.state_dict().items():
                torch.testing.assert_close(value, before_g[name], rtol=0, atol=0)
            after = model.optimizer_g.state_dict()["state"]
            if before:
                assert_same_optimizer_state(after, before)
            else:
                # The library's first step creates state; the skipped step
                # leaves it at zero, step counters included.
                assert all(
                    not torch.count_nonzero(value)
                    for state in after.values()
                    for value in state.values()
                )
        if update == bad_update:
            logger = Mock()
            with patch("traiNNer.models.sr_model.get_root_logger", return_value=logger):
                log = models[1].get_current_log()
            assert models[1].nan_count == 1
            assert models[1].loss_samples == bad_update - 1
            assert all(torch.isfinite(torch.as_tensor(v)).all() for v in log.values())
            message = logger.warning.call_args.args
            assert "skipped on the device" in message[0]
            assert message[1] == bad_update
            assert message[2] == f"nonfinite_generator_{fault}"
            if fault == "loss":
                assert "l_g_total" in message[3]
            assert "l_g_total" not in models[1].log_dict or bool(
                torch.isfinite(models[1].log_dict["l_g_total"])
            )
    # Today: the bad call itself; deferred: exactly the call after it.
    assert accepted[0] == [update != bad_update for update in range(1, 6)]
    assert accepted[1] == [update != bad_update + 1 for update in range(1, 6)]
    logs = [model.get_current_log() for model in models]
    assert models[0].loss_samples == models[1].loss_samples == 4
    assert models[1].nan_count == 0
    for key, value in logs[0].items():
        torch.testing.assert_close(logs[1][key], value, rtol=0, atol=0)
    assert_same_weights(models[0].net_g, models[1].net_g)
    assert_same_optimizer_state(
        models[0].optimizer_g.state_dict()["state"],
        models[1].optimizer_g.state_dict()["state"],
    )
    # The EMA still averages once on the skipped update.
    assert models[0].net_g_ema.update.call_count == 4
    assert models[1].net_g_ema.update.call_count == 5


@requires_cuda
def test_deferred_guard_raises_after_20_consecutive_nonfinite_updates() -> None:
    model = make_deferred_model(True)
    model.losses["l_g_pixel"] = BadDictionaryLoss()
    calls = 0
    with pytest.raises(PersistentNonfiniteError) as failure:
        for update in range(1, 31):
            calls += 1
            feed_update(model, update)
            model.optimize_parameters(update, 0, True)
    assert failure.value.reason == "nonfinite_generator_loss"
    assert failure.value.count == 20
    # Seen at the start of a later call: at most a few calls late.
    assert 21 <= calls <= 23
    assert all(
        not torch.count_nonzero(value)
        for state in model.optimizer_g.state.values()
        for value in state.values()
    )


@requires_cuda
def test_deferred_guard_settles_before_save_and_validation(tmp_path: Path) -> None:
    model = make_deferred_model(True)
    model.opt.path.models = str(tmp_path)
    model.opt.path.resume_models = str(tmp_path)
    model.save_network = Mock()
    model.save_training_state = Mock()
    model._nondist_validation = Mock()
    model._validation_inference_context = Mock(return_value=nullcontext())

    feed_update(model, 1)
    model.optimize_parameters(1, 0, True)
    model.nondist_validation(Mock(), 1, None, False, False)
    assert not model._deferred_updates
    assert model.loss_samples == 1
    model._nondist_validation.assert_called_once()

    model.nan_count = MAX_CONSECUTIVE_NONFINITE_ATTEMPTS - 1
    model.losses["l_g_pixel"] = BadDictionaryLoss()
    feed_update(model, 2)
    model.optimize_parameters(2, 0, True)
    with pytest.raises(PersistentNonfiniteError):
        model.save(0, 2)
    model.save_network.assert_not_called()
    model.save_training_state.assert_not_called()


@pytest.mark.parametrize(
    ("device", "discriminator", "accum_iters"),
    [
        pytest.param("cuda", True, 1, marks=requires_cuda),
        pytest.param("cuda", False, 2, marks=requires_cuda),
        ("cpu", False, 1),
    ],
)
def test_deferred_guard_needs_the_plain_cuda_case(
    device: str, discriminator: bool, accum_iters: int
) -> None:
    model = make_model(
        device=device, discriminator=discriminator, accum_iters=accum_iters
    )
    assert not model._deferred_nonfinite_guard_applies()
    model.losses["l_g_pixel"] = BadDictionaryLoss()
    model.optimize_parameters(1, 0, accum_iters == 1)
    # Today's check: the call that sees the value rejects itself.
    assert not model.training_step_accepted
    assert model.nan_count == 1
    assert not model._deferred_updates


@requires_cuda
@pytest.mark.parametrize("warm", [False, True])
def test_step_optimizer_found_inf_gates_both_routes(warm: bool) -> None:
    torch.manual_seed(8)
    nets = [nn.Conv2d(3, 3, 1).cuda() for _ in range(3)]
    for net in nets[1:]:
        net.load_state_dict(nets[0].state_dict())
    optimizers = [AdamW(net.parameters(), lr=0.01, fused=True) for net in nets]
    scaler = GradScaler("cuda", enabled=False)
    model = object.__new__(BaseModel)

    def step(found_inf: list[float | None]) -> None:
        for net, optimizer, flag in zip(nets, optimizers, found_inf, strict=True):
            for param in net.parameters():
                param.grad = torch.full_like(param, 0.5)
            model.step_optimizer(
                scaler,
                optimizer,
                None if flag is None else torch.tensor(flag, device="cuda"),
            )

    if warm:
        # The fast route needs the state that a first library step creates.
        step([None, 0.0, 0.0])
    before_state = deepcopy(optimizers[2].state_dict()["state"])
    before_net = deepcopy(nets[2].state_dict())
    step([None, 0.0, 1.0])
    # found_inf zero: bit-identical to no found_inf.
    assert_same_weights(nets[0], nets[1])
    assert_same_optimizer_state(
        optimizers[0].state_dict()["state"], optimizers[1].state_dict()["state"]
    )
    # found_inf non-zero: nothing moved, step counters included.
    for name, value in nets[2].state_dict().items():
        torch.testing.assert_close(value, before_net[name], rtol=0, atol=0)
    after_state = optimizers[2].state_dict()["state"]
    if warm:
        assert_same_optimizer_state(after_state, before_state)
    else:
        assert all(
            not torch.count_nonzero(value)
            for state in after_state.values()
            for value in state.values()
        )
    assert "found_inf" not in optimizers[2].__dict__


@requires_cuda
def test_deferred_guard_uses_todays_checks_after_resuming_a_non_fused_state() -> None:
    model = make_deferred_model(True)
    saved = AdamW(deepcopy(model.net_g).parameters(), lr=0.01)
    # Resume replaces the built groups with the saved ones (fused: None).
    model.optimizer_g.load_state_dict(saved.state_dict())
    assert not model.optimizer_g.param_groups[0]["fused"]
    poisoned = [False]
    model.losses["l_g_pixel"] = PoisonedPixelLoss(poisoned)
    for update in range(1, 5):
        poisoned[0] = update == 3
        feed_update(model, update)
        model.optimize_parameters(update, 0, True)
        # The read-back check: the bad call rejects itself, nothing is queued.
        assert model.training_step_accepted == (update != 3)
        assert not model._deferred_updates
    assert model.nan_count == 0
    assert all(int(state["step"]) == 3 for state in model.optimizer_g.state.values())


@requires_cuda
def test_deferred_guard_continues_after_reloading_a_fused_state() -> None:
    models = [make_deferred_model(deferred) for deferred in (False, True)]
    poisoned = [False]
    for model in models:
        model.losses["l_g_pixel"] = PoisonedPixelLoss(poisoned)
    library_step = Mock(wraps=models[1]._library_optimizer_step)
    models[1]._library_optimizer_step = library_step
    for update in range(1, 7):
        poisoned[0] = update == 5
        if update in (3, 5):
            # A resumed fused state invalidates the gathered lists: the next
            # gated step goes through the library, as the first one does.
            for model in models:
                model.optimizer_g.load_state_dict(
                    deepcopy(model.optimizer_g.state_dict())
                )
        library_step.reset_mock()
        for model in models:
            feed_update(model, update)
            model.optimize_parameters(update, 0, True)
        if update in (1, 3, 5):
            library_step.assert_called_once()
            found_inf = library_step.call_args.args[2]
            assert float(found_inf) == float(update == 5)
        else:
            library_step.assert_not_called()
    models[1].get_current_log()
    assert models[1].nan_count == 0
    assert_same_weights(models[0].net_g, models[1].net_g)
    assert_same_optimizer_state(
        models[0].optimizer_g.state_dict()["state"],
        models[1].optimizer_g.state_dict()["state"],
    )
    assert models[0].loss_samples == models[1].loss_samples == 5
