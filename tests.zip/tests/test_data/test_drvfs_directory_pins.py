import sys
from pathlib import Path

import numpy as np
import pytest
from PIL import Image
from torch.utils.data import DataLoader
from traiNNer.data.realesrgan_dataset import RealESRGANDataset
from traiNNer.utils import RNG, _drvfs
from traiNNer.utils.redux_options import DatasetOptions
from traiNNer.utils.types import DataFeed


@pytest.mark.skipif(sys.platform != "linux", reason="requires Linux directory FDs")
def test_loose_drvfs_worker_releases_pins_under_fd_pressure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from resource import RLIMIT_NOFILE, getrlimit, setrlimit

    levels = list(range(10, 22))
    shards = {tmp_path / str(level) for level in levels}
    for level in levels:
        shard = tmp_path / str(level)
        shard.mkdir()
        name = "image.tiff" if level == levels[-1] else "image.png"
        Image.new("RGB", (40, 40), (level,) * 3).save(shard / name)

    device = tmp_path.stat().st_dev
    monkeypatch.setattr(_drvfs, "_drvfs_devices", lambda: frozenset({device}))
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(0))
    dataset = RealESRGANDataset(
        DatasetOptions(
            name="drvfs",
            type="RealESRGANDataset",
            dataroot_gt=[str(tmp_path)],
            gt_size=8,
            use_hflip=False,
            use_rot=False,
            blur_prob=0.0,
            blur_prob2=0.0,
            final_sinc_prob=0.0,
        )
    )

    first_batch = True

    def collate(samples: list[DataFeed]) -> list[int]:
        nonlocal first_batch
        pins = {
            int(fd.name)
            for fd in Path("/proc/self/fd").iterdir()
            if fd.resolve() in shards
        }
        if first_batch:
            assert len(pins) == len(shards)
            _, hard = getrlimit(RLIMIT_NOFILE)
            # The same worker processes the next batch with its existing pins.
            setrlimit(RLIMIT_NOFILE, (max(pins) + 1, hard))
            first_batch = False
        else:
            assert not pins
        return [round(sample["gt"][0, 0, 0].item() * 255) for sample in samples]

    loader = DataLoader(
        dataset,
        batch_size=len(levels),
        sampler=list(range(len(levels))) * 2,
        num_workers=1,
        multiprocessing_context="fork",
        collate_fn=collate,
        timeout=15,
    )
    assert list(loader) == [levels, levels]
