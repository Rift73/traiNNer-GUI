from types import SimpleNamespace

import av
import numpy as np
import pytest
import torch
from chainner_ext import resize
from traiNNer.data.clip_hr import clip_axes, hr_clip, resize_matrix
from traiNNer.data.descale import TRANSFERS, descale, descale_matrix
from traiNNer.data.video_clip_dataset import _HR_FILTERS, VideoClipDataset
from traiNNer.data.video_index import to_rgb
from traiNNer.utils.redux_options import DatasetOptions

FRAME_H, FRAME_W = 72, 256
CROP = 16
FRAMES = 2


@pytest.mark.parametrize(
    ("kernel", "border"), [("bilinear", "zero"), ("bicubic", "mirror")]
)
def test_descale_matrix_matches_descale(kernel: str, border: str) -> None:
    image = np.random.default_rng(0).random((36, 50, 3), dtype=np.float32)
    expected = descale(image, 39, 28, kernel, border=border)
    p_v = descale_matrix(28, 36, kernel, border)
    p_h = descale_matrix(39, 50, kernel, border)
    out = np.einsum("ij,jkc->ikc", p_v, image.astype(np.float64))
    out = np.einsum("ikc,lk->ilc", out, p_h)
    assert np.abs(out - expected).max() <= 1e-5
    assert np.array_equal(descale_matrix(36, 36, kernel, border), np.eye(36))


@pytest.mark.parametrize("name", list(_HR_FILTERS))
@pytest.mark.parametrize(
    ("source", "target"), [((48, 27), (32, 18)), ((37, 50), (11, 50))]
)
def test_resize_matrix_matches_chainner_ext(
    name: str, source: tuple[int, int], target: tuple[int, int]
) -> None:
    # Values well inside 0..1, as chainner_ext clamps its result.
    rng = np.random.default_rng(1)
    image = rng.uniform(0.2, 0.8, (source[1], source[0], 2)).astype(np.float32)
    expected = resize(image, target, _HR_FILTERS[name], False)
    w_v = resize_matrix(source[1], target[1], name)
    w_h = resize_matrix(source[0], target[0], name)
    out = np.einsum("ij,jkc->ikc", w_v, image.astype(np.float64))
    out = np.einsum("ikc,lk->ilc", out, w_h)
    assert np.abs(out - expected).max() <= 1e-6


def _options(**overrides: object) -> DatasetOptions:
    options = {
        "name": "clips",
        "type": "videoclipdataset",
        "phase": "train",
        "dataroot_gt": ["unused"],
        "scale": 2,
        "lq_size": CROP // 2,
        "descale_size": (198, 56),
        "descale_kernel": "bilinear",
        "descale_border": "zero",
        "hr_size": (128, 36),
        "downscale_algorithm": "hermite",
        "descale_linear_light": None,
        "hr_linear_light": "gamma24",
    }
    options.update(overrides)
    return DatasetOptions(**options)


def _planes(seed: int) -> list[np.ndarray]:
    """yuv420p frames of smooth content with a little noise, as H*3/2,W arrays.
    The colours stay away from black, where encoding a linear-light value
    magnifies the float32 rounding of the CPU reference past the tolerance."""
    rng = np.random.default_rng(seed)
    y, x = np.mgrid[0:FRAME_H, 0:FRAME_W].astype(np.float64)
    frames = []
    for t in range(FRAMES):
        luma = 125 + 55 * np.sin(x / 7 + t) * np.cos(y / 5) + rng.normal(0, 3, x.shape)
        cy, cx = y[::2, ::2], x[::2, ::2]
        u = 128 + 20 * np.sin(cx / 9 - t) + rng.normal(0, 2, cx.shape)
        v = 128 + 20 * np.cos(cy / 4 + cx / 11) + rng.normal(0, 2, cx.shape)
        stacked = np.concatenate(
            [luma, u.reshape(FRAME_H // 4, FRAME_W), v.reshape(FRAME_H // 4, FRAME_W)]
        )
        frames.append(np.clip(np.rint(stacked), 0, 255).astype(np.uint8))
    return frames


def test_window_is_smaller_than_the_frame_along_one_axis() -> None:
    rows, cols = clip_axes(FRAME_H, FRAME_W, _options())
    assert rows.size == FRAME_H
    assert cols.size < FRAME_W
    assert cols.size % 2 == 0
    assert np.all(cols.origins % 2 == 0)
    assert np.all((cols.origins >= 0) & (cols.origins <= FRAME_W - cols.size))


@pytest.mark.parametrize("descale_light", [None, "gamma24"])
@pytest.mark.parametrize("hr_light", [None, *TRANSFERS])
@pytest.mark.parametrize("filter_name", ["hermite", "mitchell"])
def test_hr_clip_matches_hr_frame(
    descale_light: str | None, hr_light: str | None, filter_name: str
) -> None:
    opt = _options(
        descale_linear_light=descale_light,
        hr_linear_light=hr_light,
        downscale_algorithm=filter_name,
    )
    rows, cols = clip_axes(FRAME_H, FRAME_W, opt)
    frames = [
        av.VideoFrame.from_ndarray(planes, format="yuv420p") for planes in _planes(2)
    ]
    hr = [
        VideoClipDataset.hr_frame(SimpleNamespace(opt=opt), to_rgb(f)) for f in frames
    ]
    hr_w, hr_h = opt.hr_size
    last_top, last_left = hr_h - CROP, hr_w - CROP
    positions = [
        (0, 0, 0, 0, 0),
        (0, last_left, 1, 0, 0),
        (last_top, 0, 0, 1, 0),
        (last_top, last_left, 0, 0, 1),
        (9, 47, 1, 1, 1),
        (5, 61, 1, 0, 1),
    ]
    for top, left, hflip, vflip, transpose in positions:
        row, col = int(rows.origins[top]), int(cols.origins[left])
        h, w = rows.size, cols.size
        y, u, v = [], [], []
        for f in frames:
            planes = f.to_ndarray()
            chroma = planes[FRAME_H:].reshape(2, FRAME_H // 2, FRAME_W // 2)
            y.append(planes[:FRAME_H][row : row + h, col : col + w])
            u.append(chroma[0][row // 2 : (row + h) // 2, col // 2 : (col + w) // 2])
            v.append(chroma[1][row // 2 : (row + h) // 2, col // 2 : (col + w) // 2])
        geometry = torch.tensor(
            [FRAME_H, FRAME_W, top, left, row, col, hflip, vflip, transpose]
        )
        out = hr_clip(
            *(torch.from_numpy(np.stack(p)[:, None]) for p in (y, u, v)),
            geometry,
            opt,
        )
        expected = np.stack(
            [image[top : top + CROP, left : left + CROP] for image in hr]
        )
        if hflip:
            expected = expected[:, :, ::-1]
        if vflip:
            expected = expected[:, ::-1]
        if transpose:
            expected = expected.transpose(0, 2, 1, 3)
        expected = expected.transpose(0, 3, 1, 2)
        assert out.shape == (FRAMES, 3, CROP, CROP)
        assert out.dtype == torch.float32
        assert np.abs(out.numpy() - expected).max() <= 2e-6, (top, left)


def test_hr_clip_restores_matmul_precision() -> None:
    opt = _options()
    _, cols = clip_axes(FRAME_H, FRAME_W, opt)
    planes = torch.from_numpy(np.stack(_planes(3)))
    y = planes[:, None, :FRAME_H, : cols.size]
    chroma = planes[:, None, FRAME_H:].reshape(FRAMES, 1, 2, FRAME_H // 2, -1)
    u = chroma[:, :, 0, :, : cols.size // 2]
    v = chroma[:, :, 1, :, : cols.size // 2]
    geometry = torch.tensor([FRAME_H, FRAME_W, 0, 0, 0, 0, 0, 0, 0])
    before = torch.get_float32_matmul_precision()
    torch.set_float32_matmul_precision("high")
    try:
        hr_clip(y, u, v, geometry, opt)
        assert torch.get_float32_matmul_precision() == "high"
    finally:
        torch.set_float32_matmul_precision(before)
