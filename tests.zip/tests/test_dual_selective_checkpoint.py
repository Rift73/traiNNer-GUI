"""CPU contracts for DUAL's single, family-wide checkpointing switch."""
# ruff: noqa: SLF001 - Verify checkpoint boundaries and backend policies.

import copy
from collections.abc import Callable, Iterator
from contextlib import nullcontext
from typing import Any
from unittest.mock import patch

import pytest
import torch
from traiNNer.archs import dual_arch as arch


@pytest.fixture(scope="module", autouse=True)
def cpu_only() -> Iterator[None]:
    assert not torch.cuda.is_initialized()
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    yield
    torch.set_num_threads(previous)
    assert not torch.cuda.is_initialized()


def small_model(**kwargs: Any) -> arch.DUAL:
    return arch.DUAL(
        embed_dim=32,
        depths=(3, 3),
        layer_indices=((0, 1, 2), (3, 4, 5)),
        c_windows=(4, 8),
        **kwargs,
    )


@pytest.mark.parametrize("scale", [1, 2, 4])
@pytest.mark.parametrize(
    "factory",
    [
        arch.DUAL,
        arch.dual_light,
        arch.dual_xs,
        arch.dual_s,
        arch.dual_m,
        arch.dual_l,
        arch.dual_xl,
    ],
)
def test_family_defaults_schema_and_cache(
    factory: Callable[..., arch.DUAL], scale: int
) -> None:
    with torch.device("meta"):
        model = factory(scale=scale)
        off = factory(scale=scale, use_checkpoint=False)
    assert all(group.use_checkpoint for group in model.groups)
    assert not any(group.use_checkpoint for group in off.groups)
    assert model.compile_cache_key_tag != off.compile_cache_key_tag
    assert "dual-family-attention-v10" in model.compile_cache_key_tag
    assert list(model.state_dict()) == list(off.state_dict())
    for name, value in model.state_dict().items():
        assert value.shape == off.state_dict()[name].shape
    for module in model.modules():
        assert not hasattr(module, "context_checkpoint")
        assert not hasattr(module, "core_checkpoint")
        assert not hasattr(module, "dual_core_checkpoint")


@pytest.mark.parametrize("bad", [0, 1, None, "true"])
def test_switch_requires_boolean(bad: Any) -> None:
    with pytest.raises(ValueError, match="use_checkpoint must be a bool"):
        arch.dual_light(use_checkpoint=bad)


@pytest.mark.parametrize("removed", ["context_checkpoint", "dual_core_checkpoint"])
def test_removed_options_are_not_silently_accepted(removed: str) -> None:
    with pytest.raises(TypeError, match=removed):
        arch.dual_light(**{removed: True})


@pytest.mark.parametrize("scale", [1, 2, 4])
@pytest.mark.parametrize("pu2", [False, True])
@pytest.mark.parametrize("mode", ["fp64", "fp32", "bf16"])
@pytest.mark.parametrize("input_grad", [False, True])
def test_forward_all_gradients_and_strict_load(
    scale: int, pu2: bool, mode: str, input_grad: bool
) -> None:
    torch.manual_seed(121)
    dtype = torch.float64 if mode == "fp64" else torch.float32
    original = small_model(scale=scale, pixel_unshuffle=pu2, use_checkpoint=False).to(
        dtype
    )
    candidate = small_model(scale=scale, pixel_unshuffle=pu2, use_checkpoint=True).to(
        dtype
    )
    candidate.load_state_dict(original.state_dict(), strict=True)
    # Activate zero-initialized paths so this is not merely an identity test.
    with torch.no_grad():
        for parameter in original.parameters():
            parameter.add_(torch.randn_like(parameter) * 0.001)
    candidate.load_state_dict(original.state_dict(), strict=True)
    x = torch.randn(1, 3, 9, 13, dtype=dtype, requires_grad=input_grad)
    xc = x.detach().clone().requires_grad_(input_grad)
    with (
        torch.autocast("cpu", dtype=torch.bfloat16) if mode == "bf16" else nullcontext()
    ):
        expected = original(x)
        actual = candidate(xc)
    signal = torch.randn_like(expected)
    (expected * signal).sum().backward()
    (actual * signal).sum().backward()
    assert actual.shape == (1, 3, 9 * scale, 13 * scale)
    torch.testing.assert_close(actual, expected, atol=0, rtol=0)

    def compare_gradient(
        actual_grad: torch.Tensor, expected_grad: torch.Tensor
    ) -> None:
        if mode == "bf16":
            # Eager AMP cast-cache removal changes shared-weight accumulation
            # rounding. Keep an explicit RMS bound, not a bitwise BF16 claim.
            error = (
                (actual_grad.double() - expected_grad.double()).square().mean().sqrt()
            )
            reference = expected_grad.double().square().mean().sqrt()
            assert error <= 0.01 * reference + 1e-7
        else:
            torch.testing.assert_close(actual_grad, expected_grad, atol=0, rtol=0)

    if input_grad:
        compare_gradient(xc.grad, x.grad)
    for name, parameter in original.named_parameters():
        gradient = candidate.get_parameter(name).grad
        assert parameter.grad is not None and gradient is not None, name
        assert gradient.isfinite().all(), name
        compare_gradient(gradient, parameter.grad)


def test_one_boundary_per_layer_including_shared_coarse_prefix() -> None:
    model = small_model(scale=2)
    x = torch.randn(1, 3, 9, 13)
    with patch.object(arch, "checkpoint", wraps=arch.checkpoint) as call:
        model(x).square().mean().backward()
    expected = list(model.groups[0].layers) + list(model.groups[1].layers)
    expected += list(model.groups[0].layers[:2])
    assert [entry.args[0] for entry in call.call_args_list] == expected
    assert all(entry.kwargs["use_reentrant"] is False for entry in call.call_args_list)
    assert all("context_fn" in entry.kwargs for entry in call.call_args_list)


def test_disabled_eval_no_grad_and_export_do_not_checkpoint() -> None:
    model = small_model(scale=2)
    x = torch.randn(1, 3, 9, 13)
    with patch.object(arch, "checkpoint", side_effect=AssertionError("checkpoint")):
        model.eval()(x)
        with torch.no_grad():
            model.train()(x)
        small_model(scale=2, use_checkpoint=False)(x).sum().backward()
        deployed = copy.deepcopy(model).eval()
        expected = deployed(x)
        deployed.prepare_for_export()
        torch.testing.assert_close(deployed(x), expected, atol=5e-6, rtol=1e-5)


def test_policy_saves_attention_not_surrounding_work(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    policy = arch._selective_checkpoint_policy
    ops = [
        torch.ops.aten._scaled_dot_product_flash_attention.default,
        torch.ops.aten._scaled_dot_product_efficient_attention.default,
        torch.ops.aten._scaled_dot_product_cudnn_attention.default,
        torch.ops.aten._scaled_dot_product_flash_attention_for_cpu.default,
    ]
    if arch._HAS_DIRECT_ATTENTION:
        ops.append(torch.ops.dual_standalone.dense_rpb_attention.default)
    for op in ops:
        assert policy(None, op) is arch.CheckpointPolicy.MUST_SAVE
    monkeypatch.setattr(arch, "_HAS_DIRECT_ATTENTION", False)
    assert (
        policy(None, torch.ops.aten.mm.default)
        is arch.CheckpointPolicy.PREFER_RECOMPUTE
    )


def test_dynamo_fullgraph_selective_checkpoint() -> None:
    model = small_model(scale=2)
    compiled = torch.compile(model, backend="eager", fullgraph=True)
    x = torch.randn(1, 3, 9, 13, requires_grad=True)
    compiled(x).square().mean().backward()
    assert x.grad is not None and x.grad.isfinite().all()
    assert all(p.grad is not None for p in model.parameters())
