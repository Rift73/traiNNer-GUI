from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from unittest.mock import Mock

import pytest
import torch
from studio import run_process
from studio.server import Services
from studio.workspace import PROJECT_DIR_ENV, PROJECT_ID_ENV
from studio.yaml_edit import read_recipe


def test_queued_resume_waits_and_launches_the_stopped_checkpoint(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv(PROJECT_DIR_ENV, raising=False)
    monkeypatch.delenv(PROJECT_ID_ENV, raising=False)
    monkeypatch.setattr(run_process, "cli_trainer_running", lambda: False)
    monkeypatch.setattr("studio.runs.secrets.randbelow", Mock(side_effect=(123, 456)))
    services = Services(tmp_path, tmp_path / "state")
    monkeypatch.setattr(services.queue, "prepare", lambda text: text)

    def stop_at_launch(
        attempt: Path, _lease: int, experiment: Path, *_args: object, **_kwargs: object
    ) -> None:
        experiment.mkdir(parents=True, exist_ok=True)
        run_process.write_record(attempt / "result.json", {"status": "stopped"})

    launch = Mock(side_effect=stop_at_launch)
    monkeypatch.setattr(run_process, "launch", launch)
    source = services.runs.start(
        "name: resume-source\nnetwork_g: {type: compact}\npath: {}\n"
        "train: {total_iter: 100}\n"
    )
    run_id = source["id"]
    seed = services.runs.detail(run_id)["seed"]
    experiment = services.runs.experiment_dir(run_id)
    step = 37
    weights = experiment / "models" / f"net_g_{step}.pth"
    state = experiment / "training_states" / f"{step}.state"
    weights.parent.mkdir(parents=True)
    state.parent.mkdir()
    torch.save({"params": {"weight": torch.ones(1, device="cpu")}}, weights)
    torch.save({"epoch": 0, "iter": step}, state)
    launch.reset_mock()

    ready = Barrier(2, timeout=5)

    def enqueue(request_id: str) -> dict:
        ready.wait()
        return services.post(
            "/api/queue/resume", {"runId": run_id, "requestId": request_id}
        )

    with services.runs.execution_slot(exclusive=True):
        with ThreadPoolExecutor(max_workers=2) as requests:
            first, duplicate = requests.map(enqueue, ("resume-1", "resume-2"))
        assert duplicate["id"] == first["id"]
        assert first["status"] == "pending"
        assert first["sourceRunId"] == run_id
        assert first["resumeStep"] == step
        assert services.queue.dispatch_once() is None
        entries = services.get("/api/queue", {})["entries"]
        assert [(entry["id"], entry["status"]) for entry in entries] == [
            (first["id"], "pending")
        ]
        launch.assert_not_called()

    # The first service disappears after the attempt was published, before it linked the queue entry.
    with monkeypatch.context() as patch:
        patch.setattr(services.queue, "_attach", Mock(side_effect=RuntimeError("service interrupted")))
        with pytest.raises(RuntimeError, match="service interrupted"):
            services.queue.dispatch_once()
    reopened = Services(tmp_path, tmp_path / "state")
    assert reopened.queue.dispatch_once() is None
    dispatched = reopened.queue.detail(first["id"])
    assert dispatched["runId"] == run_id and dispatched["status"] == "stopped"
    launch.assert_called_once()
    run = services.runs.detail(dispatched["runId"])
    assert run["attemptId"] != source["attemptId"] and run["queueEntryId"] == first["id"]
    argv = run["invocation"]["argv"]
    assert argv[argv.index("--manual_seed") + 1] == str(seed)
    options = Path(argv[argv.index("-opt") + 1]).read_text(encoding="utf-8")
    paths = read_recipe(options)["path"]
    assert Path(paths["resume_state"]) == state
    assert Path(paths["pretrain_network_g"]) == weights


def test_fresh_recipe_detaches_copied_checkpoints_without_discarding_draft_edits(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv(PROJECT_DIR_ENV, raising=False)
    monkeypatch.delenv(PROJECT_ID_ENV, raising=False)
    service = Services(tmp_path, tmp_path / "state")
    original = service.runs.runs / ("1" * 32)
    resumed = service.runs.runs / ("2" * 32)
    for directory in (original, resumed):
        directory.mkdir(parents=True)
        run_process.write_record(directory / "run.json", {"name": "example"})

    (original / "recipe.yml").write_text(
        "path: {pretrain_network_g: seed.pth, strict_load_g: false}\n"
    )

    def pinned(directory: Path) -> str:
        experiment = directory / "experiments/example"
        return (
            f"path:\n  resume_state: {experiment}/training_states/10529.state\n"
            f"  pretrain_network_g: {experiment}/models/resume_models/net_g_10529.pth\n"
            f"  pretrain_network_d: {experiment}/models/resume_models/net_d_10529.pth\n"
            f"  pretrain_network_g_ema: {experiment}/models/net_g_ema_10529.pth\n"
            "  strict_load_g: true\n  strict_load_d: true\n"
        )

    (resumed / "recipe.yml").write_text(pinned(original))
    draft = pinned(resumed) + (
        "  pretrain_network_g_teacher: teacher.pth\nname: new-loss\n"
        "train:\n  resume_previous_lrs: {g: 0.001}\n"
        "  losses: [{type: ssimulacra2loss, loss_weight: 0.25}]\n"
    )
    def detach(text: str) -> dict:
        return read_recipe(service.post("/api/recipe/fresh", {"yaml": text})["yaml"])

    fresh = detach(draft)
    assert fresh["path"] == {
        "resume_state": None, "pretrain_network_g": "seed.pth",
        "strict_load_g": False, "pretrain_network_g_teacher": "teacher.pth",
    }
    assert fresh["name"] == "new-loss"
    assert fresh["train"] == {"losses": [{"type": "ssimulacra2loss", "loss_weight": 0.25}]}
    edited = draft.replace(str(resumed / "experiments/example/models/resume_models/net_g_10529.pth"), "my-choice.pth")
    assert detach(edited)["path"]["pretrain_network_g"] == "my-choice.pth"


def test_queued_extension_persists_and_launches_the_completed_checkpoint(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv(PROJECT_DIR_ENV, raising=False)
    monkeypatch.delenv(PROJECT_ID_ENV, raising=False)
    monkeypatch.setattr(run_process, "cli_trainer_running", lambda: False)
    schema = Path("schemas/redux-config.schema.json")
    (tmp_path / schema.parent).mkdir()
    (tmp_path / schema).symlink_to(Path(__file__).resolve().parents[1] / schema)
    (tmp_path / "gt").mkdir()
    (tmp_path / "lq").mkdir()
    state_dir = tmp_path / "state"
    services = Services(tmp_path, state_dir)
    step, additional, seed = 100, 25, 9876
    weights_path = Path("models") / f"net_g_{step}.pth"
    state_path = Path("training_states") / f"{step}.state"

    def finish_at_launch(
        attempt: Path, _lease: int, experiment: Path, *_args: object, **_kwargs: object
    ) -> None:
        if experiment.is_dir():
            result = {"status": "stopped"}
        else:
            (experiment / weights_path.parent).mkdir(parents=True)
            (experiment / state_path.parent).mkdir()
            weight = torch.ones(1, device="cpu")
            torch.save({"params": {"weight": weight}}, experiment / weights_path)
            torch.save(
                {
                    "epoch": 0,
                    "iter": step,
                    "optimizers": [
                        {"state": {}, "param_groups": [{"params": [0], "lr": 0.0001}]}
                    ],
                    "schedulers": [{"last_epoch": step}],
                },
                experiment / state_path,
            )
            result = {
                "status": "completed",
                "completionReason": "targetReached",
                "completedIteration": step,
            }
        run_process.write_record(attempt / "result.json", result)

    launch = Mock(side_effect=finish_at_launch)
    monkeypatch.setattr(run_process, "launch", launch)
    recipe = (
        f"name: completed-source\nscale: 2\nnum_gpu: 0\nmanual_seed: {seed}\n"
        "network_g: {type: compact}\npath: {}\n"
        "datasets:\n"
        "  train:\n"
        "    name: fixture\n"
        "    type: PairedImageDataset\n"
        "    dataroot_gt: gt\n"
        "    dataroot_lq: lq\n"
        "    lq_size: 8\n"
        "    batch_size_per_gpu: 1\n"
        "    num_worker_per_gpu: 0\n"
        "train:\n"
        f"  total_iter: {step}\n"
        "  optim_g: {type: Adam, lr: 0.0001}\n"
        "  scheduler: {type: MultiStepLR, milestones: [80], gamma: 0.5}\n"
        "  losses: [{type: charbonnierloss, loss_weight: 1.0}]\n"
        "logger: {print_freq: 1, save_checkpoint_freq: 20, use_tb_logger: false}\n"
    )
    source = services.runs.start(recipe)
    assert source["status"] == "completed"
    source_experiment = services.runs.experiment_dir(source["id"])
    launch.reset_mock()

    route = "/api/queue/resume"
    body = {
        "runId": source["id"],
        "additionalIterations": additional,
        "requestId": "completed-extension",
    }
    entry = services.post(route, body)
    assert entry["status"] == "pending"
    assert entry["sourceRunId"] == source["id"]
    assert entry["resumeStep"] == step
    assert entry["additionalIterations"] == additional

    reopened = Services(tmp_path, state_dir)
    assert reopened.post(route, body)["id"] == entry["id"]
    assert (
        reopened.post(route, {**body, "requestId": "same-extension"})["id"]
        == entry["id"]
    )
    with pytest.raises(FileExistsError):
        reopened.post(
            route,
            {
                **body,
                "requestId": "different-extension",
                "additionalIterations": additional + 1,
            },
        )
    assert reopened.get("/api/queue", {})["entries"] == [entry]
    launch.assert_not_called()

    dispatched = reopened.queue.dispatch_once()
    assert dispatched is not None
    assert dispatched["id"] == entry["id"] and dispatched["status"] == "stopped", (
        dispatched
    )
    assert dispatched["runId"] == source["id"]
    run = reopened.runs.detail(dispatched["runId"])
    assert run["attemptId"] != source["attemptId"] and run["total"] == step + additional
    argv = run["invocation"]["argv"]
    assert argv[argv.index("--manual_seed") + 1] == str(seed)
    options = read_recipe(
        Path(argv[argv.index("-opt") + 1]).read_text(encoding="utf-8")
    )
    assert options["train"]["total_iter"] == step + additional
    experiment = reopened.runs.experiment_dir(run["id"])
    assert Path(options["path"]["resume_state"]) == experiment / state_path
    assert Path(options["path"]["pretrain_network_g"]) == experiment / weights_path
    assert experiment == source_experiment

    assert reopened.post(route, body)["runId"] == run["id"]
    assert reopened.queue.dispatch_once() is None
    launch.assert_called_once()


def test_pause_preserves_attempt_order_across_restart(tmp_path, monkeypatch):
    """A queued run owns its checkpoint and its place across a Studio restart."""
    import os

    for key in (PROJECT_DIR_ENV, PROJECT_ID_ENV):
        monkeypatch.delenv(key, raising=False)
    monkeypatch.setattr(run_process, "cli_trainer_running", lambda: False)
    state = tmp_path / "state"
    queue = Services(tmp_path, state).queue
    queue.prepare = lambda text: text
    leases = []
    attempts = []

    def launch(attempt, lease, experiment, *_args, control, **_kwargs):
        leases.append(os.dup(lease))
        attempts.append((attempt, experiment, control))
        (control / "launched").touch()
        # The supervisor owns this lock independently of Studio.
        import fcntl
        supervisor = os.open(control / "supervisor.lock", os.O_RDWR | os.O_CREAT, 0o600)
        fcntl.flock(supervisor, fcntl.LOCK_EX)
        leases.append(supervisor)

    monkeypatch.setattr(run_process, "launch", launch)
    try:
        recipe = "name: {}\nnetwork_g: {{type: compact}}\npath: {{}}\ntrain: {{total_iter: 100}}\n"
        ids = [queue.submit(recipe.format(name))["id"] for name in ("first", "second", "held")]
        for entry_id in ids[:2]:
            queue.release(entry_id)
        run = queue.dispatch_once()
        attempt, experiment, control = attempts[0]
        queue.set_paused(True)
        queue = Services(tmp_path, state).queue
        queue.dispatch_once()
        assert not (control / "stop").exists()
        (control / "checkpoint-ready").touch()
        queue.dispatch_once()
        assert (control / "stop").exists()
        step = 37
        weights = experiment / "models" / f"net_g_{step}.pth"
        checkpoint = experiment / "training_states" / f"{step}.state"
        weights.parent.mkdir(parents=True)
        checkpoint.parent.mkdir()
        torch.save({"params": {"weight": torch.ones(1)}}, weights)
        torch.save({"iter": step, "epoch": 0}, checkpoint)
        run_process.write_record(attempt / "result.json", {
            "status": "stopped", "completionReason": "interrupted", "completedIteration": step
        })
        while leases:
            os.close(leases.pop())
        assert queue.dispatch_once() is None
        snapshot = queue.snapshot()
        assert snapshot["paused"] and [e["status"] for e in snapshot["entries"]] == ["pending", "pending", "held"]
        queue.set_paused(False)
        resumed = queue.dispatch_once()
        assert (resumed["id"], resumed["runId"]) == (ids[0], run["runId"])
        assert len(attempts) == 2 and attempts[1][1] == experiment
        assert read_recipe((attempts[1][0] / "options.yml").read_text())["path"]["resume_state"] == str(checkpoint)
        assert queue.dispatch_once() is None
    finally:
        while leases:
            os.close(leases.pop())
