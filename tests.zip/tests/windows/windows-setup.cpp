// Windows integration check. Link updates.cpp with the launcher's Windows SDK libraries.
// Supply an empty temporary directory. OS changes and confirmation dialogs are simulated.
#include "windows_host.cpp"

#include <iostream>
#include <optional>

namespace fixture {
using namespace host;

bool live = false, damaged = true, allow = true, wmi_available = true;
unsigned repairs = 0, enables = 0, installs = 0;
bool enabled = false;
fs::path executable;
class Dialogs : public SetupDialogs {
public:
    explicit Dialogs(bool) : SetupDialogs(false) {}
    bool confirm(const wchar_t*) { return allow; }
    void progress(const wchar_t*) {}
};
ProcessResult status() {
    if (live) return wsl_status();
    if (!damaged) return {};
    return host::capture_process(executable, {L"--emit-repair"}, 1500, nullptr, {}, {}, true);
}
bool feature() {
    if (live) return virtual_machine_platform_enabled();
    if (!wmi_available) throw std::runtime_error("WMI access denied (0x80041003)");
    return enabled;
}
DWORD enable() { ++enables; enabled = true; return ERROR_SUCCESS_REBOOT_REQUIRED; }
ProcessResult repair() { ++repairs; damaged = false; return {}; }
DWORD install() { ++installs; return 0; }
bool service(const wchar_t* name) { return live ? service_present(name) : true; }
}

#define SetupDialogs fixture::Dialogs
#define wsl_status fixture::status
#define virtual_machine_platform_enabled fixture::feature
#define enable_vm_platform fixture::enable
#define repair_wsl_package fixture::repair
#define install_wsl fixture::install
#define service_present fixture::service
#include "launcher.cpp"
#undef service_present
#undef install_wsl
#undef repair_wsl_package
#undef enable_vm_platform
#undef virtual_machine_platform_enabled
#undef wsl_status
#undef SetupDialogs

void check(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
int wmain(int argc, wchar_t** argv) {
    using namespace host;
    if (argc == 2 && wstring(argv[1]) == L"--emit-repair") {
        constexpr wchar_t prompt[] = L"WSL: Wsl/CallMsi/Install/REGDB_E_CLASSNOTREG\r\nPress any key to repair WSL.";
        DWORD written;
        WriteFile(GetStdHandle(STD_ERROR_HANDLE), prompt, sizeof(prompt) - sizeof(wchar_t), &written, nullptr);
        Sleep(10000);
        return 1;
    }
    if (argc != 2) return 2;
    try {
        fixture::executable = fs::absolute(argv[0]);
        Profile profile{fs::absolute(argv[1])};
        check(fs::is_directory(profile.folder) && fs::is_empty(profile.folder), "Use an empty scratch directory");
        fixture::Dialogs dialogs(false);
        Pending pending{profile.folder, project_id(profile.folder, true), {}, true};
        save_pending(profile, pending);
        auto run = [&](bool interactive) {
            try { prepare_windows(profile, pending, dialogs, interactive); return 0; }
            catch (const Exit& exit) { return exit.code; }
        };
        bool unattended_blocked = false;
        try { run(false); }
        catch (const std::runtime_error&) { unattended_blocked = true; }
        check(unattended_blocked && !fixture::repairs && !fixture::enables, "Unattended setup modified Windows");
        fixture::allow = false;
        check(run(true) == ERROR_CANCELLED && !fixture::repairs && !fixture::enables, "Cancellation modified Windows");
        fixture::allow = true;
        check(run(true) == ERROR_SUCCESS_REBOOT_REQUIRED && fixture::repairs == 1
              && fixture::enables == 1 && !fixture::installs, "Combined feature/registration repair failed");
        auto saved = load_pending(profile);
        check(saved.cpu_only && saved.project == pending.project && saved.project_id == pending.project_id
              && !saved.reboot_after.empty(), "Lost project or runtime at reboot boundary");
        pending = saved;
        check(run(true) == ERROR_SUCCESS_REBOOT_REQUIRED && fixture::repairs == 1 && fixture::enables == 1,
              "Repeated servicing before reboot");
        pending.reboot_after = "at:1";
        check(run(true) == 0 && load_pending(profile).reboot_after.empty(), "Failed to resume after reboot");

        fixture::wmi_available = false;
        check(run(true) == 0 && !fixture::installs && fixture::enables == 1, "Healthy WSL blocked by WMI");
        fixture::wmi_available = true;
        fixture::damaged = true;
        check(run(true) == 0 && fixture::repairs == 2 && fixture::enables == 1,
              "Package-only repair unnecessarily required reboot or feature change");
        check(read_text(profile.log()).find("REGDB_E_CLASSNOTREG") != string::npos, "Lost Windows diagnostic");
        if (GetEnvironmentVariableW(L"TRAINNER_TEST_LIVE_WSL_READONLY", nullptr, 0)) {
            fixture::live = true;
            const auto plan = inspect_windows(profile);
            std::cout << "Live read-only WSL status exit " << wsl_status().code
                      << ", Windows build " << windows_build_number()
                      << ", platform enabled " << virtual_machine_platform_enabled()
                      << ", ready " << (plan.action == WslAction::ready) << '\n';
            check(plan.action == WslAction::ready, "Expected configured WSL host");
        }
        std::cout << "Windows prerequisite and repair scenarios passed.\n";
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
