"""One shared image inventory exercises the three supervised provider selections."""

import hashlib
import json
from pathlib import Path

from PIL import Image
from studio.split_audit import audit_split_leakage


def test_supervised_image_leakage(tmp_path: Path) -> None:
    def write_image(split: str, relative: str, color: str) -> Path:
        path = tmp_path / split / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        Image.new("RGB", (3, 2), color).save(path)
        return path

    original = write_image("train", "cat/nested/shared.bmp", "red")
    blue = write_image("train", "dog/shared.bmp", "blue")
    control = write_image("val", "cat/nested/shared.bmp", "lime")
    copy = write_image("val", "dog/renamed.bmp", "red")
    copy.write_bytes(original.read_bytes())
    reencoded = write_image("val", "dog/also-blue.png", "blue")
    assert original.stat().st_size == control.stat().st_size
    digest = hashlib.sha256(original.read_bytes()).hexdigest()

    for path in (original, blue, control, copy, reencoded):
        split, *relative = path.relative_to(tmp_path).parts
        mask = tmp_path.joinpath(split + "-masks", *relative).with_suffix(".png")
        mask.parent.mkdir(parents=True, exist_ok=True)
        Image.new("L", (3, 2), 1).save(mask)

    # Two train image IDs refer to one file. Validation also lists an empty
    # image with an ID used in train. Unlisted files stay outside this selection.
    for split, filenames in (
        ("train", ["cat/nested/shared.bmp", "cat/nested/shared.bmp"]),
        ("val", ["cat/nested/shared.bmp", "dog/renamed.bmp"]),
    ):
        document = {
            "categories": [{"id": 7, "name": "object"}],
            "images": [
                {"id": i, "file_name": name, "width": 3, "height": 2}
                for i, name in enumerate(filenames, 1)
            ],
            "annotations": [
                {
                    "id": 1,
                    "image_id": 2,
                    "category_id": 7,
                    "bbox": [0, 0, 1, 1],
                    "iscrowd": 1,
                }
            ],
        }
        (tmp_path / f"{split}.json").write_text(json.dumps(document))

    for task, provider in (
        ("image_classification", "ClassFolderDataset"),
        ("semantic_segmentation", "ImageMaskDataset"),
        ("object_detection", "CocoDetectionDataset"),
    ):
        detection = task == "object_detection"
        datasets = {}
        for split in ("train", "val"):
            dataset = {"type": provider, "dataroot_lq": split}
            if task == "semantic_segmentation":
                dataset.update(dataroot_gt=split + "-masks", lq_size=2)
            if detection:
                dataset["annotation_file"] = split + ".json"
            datasets[split] = dataset
        report = audit_split_leakage(
            {
                "task": task,
                "datasets": datasets,
                "task_options": {"categories": [{"id": 7, "name": "object"}]}
                if detection
                else {"class_names": ["cat", "dog"]},
            },
            root=tmp_path,
            scratch_dir=tmp_path,
        )
        assert report["complete"], report["issues"]
        assert report["hasTrainValidationOverlap"]
        assert report["counts"]["sources"] == (3 if detection else 5)
        train, val = (entry["counts"] for entry in report["splits"])
        assert (train["samples"], train["sources"], val["samples"], val["sources"]) == (
            (2, 1, 2, 2) if detection else (2, 2, 3, 3)
        )
        assert train["trainValidationSamples"] == (2 if detection else 1)
        assert train["trainValidationSources"] == val["trainValidationSources"] == 1
        assert val["trainValidationSamples"] == 1
        (group,) = report["groups"]
        assert group["sha256"] == digest
        assert group["trainValidation"] and group["withinSplit"] == detection
        assert group["inputs"] == group["samples"] == (3 if detection else 2)
        assert all(row["role"] == "image" for row in group["examples"])
        context = [row["labelContext"] for row in group["examples"]]
        if detection:
            assert [entry["cocoImageId"] for entry in context] == [1, 2, 2]
        elif task == "image_classification":
            assert [entry["className"] for entry in context] == ["cat", "dog"]
        else:
            assert [entry["maskRelativePath"] for entry in context] == [
                "cat/nested/shared.png",
                "dog/renamed.png",
            ]
