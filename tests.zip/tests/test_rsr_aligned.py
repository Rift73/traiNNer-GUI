"""CPU tests of RSR's aligned temporal read (traiNNer.archs.rsr_arch)."""

from __future__ import annotations

import io
import os
from collections.abc import Callable

import pytest
import torch
from safetensors.torch import load_file
from torch import Tensor, nn
from traiNNer.archs.rsr_arch import RSR, flow_working_factor, rsr_compact
from traiNNer.archs.wsr_arch import wsr_compact

NEUFLOW_PATH = "experiments/pretrained_models/neuflow_v2.safetensors"

NEW_KEYS = {
    "blend_reverse.weight",
    "blend_reverse.bias",
    "blend_forward.weight",
    "blend_forward.bias",
    "confidence_past",
    "confidence_future",
    "flow_loaded",
}

CUT_FOUR = [[0, 0, 1, 1], [2, 2, 2, 2]]


def _open_weights(model: nn.Module, seed: int) -> None:
    """Perturb every parameter so WSR's zero-initialized paths are active."""
    generator = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn(parameter.shape, generator=generator) * 0.02)


def _pair(scale: int = 2, seed: int = 0) -> tuple[nn.Module, RSR, list[str]]:
    """A WSR Compact with open weights, an aligned RSR holding the same weights
    and the keys that loading left missing."""
    torch.manual_seed(seed)
    wsr = wsr_compact(scale=scale).eval()
    _open_weights(wsr, seed + 1)
    rsr = rsr_compact(scale=scale, temporal_read="aligned").eval()
    result = rsr.load_state_dict(wsr.state_dict(), strict=False)
    assert not result.unexpected_keys
    return wsr, rsr, result.missing_keys


def _aligned_model(scale: int = 2, seed: int = 0, blend_scale: float = 0.05) -> RSR:
    """An aligned RSR whose blends read the neighbours."""
    _, rsr, _ = _pair(scale, seed)
    generator = torch.Generator().manual_seed(seed + 2)
    with torch.no_grad():
        for blend in (rsr.blend_reverse, rsr.blend_forward):
            for parameter in (blend.weight, blend.bias):
                parameter.copy_(
                    torch.randn(parameter.shape, generator=generator) * blend_scale
                )
        rsr.confidence_past.fill_(-0.3)
        rsr.confidence_future.fill_(0.2)
    return rsr


def _clip(batch: int, frames: int, height: int, width: int, seed: int) -> Tensor:
    generator = torch.Generator().manual_seed(seed)
    return torch.rand(batch, frames, 3, height, width, generator=generator)


def _guidance(batch: int, frames: int, height: int, width: int, seed: int) -> Tensor:
    """Random guidance: flows within three grid pixels, inconsistency below two."""
    generator = torch.Generator().manual_seed(seed)
    flow = (
        torch.rand(batch, frames, 2, 2, height, width, generator=generator) - 0.5
    ) * 6
    error = torch.rand(batch, frames, 2, 1, height, width, generator=generator) * 2
    return torch.cat((flow, error), dim=3)


def test_keys_and_start_equal_wsr_compact() -> None:
    wsr, rsr, missing = _pair()
    assert {k for k in missing if not k.startswith("flow.")} == NEW_KEYS
    assert any(k.startswith("flow.") for k in missing)
    keys = set(rsr.state_dict())
    assert not any(k.startswith("attention.key_value_") for k in keys)
    assert not {"attention.null_key", "attention.temporal_gain"} & keys
    clip = _clip(2, 3, 21, 27, seed=1)
    guidance = _guidance(2, 3, 11, 14, seed=2)
    with torch.no_grad():
        result = rsr(clip, torch.tensor([[0, 0, 1], [2, 2, 2]]), guidance)
        for t in range(clip.shape[1]):
            frame = clip[:, t].contiguous()
            expected = wsr(frame)
            assert torch.equal(result[:, t], expected)
            assert torch.equal(rsr(frame), expected)


@pytest.mark.parametrize(
    ("size", "grid"),
    [
        ((24, 32), (24, 32)),
        ((37, 45), (37, 45)),
        ((24, 32), (12, 16)),
        ((37, 45), (18, 22)),
    ],
)
def test_warp_moves_the_state_by_the_flow(
    size: tuple[int, int], grid: tuple[int, int]
) -> None:
    height, width = size
    shift_x, shift_y = 3, -2
    generator = torch.Generator().manual_seed(3)
    state = torch.randn(2, 4, height, width, generator=generator)
    # The flow is in grid pixels: one frame pixel is width / grid width of them.
    guidance = torch.zeros(2, 3, *grid)
    guidance[:, 0] = shift_x * grid[1] / width
    guidance[:, 1] = shift_y * grid[0] / height
    read = RSR.aligned_read(
        torch.zeros_like(state), state, None, guidance, torch.tensor(0.0)
    )
    # Pixel p reads p + (3, -2) of the state.
    expected = torch.tanh(state)[..., : height + shift_y, shift_x:]
    torch.testing.assert_close(
        read[..., -shift_y:, : width - shift_x], expected, rtol=0, atol=1e-5
    )


def test_inconsistency_validity_and_absence_close_the_read() -> None:
    generator = torch.Generator().manual_seed(4)
    state = torch.randn(2, 4, 16, 20, generator=generator)
    current = torch.zeros_like(state)
    guidance = torch.zeros(2, 3, 16, 20)
    open_read = RSR.aligned_read(current, state, None, guidance, torch.tensor(0.0))
    assert open_read.abs().sum() > 0
    guidance[:, 2] = 100.0
    assert not RSR.aligned_read(current, state, None, guidance, torch.tensor(0.0)).any()
    wild = torch.full((2, 3, 16, 20), 1e30)
    closed = RSR.aligned_read(
        current, state, torch.tensor([False, True]), wild, torch.tensor(0.0)
    )
    assert not closed[0].any()
    assert not RSR.aligned_read(current, None, None, None, torch.tensor(0.0)).any()


def test_shots_do_not_affect_each_other() -> None:
    model = _aligned_model()
    clip = _clip(2, 4, 21, 27, seed=5)
    guidance = _guidance(2, 4, 21, 27, seed=6)
    shot_ids = torch.tensor(CUT_FOUR)
    with torch.no_grad():
        result = model(clip, shot_ids, guidance)
        changed = clip.clone()
        changed[0, 2:] = torch.rand_like(changed[0, 2:])
        other = model(changed, shot_ids, guidance)
        assert torch.equal(other[0, :2], result[0, :2])
        changed = clip.clone()
        changed[0, :2] = torch.rand_like(changed[0, :2])
        other = model(changed, shot_ids, guidance)
        assert torch.equal(other[0, 2:], result[0, 2:])
        # Without the cut the neighbours are read.
        assert not torch.equal(model(changed, None, guidance)[0, 2:], result[0, 2:])


def test_guidance_has_no_flow_across_cuts_and_clip_ends() -> None:
    model = rsr_compact(scale=2, temporal_read="aligned")
    # The randomly initialized flow estimator stands in for the real weights.
    model.flow_loaded.fill_(True)
    clip = _clip(2, 4, 24, 40, seed=8)
    shot_ids = torch.tensor(CUT_FOUR)
    guidance = model.guidance(clip, shot_ids)
    assert guidance.shape == (2, 4, 2, 3, 24, 40)
    assert torch.isfinite(guidance).all()
    assert not guidance[:, 0, 0].any() and not guidance[:, -1, 1].any()
    assert not guidance[0, 1, 1].any() and not guidance[0, 2, 0].any()
    assert guidance[1, 1, 1].any() and guidance[1, 2, 0].any()
    changed = clip.clone()
    changed[0, 2:] = torch.rand_like(changed[0, 2:])
    other = model.guidance(changed, shot_ids)
    assert torch.equal(other[0, :2], guidance[0, :2])


def test_long_chain_stays_finite() -> None:
    model = _aligned_model(blend_scale=2.0)
    clip = _clip(1, 48, 16, 20, seed=9)
    guidance = _guidance(1, 48, 16, 20, seed=10)
    with torch.no_grad():
        result = model(clip, None, guidance)
    assert torch.isfinite(result).all()


def _frame_loss(targets: Tensor) -> Callable[[Tensor, int], Tensor]:
    def loss(output: Tensor, t: int) -> Tensor:
        return (output - targets[:, t]).square().mean() * (1.0 + 0.5 * t)

    return loss


def _gradients(model: nn.Module) -> dict[str, Tensor | None]:
    return {
        name: None if p.grad is None else p.grad.clone()
        for name, p in model.named_parameters()
        if p.requires_grad
    }


@pytest.mark.parametrize("keep", ["none", "reverse", "both"])
def test_backward_clip_is_exact_in_float64(keep: str) -> None:
    model = _aligned_model().train().double()
    clip = _clip(2, 4, 21, 27, seed=11).double()
    guidance = _guidance(2, 4, 11, 14, seed=12).double()
    shot_ids = torch.tensor(CUT_FOUR)
    targets = torch.rand(2, 4, 3, 42, 54, dtype=torch.float64)
    loss = _frame_loss(targets)

    leaf = clip.clone().requires_grad_()
    output = model(leaf, shot_ids, guidance)
    sum(
        (loss(output[:, t], t) for t in range(4)), torch.zeros((), dtype=torch.float64)
    ).backward()
    expected = _gradients(model)
    expected_input = leaf.grad
    model.zero_grad(set_to_none=True)

    leaf = clip.clone().requires_grad_()
    actual_output = model.backward_clip(
        leaf,
        loss,
        shot_ids=shot_ids,
        guidance=guidance,
        keep=keep,
        encode_chunk=3,
        grad_chunk=2,
    )
    torch.testing.assert_close(actual_output, output.detach(), rtol=1e-10, atol=1e-12)
    actual = _gradients(model)
    for name in ("blend_forward.weight", "blend_reverse.weight", "confidence_past"):
        assert expected[name] is not None and expected[name].abs().sum() > 0, name
    for name, value in expected.items():
        other = actual[name]
        if value is None:
            assert other is None or not other.any(), name
        else:
            assert other is not None, name
            torch.testing.assert_close(other, value, rtol=1e-9, atol=1e-12, msg=name)
    assert leaf.grad is not None and expected_input is not None
    torch.testing.assert_close(leaf.grad, expected_input, rtol=1e-9, atol=1e-12)


@pytest.mark.parametrize(("chunk", "lookahead"), [(1, 4), (2, 3), (3, 2), (5, 0)])
def test_infer_in_chunks_equals_forward(chunk: int, lookahead: int) -> None:
    model = _aligned_model()
    clip = _clip(2, 5, 21, 27, seed=13)
    guidance = _guidance(2, 5, 21, 27, seed=14)
    shot_ids = torch.tensor([[0, 0, 0, 1, 1], [2, 2, 2, 2, 2]])
    with torch.no_grad():
        expected = model(clip, shot_ids, guidance)
        actual = model.infer(clip, chunk, lookahead, shot_ids, guidance)
    assert torch.equal(actual, expected)


def test_infer_computes_the_flow_across_chunk_edges() -> None:
    model = _aligned_model()
    # The randomly initialized flow estimator stands in for the real weights.
    model.flow_loaded.fill_(True)
    clip = _clip(1, 5, 24, 32, seed=16)
    with torch.no_grad():
        expected = model(clip)
        actual = model.infer(clip, 2, 3)
    # Each chunk runs the flow on its own pairs: rounding only.
    torch.testing.assert_close(actual, expected, rtol=0, atol=1e-5)


def test_flow_is_frozen_and_saved() -> None:
    model = _aligned_model().train()
    assert not model.flow.training
    trainable = {name for name, p in model.named_parameters() if p.requires_grad}
    assert trainable and not any(name.startswith("flow.") for name in trainable)
    clip = _clip(1, 3, 16, 20, seed=17)
    guidance = _guidance(1, 3, 16, 20, seed=18)
    model(clip, None, guidance).square().mean().backward()
    assert all(p.grad is None for p in model.flow.parameters())
    model.flow_loaded.fill_(True)
    buffer = io.BytesIO()
    torch.save(model.state_dict(), buffer)
    buffer.seek(0)
    state = torch.load(buffer)
    assert any(k.startswith("flow.") for k in state) and bool(state["flow_loaded"])
    other = rsr_compact(scale=2, temporal_read="aligned")
    other.load_state_dict(state, strict=True)
    assert bool(other.flow_loaded)
    for name, value in model.flow.state_dict().items():
        assert torch.equal(other.flow.state_dict()[name], value), name


def test_guidance_needs_flow_weights_and_export_is_refused() -> None:
    model = rsr_compact(scale=2, temporal_read="aligned").eval()
    with pytest.raises(RuntimeError, match="no NeuFlow v2 weights"):
        model(_clip(1, 2, 16, 20, seed=19))
    with pytest.raises(NotImplementedError):
        model.prepare_for_export()


@pytest.mark.parametrize(
    ("short", "factor"), [(192, 1), (270, 1), (360, 1), (540, 2), (1080, 4)]
)
def test_working_size_rule(short: int, factor: int) -> None:
    assert flow_working_factor(short, short * 16 // 9) == factor
    assert flow_working_factor(short * 16 // 9, short) == factor


@pytest.mark.skipif(not os.path.exists(NEUFLOW_PATH), reason="no NeuFlow v2 weights")
def test_translated_pair_gives_the_translation() -> None:
    model = rsr_compact(scale=2, temporal_read="aligned")
    model.load_flow_weights(load_file(NEUFLOW_PATH))
    generator = torch.Generator().manual_seed(20)
    texture = torch.nn.functional.interpolate(
        torch.rand(1, 3, 40, 48, generator=generator),
        size=(160, 192),
        mode="bicubic",
        align_corners=False,
    ).clamp(0, 1)
    shift_x, shift_y = 3, 2
    later = texture.roll((shift_y, shift_x), dims=(2, 3))
    guidance = model.guidance(torch.stack((texture, later), dim=1))
    # Frame 0's future flow: pixel p of frame 0 sits at p + shift in frame 1.
    inner = guidance[0, 0, 1, :, 16:-16, 16:-16]
    assert abs(float(inner[0].median()) - shift_x) < 0.5
    assert abs(float(inner[1].median()) - shift_y) < 0.5
    assert float(inner[2].median()) < 0.5
    inner = guidance[0, 1, 0, :, 16:-16, 16:-16]
    assert abs(float(inner[0].median()) + shift_x) < 0.5
    assert abs(float(inner[1].median()) + shift_y) < 0.5
