import pytest
import torch
import torchvision
from torch import nn
from torchvision.models.vgg import make_layers

from traiNNer.losses import build_loss


@pytest.mark.skipif(not torch.cuda.is_available(), reason="requires CUDA")
def test_vgg_input_gradient_matches_native_after_loading_weights(monkeypatch):
    pytest.importorskip("tensorrt")

    def small_vgg19(*, weights):
        model = nn.Module()
        model.features = make_layers(
            [8, 8, "M", 8, 8, "M", 8, 8, 8, 8, "M", 8, 8, 8, 8, "M", 8, 8, 8, 8]
        )
        return model

    monkeypatch.setattr(torchvision.models, "vgg19", small_vgg19)
    options = {"type": "perceptualloss", "loss_weight": 1.0}
    native = build_loss(options).cuda()
    optimized = build_loss({**options, "tensorrt_fp16_backward": True}).cuda()
    rng = torch.Generator(device="cuda").manual_seed(37)
    target = torch.rand((1, 3, 32, 48), generator=rng, device="cuda")
    image = (
        target + 0.001 * torch.randn(target.shape, generator=rng, device="cuda")
    ).requires_grad_()

    def gradient(loss):
        value = sum(loss(image, target).values())
        return value.detach(), torch.autograd.grad(value, image)[0]

    gradient(optimized)  # Build from the initial weights before replacing them.
    optimized.load_state_dict(native.state_dict())
    ref_value, ref_gradient = gradient(native)
    value, result = gradient(optimized)
    torch.testing.assert_close(value, ref_value)
    assert (result - ref_gradient).norm() < 0.008 * ref_gradient.norm()
    with torch.no_grad():
        image.copy_(target)
    assert gradient(optimized)[1].count_nonzero() == 0
