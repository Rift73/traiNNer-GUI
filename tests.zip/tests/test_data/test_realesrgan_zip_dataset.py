import random
from pathlib import Path
from zipfile import ZIP_STORED, ZipFile

import numpy as np
import torch
from PIL import Image
from torch.utils.data import default_collate
from traiNNer.data import build_dataloader, build_dataset
from traiNNer.data.data_sampler import EnlargedSampler
from traiNNer.utils.redux_options import DatasetOptions
from traiNNer.utils.rng import RNG
from traiNNer.utils.types import DataFeed


def _collate_with_rng(samples: list[DataFeed]) -> tuple:
    # Observe the worker's continuation after the same samples the loader returns.
    return (
        default_collate(samples),
        random.getstate(),
        RNG.get_rng().bit_generator.state,
    )


def test_otf_zip_manifest_matches_loose_samples_and_worker_rng(tmp_path: Path) -> None:
    loose_root = tmp_path / "loose"
    (loose_root / "set").mkdir(parents=True)
    selected = ["set/wide crop.png", "set/tall pad.png"]
    decoy = "set/excluded.png"
    for variant, (name, (height, width)) in enumerate(
        zip([*selected, decoy], [(92, 107), (91, 39), (80, 80)], strict=True)
    ):
        y, x = np.indices((height, width))
        pixels = np.stack((3 * x + variant, 5 * y, x + y + 7 * variant), axis=-1)
        Image.fromarray(pixels.astype(np.uint8)).save(loose_root / name)

    archive = tmp_path / "images.zip"
    with ZipFile(archive, "w", compression=ZIP_STORED) as output:
        for name in [decoy, *reversed(selected)]:
            output.write(loose_root / name, name)
    manifest = tmp_path / "selected.txt"
    manifest.write_text("\n".join(selected) + "\n", encoding="utf-8")

    def load(root: Path, backend: str) -> list:
        options = DatasetOptions(
            name="selected images",
            type="RealESRGANDataset",
            phase="train",
            dataroot_gt=[str(root)],
            io_backend={"type": backend},
            meta_info=str(manifest),
            scale=2,
            gt_size=32,
            num_worker_per_gpu=1,
            batch_size_per_gpu=2,
            persistent_workers=False,
            pin_memory=False,
        )
        dataset = build_dataset(options)
        dataset.collate_fn = _collate_with_rng
        sampler = EnlargedSampler(dataset, num_replicas=1, rank=0, ratio=2)
        loader = build_dataloader(dataset, options, num_gpu=0, sampler=sampler, seed=31)
        expected = [selected[index] for index in sampler]
        observed = []
        batches = []
        for batch, python_rng, project_rng in loader:
            paths = batch.pop("gt_path")
            if backend == "zip":
                observed.extend(path.split("!/", maxsplit=1)[1] for path in paths)
            else:
                observed.extend(
                    Path(path).relative_to(root).as_posix() for path in paths
                )
            batches.append((batch, python_rng, project_rng))
        assert len(dataset) == len(selected)
        assert observed == expected
        return batches

    loose_batches = load(loose_root, "disk")
    zip_batches = load(archive, "zip")
    for loose, zipped in zip(loose_batches, zip_batches, strict=True):
        loose_batch, loose_python, loose_project = loose
        zip_batch, zip_python, zip_project = zipped
        assert set(loose_batch) == set(zip_batch)
        for key in loose_batch:
            torch.testing.assert_close(loose_batch[key], zip_batch[key], rtol=0, atol=0)
        assert loose_python == zip_python
        assert loose_project == zip_project
