"""DUAL routing_na and regional_na: defaults, validation, cache tag, limits, the
per-position definitions, the path each call takes, the regional kernels and both
switches together."""

import math

import pytest
import torch
from torch.nn import functional
from traiNNer.archs import dual_arch as dual
from traiNNer.archs.dual_arch import _HAS_DIRECT_ATTENTION, _premixed_conv3x3

# Measured kernel-against-reference maxima (relative to the largest value) are up
# to 7.6e-3 in BF16 and 2.5e-3 in FP16; 1.5e-2 leaves a factor of two.
KERNEL_TOLERANCE = 1.5e-2


def light(lq: int, width: int, **switches) -> tuple[torch.Tensor, torch.Tensor]:
    torch.manual_seed(0)
    model = dual.dual_light(scale=1, use_checkpoint=False, **switches).double()
    with torch.no_grad():
        for parameter in model.parameters():
            if parameter.abs().max() == 0:
                parameter.normal_(0, 0.02)
    x = torch.rand(1, 3, lq, width, dtype=torch.float64, generator=torch.Generator().manual_seed(1))
    y = model(x)
    y.square().mean().backward()
    grads = torch.cat([p.grad.flatten() for p in model.parameters() if p.grad is not None])
    return y.detach(), grads


def regional(channels: int = 64, heads: int = 2, dtype: torch.dtype = torch.float64) -> dual.RegionalChannelAttention:
    torch.manual_seed(4)
    module = dual.RegionalChannelAttention(channels, heads).to(dtype)
    module.regional_na = True
    with torch.no_grad():
        module.theta.normal_(0, 1)
    return module


def blend(module: dual.RegionalChannelAttention, *qkv: torch.Tensor) -> torch.Tensor:
    module.regional_na = False
    try:
        return module.mix(*qkv)
    finally:
        module.regional_na = True


def test_defaults_validation_and_cache_tag() -> None:
    with torch.device("meta"):
        model = dual.dual_light(scale=2)
        both = dual.dual_light(scale=2, routing_na=True, regional_na=True)
    assert not model.routing_na and not model.regional_na
    assert both.state_dict().keys() == model.state_dict().keys()
    assert "routing-na" not in model.compile_cache_key_tag
    assert "regional-na" not in model.compile_cache_key_tag
    assert both.compile_cache_key_tag.endswith(":routing-na:regional-na")
    assert all(m.regional_na for m in both.modules() if isinstance(m, dual.RegionalChannelAttention))
    assert all(m.routing_na for m in both.modules() if isinstance(m, dual.DynamicRouter))
    for name in ("routing_na", "regional_na"):
        with pytest.raises(ValueError, match=name):
            dual.dual_light(scale=2, **{name: 1})


@pytest.mark.parametrize(
    ("switch", "lq", "width"), [("regional_na", 32, 32), ("routing_na", 64, 72)]
)
def test_maps_within_reach_keep_the_function(switch: str, lq: int, width: int) -> None:
    """Light's trunk is half the LQ: regional 16 and routing 96 per axis or less."""
    off, on = light(lq, width), light(lq, width, **{switch: True})
    for a, b in zip(off, on, strict=True):
        torch.testing.assert_close(a, b, atol=0, rtol=0)


@pytest.mark.parametrize("training", [True, False])
def test_regional_reads_each_position_clamped_32x32_window(training: bool) -> None:
    """On the CPU, in training and in eval, the switch runs the per-position form."""
    module = regional().train(training)
    h, w = 36, 44
    q, k, v = (torch.randn(1, 64, h, w, dtype=torch.float64) for _ in range(3))
    out = module.mix(q, k, v)
    assert not torch.allclose(out, blend(module, q, k, v))
    for y, x in ((0, 0), (h - 1, w - 1), (17, 5), (35, 22)):
        sy, sx = min(max(y - 16, 0), h - 32), min(max(x - 16, 0), w - 32)
        for head in range(2):
            c = slice(32 * head, 32 * head + 32)
            qw = q[0, c, sy : sy + 32, sx : sx + 32].reshape(32, -1)
            kw = k[0, c, sy : sy + 32, sx : sx + 32].reshape(32, -1)
            qn = (qw.square().sum(1) + 1024e-6).sqrt()
            kn = (kw.square().sum(1) + 1024e-6).sqrt()
            tau = module.theta[head].clamp(max=math.log(100)).exp()
            a = (tau * (qw @ kw.T) / (qn[:, None] * kn[None, :])).softmax(1)
            torch.testing.assert_close(out[0, c, y, x], a @ v[0, c, y, x], atol=1e-12, rtol=1e-10)


@pytest.mark.parametrize("flag", ["torch.onnx.is_in_onnx_export", "torch.compiler.is_exporting"])
def test_regional_export_keeps_the_blend(flag: str, monkeypatch: pytest.MonkeyPatch) -> None:
    module = regional().eval()
    q, k, v = (torch.randn(1, 64, 36, 44, dtype=torch.float64) for _ in range(3))
    expected = blend(module, q, k, v)
    monkeypatch.setattr(flag, lambda: True)
    torch.testing.assert_close(module.mix(q, k, v), expected, atol=0, rtol=0)


def test_regional_other_head_widths_keep_the_blend() -> None:
    module = regional(channels=64, heads=4)
    q, k, v = (torch.randn(1, 64, 36, 44, dtype=torch.float64) for _ in range(3))
    torch.testing.assert_close(module.mix(q, k, v), blend(module, q, k, v), atol=0, rtol=0)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
@pytest.mark.parametrize(
    ("batch", "height", "width", "dtype", "channels", "heads", "channels_last"),
    [
        (2, 40, 56, torch.bfloat16, 128, 4, False),
        (1, 72, 40, torch.bfloat16, 128, 4, False),  # over 64 rows: the ring drops old windows
        (3, 32, 40, torch.bfloat16, 128, 4, False),  # one side exactly one window
        (2, 40, 56, torch.float16, 128, 4, False),
        (2, 40, 56, torch.bfloat16, 128, 4, True),
        (2, 40, 56, torch.bfloat16, 160, 5, False),
    ],
)
def test_regional_kernel_matches_reference_output_and_gradients(
    batch: int, height: int, width: int, dtype: torch.dtype, channels: int, heads: int, channels_last: bool
) -> None:
    pytest.importorskip("triton")
    if not _HAS_DIRECT_ATTENTION:
        pytest.skip("needs the bundled Triton kernels")
    module = regional(channels, heads, torch.float32).cuda()
    torch.manual_seed(6)
    q, k, v = (torch.randn(batch, channels, height, width, device="cuda").to(dtype) for _ in range(3))
    if channels_last:
        q, k, v = (t.contiguous(memory_format=torch.channels_last) for t in (q, k, v))
    signal = torch.randn(batch, channels, height, width, device="cuda")
    results = []
    # Training takes the kernels; eval takes the reference form on the same inputs.
    for training in (True, False):
        module.train(training)
        leaves = [t.detach().clone().requires_grad_() for t in (q, k, v)]
        module.theta.grad = None
        out = module.mix(*leaves)
        (out.float() * signal).sum().backward()
        results.append([out.float()] + [t.grad.float() for t in leaves] + [module.theta.grad.clone()])
    for got, want in zip(*results, strict=True):
        error = (got - want).abs().max() / want.abs().max()
        assert error < KERNEL_TOLERANCE, float(error)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
def test_regional_kernels_in_the_model_match_the_reference_form() -> None:
    """dual_light, trunk 40 x 48, one BF16 training step: kernels against the
    reference form (the regional modules alone in eval mode, which takes it)."""
    pytest.importorskip("triton")
    if not _HAS_DIRECT_ATTENTION:
        pytest.skip("needs the bundled Triton kernels")
    x = torch.rand(1, 3, 80, 96, device="cuda", generator=torch.Generator("cuda").manual_seed(1))
    runs = []
    for kernels in (True, False):
        torch.manual_seed(0)
        model = dual.dual_light(scale=1, regional_na=True).cuda().train()
        if not kernels:
            for module in model.modules():
                if isinstance(module, dual.RegionalChannelAttention):
                    module.eval()
        with torch.autocast("cuda", dtype=torch.bfloat16):
            y = model(x).float()
        y.square().mean().backward()
        runs.append((y.detach(), torch.cat([p.grad.flatten() for p in model.parameters() if p.grad is not None])))
    (y_kernel, g_kernel), (y_reference, g_reference) = runs
    assert float((y_kernel - y_reference).abs().max() / y_reference.abs().max()) < KERNEL_TOLERANCE
    assert float((g_kernel - g_reference).norm() / g_reference.norm()) < KERNEL_TOLERANCE


def test_routing_reads_each_position_clamped_96x96_mean() -> None:
    torch.manual_seed(5)
    router = dual.DynamicRouter(16, 3).double()
    router.routing_na = True
    with torch.no_grad():
        router.fc2.bias.normal_(0, 0.5)
    h, w = 100, 104
    x = torch.randn(1, 16, h, w, dtype=torch.float64)
    experts = torch.randn(3, 16, 16 * 9, dtype=torch.float64) * 0.05
    w0 = torch.randn(16, 16, 3, 3, dtype=torch.float64) * 0.1
    b0 = torch.randn(16, dtype=torch.float64)
    out = _premixed_conv3x3(x, w0, b0, experts, router(x))
    base = functional.conv2d(x, w0, b0, padding=1)
    convs = [functional.conv2d(x, experts[i].reshape(16, 16, 3, 3), padding=1) for i in range(3)]
    for y, xx in ((0, 0), (h - 1, w - 1), (50, 7), (3, 99)):
        sy, sx = min(max(y - 48, 0), h - 96), min(max(xx - 48, 0), w - 96)
        mean = x[0, :, sy : sy + 96, sx : sx + 96].mean((1, 2))
        hidden = functional.gelu(
            functional.linear(functional.layer_norm(mean, (16,), eps=1e-5), router.fc1.weight, router.fc1.bias)
        )
        c = functional.linear(hidden, router.fc2.weight, router.fc2.bias).softmax(-1) - 1 / 3
        ref = base[0, :, y, xx] + sum(c[i] * convs[i][0, :, y, xx] for i in range(3))
        torch.testing.assert_close(out[0, :, y, xx], ref, atol=1e-12, rtol=1e-10)


def test_both_switches_train_together() -> None:
    """LQ 196 x 34 (trunk 98 x 17): both per-position forms active; one FP32 CPU step."""
    torch.manual_seed(0)
    model = dual.dual_light(scale=1, use_checkpoint=False, routing_na=True, regional_na=True)
    x = torch.rand(1, 3, 196, 34, generator=torch.Generator().manual_seed(1))
    y = model(x)
    y.square().mean().backward()
    grads = [p.grad for p in model.parameters() if p.grad is not None]
    assert torch.isfinite(y).all() and all(torch.isfinite(g).all() for g in grads)


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA inference")
def test_batched_dual_validation_matches_eager_on_partial_windows(monkeypatch: pytest.MonkeyPatch) -> None:
    if not _HAS_DIRECT_ATTENTION or torch.cuda.get_device_capability() != (12, 0):
        pytest.skip("the fused BF16 inference path targets SM120")
    torch.manual_seed(604)
    model = dual.dual_light(scale=2, routing_na=True).eval().cuda()
    # An odd, non-square pair exercises the final partial tile and both batches.
    image = torch.randn(2, 3, 67, 197, device="cuda").contiguous(memory_format=torch.channels_last)
    with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
        actual = model(image)
        with monkeypatch.context() as patch:
            patch.setattr(dual, "_cuda_eval_supported", lambda tensor: False)
            reference = model(image)
    torch.testing.assert_close(actual, reference, rtol=0, atol=0)
