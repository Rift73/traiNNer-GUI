from collections.abc import Iterator
from copy import deepcopy
from typing import cast
from unittest.mock import Mock

import pytest
import torch
from ema_pytorch import EMA
from torch import Tensor, nn
from torch.amp.grad_scaler import GradScaler
from torch.nn.utils import get_total_norm
from torch.optim import AdamW, NAdam
from torch.optim.lr_scheduler import MultiStepLR
from torch.optim.optimizer import Optimizer
from torch.utils import deterministic
from traiNNer.models.base_model import BaseModel
from traiNNer.models.sr_model import SRModel, _get_total_gradient_norm
from traiNNer.optimizers import build_optimizer
from traiNNer.utils.misc import _UninitializedFillSetting

requires_cuda = pytest.mark.skipif(
    not torch.cuda.is_available(), reason="fused Adam needs CUDA tensors"
)
DEVICES = ["cpu", pytest.param("cuda", marks=requires_cuda)]


class SmallNet(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.head = nn.Conv2d(3, 8, 3, padding=1)
        self.norm = nn.BatchNorm2d(8)
        self.body = nn.Sequential(nn.Conv2d(8, 8, 3, padding=1), nn.Linear(4, 4))
        self.tail = nn.Conv2d(8, 3, 1)


def make_parameters(device: str) -> list[nn.Parameter]:
    torch.manual_seed(3)
    net = SmallNet().to(device)
    return list(net.parameters())


def set_gradients(params: list[nn.Parameter], seed: int) -> None:
    generator = torch.Generator().manual_seed(seed)
    for param in params:
        param.grad = (
            torch.randn(param.shape, generator=generator).to(param.device) * 1e-2
        )


def make_ema(use_foreach: bool, update_after_step: int, device: str) -> EMA:
    torch.manual_seed(5)
    net = SmallNet()
    ema = EMA(
        net,
        beta=0.999,
        allow_different_devices=True,
        update_after_step=update_after_step,
        update_every=1,
        power=0.75,
        use_foreach=use_foreach,
    ).to(device=torch.device(device))
    # As the trainer keeps them: the step counters live on the CPU.
    ema.step = ema.step.to(device=torch.device("cpu"))
    ema.initted = ema.initted.to(device=torch.device("cpu"))
    return ema


def perturb_online_model(ema: EMA, seed: int) -> None:
    generator = torch.Generator().manual_seed(seed)
    with torch.no_grad():
        for _, tensor in [
            *ema.model.named_parameters(),
            *ema.model.named_buffers(),
        ]:
            if tensor.is_floating_point():
                noise = torch.randn(tensor.shape, generator=generator) * 1e-2
                tensor.add_(noise.to(tensor.device))


def assert_same_state(first: nn.Module, second: nn.Module) -> None:
    first_state = first.state_dict()
    second_state = second.state_dict()
    assert first_state.keys() == second_state.keys()
    for key, value in first_state.items():
        assert torch.equal(value, second_state[key]), key


@pytest.mark.parametrize("device", DEVICES)
@pytest.mark.parametrize("update_after_step", [0, 4])
@pytest.mark.parametrize("use_foreach", [False, True])
def test_ema_update_matches_library(
    device: str, update_after_step: int, use_foreach: bool
) -> None:
    reference = make_ema(use_foreach, update_after_step, device)
    candidate = make_ema(use_foreach, update_after_step, device)
    library_update = Mock(wraps=candidate.update)
    candidate.update = library_update
    model = object.__new__(BaseModel)

    for update in range(20):
        if update == 8:
            # Parameters get new storage and buffers are replaced in their
            # modules' dicts behind the cached pairing.
            for ema in (reference, candidate):
                ema.double()
                ema.float()
                if device == "cuda":
                    ema.to(memory_format=torch.channels_last)
        if update == 12:
            for ema in (reference, candidate):
                state = deepcopy(ema.state_dict())
                ema.load_state_dict(state)
        if update == 15:
            # Resume replaces the step counter (BaseModel.resume_training).
            for ema in (reference, candidate):
                ema.register_buffer("step", ema.step.clone())
        perturb_online_model(reference, 100 + update)
        perturb_online_model(candidate, 100 + update)
        reference.update()
        model.update_ema(candidate)
        assert reference.step.item() == candidate.step.item()
        assert_same_state(reference.ema_model, candidate.ema_model)

    # The first update and every step <= update_after_step go to the library.
    assert library_update.call_count == update_after_step + 1


def test_ema_update_delegates_non_plain_cases() -> None:
    reference = make_ema(False, 0, "cpu")
    candidate = make_ema(False, 0, "cpu")
    for ema in (reference, candidate):
        ema.ignore_names = {"tail.bias"}
    library_update = Mock(wraps=candidate.update)
    candidate.update = library_update
    model = object.__new__(BaseModel)

    for update in range(5):
        perturb_online_model(reference, update)
        perturb_online_model(candidate, update)
        reference.update()
        model.update_ema(candidate)

    assert library_update.call_count == 5
    assert_same_state(reference.ema_model, candidate.ema_model)


def test_ema_update_calls_non_ema_objects() -> None:
    model = object.__new__(BaseModel)
    ema = Mock()

    model.update_ema(ema)

    ema.update.assert_called_once_with()


def gradient_layouts(device: str) -> list[list[nn.Parameter]]:
    contiguous = make_parameters(device)
    set_gradients(contiguous, 1)
    channels_last = make_parameters(device)
    set_gradients(channels_last, 1)
    for param in channels_last:
        assert param.grad is not None
        if param.grad.dim() == 4:
            param.grad = param.grad.contiguous(memory_format=torch.channels_last)
    return [contiguous, channels_last]


@pytest.mark.parametrize("device", DEVICES)
def test_total_gradient_norm_matches_get_total_norm(device: str) -> None:
    for params in gradient_layouts(device):
        gradients: list[Tensor] = [
            param.grad for param in params if param.grad is not None
        ]
        flattened = torch.linalg.vector_norm(
            torch.cat([gradient.reshape(-1) for gradient in gradients]), 2
        )

        actual = _get_total_gradient_norm(params)

        torch.testing.assert_close(
            actual, get_total_norm(gradients, foreach=device == "cuda")
        )
        torch.testing.assert_close(actual, flattened)


FILL_SETTING = cast(_UninitializedFillSetting, deterministic)


@pytest.fixture
def restore_deterministic_settings() -> Iterator[None]:
    enabled = torch.are_deterministic_algorithms_enabled()
    warn_only = torch.is_deterministic_algorithms_warn_only_enabled()
    fill = FILL_SETTING.fill_uninitialized_memory
    try:
        yield
    finally:
        torch.use_deterministic_algorithms(enabled, warn_only=warn_only)
        FILL_SETTING.fill_uninitialized_memory = fill


@pytest.mark.usefixtures("restore_deterministic_settings")
def test_total_gradient_norm_is_the_same_in_deterministic_mode() -> None:
    for params in gradient_layouts("cpu"):
        gradients: list[Tensor] = [
            param.grad for param in params if param.grad is not None
        ]
        flattened = torch.linalg.vector_norm(
            torch.cat([gradient.reshape(-1) for gradient in gradients]), 2
        )
        results = []
        for enabled in (False, True):
            torch.use_deterministic_algorithms(enabled)
            FILL_SETTING.fill_uninitialized_memory = True
            results.append(_get_total_gradient_norm(params))

        assert torch.equal(results[0], results[1])
        for result in results:
            assert result.isfinite()
            torch.testing.assert_close(result, flattened)


@pytest.mark.parametrize("device", DEVICES)
@pytest.mark.parametrize("keep_storage", [False, True])
def test_zeroing_keeps_gradient_storage(device: str, keep_storage: bool) -> None:
    model = object.__new__(SRModel)
    model.cudagraph_stable_gradients = keep_storage
    params = gradient_layouts(device)[1]
    optimizer = AdamW(params, lr=1e-3)
    storage = [param.grad.data_ptr() for param in params if param.grad is not None]
    strides = [param.grad.stride() for param in params if param.grad is not None]

    model._zero_generator_optimizer(optimizer)  # noqa: SLF001

    if not keep_storage:
        assert all(param.grad is None for param in params)
        return
    gradients = [param.grad for param in params if param.grad is not None]
    assert [gradient.data_ptr() for gradient in gradients] == storage
    assert [gradient.stride() for gradient in gradients] == strides
    assert all(not gradient.any() for gradient in gradients)


def test_build_optimizer_keeps_cpu_and_explicit_options() -> None:
    params = make_parameters("cpu")

    default = build_optimizer(params, {"type": "AdamW", "lr": 1e-3})
    explicit = build_optimizer(params, {"type": "AdamW", "lr": 1e-3, "foreach": False})

    assert default.defaults["fused"] is None
    assert explicit.defaults["fused"] is None
    assert explicit.defaults["foreach"] is False


@requires_cuda
def test_build_optimizer_fuses_cuda_adam() -> None:
    params = make_parameters("cuda")

    default = build_optimizer(params, {"type": "AdamW", "lr": 1e-3})
    explicit = build_optimizer(params, {"type": "Adam", "lr": 1e-3, "fused": False})
    foreach = build_optimizer(params, {"type": "Adam", "lr": 1e-3, "foreach": True})
    generated = build_optimizer(
        (param for param in params), {"type": "AdamW", "lr": 1e-3}
    )

    assert generated.defaults["fused"] is None
    assert len(generated.param_groups[0]["params"]) == len(params)
    assert default.defaults["fused"] is True
    assert explicit.defaults["fused"] is False
    assert foreach.defaults["fused"] is None
    assert foreach.defaults["foreach"] is True


def make_two_group_optimizer(params: list[nn.Parameter]) -> AdamW:
    return AdamW(
        [
            {"params": params[:3]},
            {"params": params[3:], "lr": 3e-3, "weight_decay": 0.0},
        ],
        lr=1e-3,
        betas=(0.9, 0.99),
        weight_decay=1e-2,
        fused=True,
    )


def assert_same_optimizer(reference: AdamW, candidate: AdamW) -> None:
    for reference_group, candidate_group in zip(
        reference.param_groups, candidate.param_groups, strict=True
    ):
        assert reference_group["lr"] == candidate_group["lr"]
        for reference_param, candidate_param in zip(
            reference_group["params"], candidate_group["params"], strict=True
        ):
            assert torch.equal(reference_param, candidate_param)
            reference_state = reference.state[reference_param]
            candidate_state = candidate.state[candidate_param]
            assert reference_state.keys() == candidate_state.keys()
            for key, value in reference_state.items():
                assert torch.equal(value, candidate_state[key]), key


@requires_cuda
def test_fused_adam_step_matches_library() -> None:
    reference_params = make_parameters("cuda")
    candidate_params = make_parameters("cuda")
    reference = make_two_group_optimizer(reference_params)
    candidate = make_two_group_optimizer(candidate_params)
    reference_scheduler = MultiStepLR(reference, milestones=[3, 9], gamma=0.5)
    candidate_scheduler = MultiStepLR(candidate, milestones=[3, 9], gamma=0.5)
    scaler = GradScaler("cuda", enabled=False)
    library_step = Mock(wraps=scaler.step)
    scaler.step = library_step
    model = object.__new__(BaseModel)
    library_steps = []

    for step in range(12):
        set_gradients(reference_params, 40 + step)
        set_gradients(candidate_params, 40 + step)
        if step == 5:
            # Resume replaces the state and the param_groups objects.
            candidate.load_state_dict(deepcopy(candidate.state_dict()))
        if step == 7:
            # The library skips a parameter without a gradient.
            reference_params[1].grad = None
            candidate_params[1].grad = None
        if step == 9:
            extra_reference = nn.Parameter(torch.ones(5, device="cuda"))
            extra_candidate = nn.Parameter(torch.ones(5, device="cuda"))
            reference.add_param_group({"params": [extra_reference]})
            candidate.add_param_group({"params": [extra_candidate]})
            reference_params.append(extra_reference)
            candidate_params.append(extra_candidate)
            set_gradients(reference_params, 40 + step)
            set_gradients(candidate_params, 40 + step)
        calls_before = library_step.call_count
        reference.step()
        model.step_optimizer(scaler, candidate)
        if library_step.call_count > calls_before:
            library_steps.append(step)
        reference_scheduler.step()
        candidate_scheduler.step()
        assert_same_optimizer(reference, candidate)

    assert library_steps == [0, 5, 7, 9]


def count_library_steps(
    model: BaseModel, optimizer: Optimizer, params: list[nn.Parameter], seeds: range
) -> int:
    scaler = GradScaler(params[0].device.type, enabled=False)
    library_step = Mock(wraps=scaler.step)
    scaler.step = library_step
    for seed in seeds:
        set_gradients(params, seed)
        model.step_optimizer(scaler, optimizer)
    return library_step.call_count


@pytest.mark.parametrize("device", DEVICES)
@pytest.mark.parametrize("saved_fused", [False, True])
def test_resume_keeps_the_saved_optimizer_path(device: str, saved_fused: bool) -> None:
    model = object.__new__(BaseModel)
    # build_optimizer chooses fused only for CUDA; on the CPU it is asked for.
    config = {"type": "AdamW", "lr": 1e-3, "betas": (0.9, 0.99)}
    if device == "cpu":
        config["fused"] = True
    saved_params = make_parameters(device)
    # The state as a run saved it: built before the fused default, or fused.
    saved = AdamW(saved_params, lr=1e-3, betas=(0.9, 0.99), fused=saved_fused or None)
    for seed in range(3):
        set_gradients(saved_params, seed)
        saved.step()
    state = deepcopy(saved.state_dict())

    resumed_params = [nn.Parameter(param.detach().clone()) for param in saved_params]
    resumed = build_optimizer(resumed_params, config)
    assert resumed.defaults["fused"] is True
    resumed.load_state_dict(state)
    library_steps = count_library_steps(model, resumed, resumed_params, range(3, 8))
    for seed in range(3, 8):
        set_gradients(saved_params, seed)
        saved.step()

    # load_state_dict restores the saved groups, so their path continues.
    assert resumed.param_groups[0]["fused"] is (True if saved_fused else None)
    assert library_steps == (1 if saved_fused else 5)
    for param, saved_param in zip(resumed_params, saved_params, strict=True):
        assert torch.equal(param, saved_param)
        for key, value in saved.state[saved_param].items():
            assert torch.equal(value, resumed.state[param][key]), key
            assert value.device == resumed.state[param][key].device, key


def test_step_optimizer_uses_library_for_other_optimizers() -> None:
    params = make_parameters("cpu")
    reference_params = make_parameters("cpu")
    for optimizer_class in (AdamW, NAdam):
        candidate = optimizer_class(params, lr=1e-3)
        reference = optimizer_class(reference_params, lr=1e-3)
        scaler = GradScaler("cpu", enabled=False)
        library_step = Mock(wraps=scaler.step)
        scaler.step = library_step
        model = object.__new__(BaseModel)

        for step in range(3):
            set_gradients(params, step)
            set_gradients(reference_params, step)
            model.step_optimizer(scaler, candidate)
            reference.step()

        assert library_step.call_count == 3
        for param, reference_param in zip(params, reference_params, strict=True):
            assert torch.equal(param, reference_param)
