"""Still sources sent as bytes: eligibility, draws, collation and the GPU canvas
against the dataset's CPU canvas."""

import itertools
import random
from pathlib import Path
from typing import Any

import numpy as np
import pytest
import pyvips
import torch
from torch.utils.data import default_collate
from traiNNer.data import build_dataloader, realesrgan_dataset, still_source
from traiNNer.data.dvd_response import collate_dvd
from traiNNer.data.realesrgan_dataset import RealESRGANDataset, _downsample_input_vips
from traiNNer.data.still_source import (
    collate_still_source,
    device_canvas,
    host_canvas,
    is_still_source,
    uses_still_sources,
)
from traiNNer.utils.redux_options import DatasetOptions
from traiNNer.utils.rng import RNG

GT_SIZE = 64
D4 = list(itertools.product([False, True], repeat=3))


@pytest.fixture(autouse=True)
def _project_rng(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(0))


def _write(folder: Path, name: str, pixels: np.ndarray) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    img = pyvips.Image.new_from_array(pixels)
    if pixels.dtype == np.uint16:
        img = img.copy(interpretation="rgb16")
    img.write_to_file(str(folder / name))


def _pixels(size: int, channels: int, seed: int, dtype: type = np.uint8) -> np.ndarray:
    # Noise over a ramp: every tap weight and the clip at both ends matter.
    rng = np.random.default_rng(seed)
    ramp = (
        np.linspace(0, 1, size)[None, :, None] * np.linspace(0, 1, size)[:, None, None]
    )
    top = np.iinfo(dtype).max
    noise = rng.integers(0, top, (size, size, channels), endpoint=True)
    values = np.where(rng.random((size, size, channels)) < 0.5, noise, ramp * top)
    return values.astype(dtype)


def _dataset(root: Path, still: bool, **changes: Any) -> RealESRGANDataset:
    options: dict[str, Any] = {
        "name": "still_source",
        "type": "realesrgandataset",
        "phase": "train",
        "dataroot_gt": [str(root)],
        "gt_size": GT_SIZE,
        "downsample_input": True,
        "downscale_algorithm": "hermite",
        "use_hflip": True,
        "use_rot": True,
    }
    opt = DatasetOptions(**{**options, **changes})
    dataset = RealESRGANDataset(opt)
    dataset.still_sources = still
    return dataset


def _sample(dataset: RealESRGANDataset, index: int, seed: int) -> dict[str, Any]:
    random.seed(seed)
    RNG.get_rng().bit_generator.state = np.random.default_rng(seed).bit_generator.state
    return dict(dataset[index])


def _forced(monkeypatch: pytest.MonkeyPatch, d4: tuple[bool, bool, bool]) -> None:
    monkeypatch.setattr(realesrgan_dataset, "draw_augment_vips", lambda *_: d4)


def test_eligibility_reads_the_decoded_image() -> None:
    opt = DatasetOptions(
        name="still_source",
        type="realesrgandataset",
        gt_size=GT_SIZE,
        downsample_input=True,
        downscale_algorithm="hermite",
    )

    def image(size: int, channels: int, dtype: type = np.uint8) -> pyvips.Image:
        return pyvips.Image.new_from_array(np.zeros((size, size, channels), dtype))

    assert is_still_source(image(2 * GT_SIZE, 3), opt)
    assert not is_still_source(image(2 * GT_SIZE + 2, 3), opt)
    assert not is_still_source(image(2 * GT_SIZE, 1), opt)
    assert not is_still_source(image(2 * GT_SIZE, 4), opt)
    assert not is_still_source(image(2 * GT_SIZE, 3, np.uint16), opt)
    for changes in (
        {"downscale_algorithm": "catrom"},
        {"downsample_input": False},
        {"target_dataroot_gt": ["target"]},
        {"gt_size": 8},
    ):
        changed = DatasetOptions(
            **{
                "name": "still_source",
                "type": "realesrgandataset",
                "gt_size": GT_SIZE,
                "downsample_input": True,
                "downscale_algorithm": "hermite",
                **changes,
            }
        )
        size = changed.gt_size or GT_SIZE
        assert not is_still_source(image(2 * size, 3), changed)


@pytest.mark.parametrize(
    ("name", "pixels", "changes"),
    [
        ("size", _pixels(2 * GT_SIZE + 6, 3, 1), {}),
        ("deep", _pixels(2 * GT_SIZE, 3, 2, np.uint16), {}),
        ("alpha", _pixels(2 * GT_SIZE, 4, 3), {}),
        ("catrom", _pixels(2 * GT_SIZE, 3, 4), {"downscale_algorithm": "catrom"}),
        ("full", _pixels(2 * GT_SIZE, 3, 5), {"downsample_input": False}),
    ],
)
def test_other_sources_keep_the_cpu_path(
    tmp_path: Path, name: str, pixels: np.ndarray, changes: dict[str, Any]
) -> None:
    _write(tmp_path, f"{name}.png", pixels)
    still = _sample(_dataset(tmp_path, True, **changes), 0, 11)
    plain = _sample(_dataset(tmp_path, False, **changes), 0, 11)
    assert "gt_orientation" not in still
    assert still.keys() == plain.keys()
    assert torch.equal(still["gt"], plain["gt"])


@pytest.mark.parametrize("channels", [3, 1])
def test_draws_dvd_entry_and_host_canvas_match_the_cpu_path(
    tmp_path: Path, channels: int
) -> None:
    # A grey PNG decodes to RGB, so it is a still source as well.
    for i in range(4):
        _write(tmp_path, f"{i}.png", _pixels(2 * GT_SIZE, channels, 10 + i).squeeze())
    still_set = _dataset(tmp_path, True, dvd_prob=1.0)
    plain_set = _dataset(tmp_path, False, dvd_prob=1.0)
    for i in range(4):
        still = _sample(still_set, i, 100 + i)
        still_state = (random.getstate(), RNG.get_rng().bit_generator.state)
        plain = _sample(plain_set, i, 100 + i)
        assert still_state == (random.getstate(), RNG.get_rng().bit_generator.state)
        assert still["gt"].dtype == torch.uint8
        assert still["gt"].shape == (3, 2 * GT_SIZE, 2 * GT_SIZE)
        assert still.keys() - plain.keys() == {"gt_orientation"}
        for key in ("kernel1", "kernel2", "sinc_kernel"):
            assert torch.equal(still[key], plain[key])
        assert still["otf_padded_height"] is plain["otf_padded_height"] is True
        assert still["otf_padded_width"] is plain["otf_padded_width"] is True
        assert still["dvd"] == plain["dvd"]
        assert still["dvd"].source is None
        canvas = host_canvas(still["gt"], still["gt_orientation"])
        assert canvas.dtype == plain["gt"].dtype
        assert torch.equal(canvas, plain["gt"])


def test_collation(tmp_path: Path) -> None:
    for i in range(3):
        _write(tmp_path, f"{i}.png", _pixels(2 * GT_SIZE, 3, 20 + i))
    _write(tmp_path, "3.png", _pixels(2 * GT_SIZE, 4, 23))
    still_set = _dataset(tmp_path, True, dvd_prob=1.0)
    plain_set = _dataset(tmp_path, False, dvd_prob=1.0)
    still = [_sample(still_set, i, 200 + i) for i in range(4)]
    plain = [_sample(plain_set, i, 200 + i) for i in range(4)]

    # A mixed batch is the CPU path's batch.
    mixed, expected = collate_still_source(still), collate_dvd(plain)
    assert mixed.keys() == expected.keys()
    assert mixed["gt"].dtype == torch.float32
    assert torch.equal(mixed["gt"], expected["gt"])
    for got, want in zip(mixed["dvd"], expected["dvd"], strict=True):
        assert got.geometry == want.geometry
        assert (got.source is None) == (want.source is None)
        assert got.source is None or torch.equal(got.source, want.source)
    for key in ("kernel1", "kernel2", "sinc_kernel", "otf_padded_height"):
        assert torch.equal(mixed[key], expected[key])

    # A batch of still sources only stays bytes, with its flags.
    raw = collate_still_source(still[:3])
    assert raw["gt"].dtype == torch.uint8
    assert raw["gt"].shape == (3, 3, 2 * GT_SIZE, 2 * GT_SIZE)
    assert raw["gt_orientation"].tolist() == [s["gt_orientation"] for s in still[:3]]
    assert len(raw["dvd"]) == 3


def test_build_dataloader_selects_the_collation(tmp_path: Path) -> None:
    _write(tmp_path, "0.png", _pixels(2 * GT_SIZE, 3, 30))
    loader_options = {
        "batch_size_per_gpu": 1,
        "num_worker_per_gpu": 0,
        "prefetch_factor": None,
        "persistent_workers": False,
    }
    dataset = _dataset(tmp_path, False, **loader_options)
    loader = build_dataloader(dataset, dataset.opt, num_gpu=0)
    assert loader.collate_fn is collate_still_source
    assert dataset.still_sources

    dataset = _dataset(tmp_path, False, downsample_input=False, **loader_options)
    loader = build_dataloader(dataset, dataset.opt, num_gpu=0)
    assert loader.collate_fn is default_collate
    assert not dataset.still_sources


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
@pytest.mark.parametrize("memory_format", [torch.channels_last, torch.preserve_format])
def test_device_canvas_matches_the_cpu_path(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, memory_format: torch.memory_format
) -> None:
    for i in range(2):
        _write(tmp_path, f"{i}.png", _pixels(2 * GT_SIZE, 3, 40 + i))
    still_set = _dataset(tmp_path, True)
    plain_set = _dataset(tmp_path, False)
    sources, flags, expected = [], [], []
    for d4 in D4:
        _forced(monkeypatch, d4)
        for i in range(2):
            still = _sample(still_set, i, 0)
            sources.append(still["gt"])
            flags.append(still["gt_orientation"])
            expected.append(_sample(plain_set, i, 0)["gt"])
    source = torch.stack(sources).cuda()
    if memory_format is torch.channels_last:
        source = source.contiguous(memory_format=torch.channels_last)
    canvas = device_canvas(source, torch.tensor(flags).cuda(), memory_format)
    assert canvas.is_contiguous(
        memory_format=torch.contiguous_format
        if memory_format is torch.preserve_format
        else memory_format
    )
    assert torch.equal(canvas.cpu(), torch.stack(expected))


@pytest.mark.parametrize("size", [(2 * GT_SIZE + 6, 2 * GT_SIZE + 6), (141, 119)])
def test_dvd_window_of_a_halved_source_keeps_its_pixels(
    tmp_path: Path, size: tuple[int, int]
) -> None:
    width, height = size
    pixels = _pixels(max(size), 3, 50)[:height, :width]
    _write(tmp_path, "0.png", np.ascontiguousarray(pixels))
    halved = (
        _downsample_input_vips(
            pyvips.Image.new_from_file(str(tmp_path / "0.png")), "hermite"
        )
        .numpy()
        .copy()
    )
    expected = _sample(_dataset(tmp_path, False), 0, 60)["gt"]
    armed = _dataset(tmp_path, False, dvd_prob=1.0)
    for _ in range(20):
        sample = _sample(armed, 0, 60)
        assert torch.equal(sample["gt"], expected)
        window = sample["dvd"].geometry.window()
        assert window.width > 0 and window.height > 0
        region = halved[
            window.top : window.top + window.height,
            window.left : window.left + window.width,
        ]
        assert torch.equal(
            sample["dvd"].source, torch.from_numpy(region).permute(2, 0, 1)
        )
        assert torch.isfinite(sample["gt"]).all()
        assert 0 <= float(sample["gt"].min()) and float(sample["gt"].max()) <= 1


def test_without_triton_no_source_takes_the_gpu_canvas(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    opt = DatasetOptions(
        name="still_source",
        type="realesrgandataset",
        dataroot_gt=["unused"],
        gt_size=GT_SIZE,
        downsample_input=True,
        downscale_algorithm="hermite",
    )
    assert uses_still_sources(opt)
    monkeypatch.setattr(still_source, "_triton_available", lambda: False)
    assert not uses_still_sources(opt)
