"""DAT's position-bias networks evaluated in one batched pass."""

import copy
from collections.abc import Callable

import pytest
import torch
from torch import nn
from traiNNer.archs import dat_arch
from traiNNer.archs.dat_arch import (
    DAT,
    DynamicPosBias,
    ResidualGroup,
    Spatial_Attention,
    batched_position_biases,
    dat_s,
)

CUDA = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA regression")


def _model(seed: int = 0) -> DAT:
    torch.manual_seed(seed)
    model = dat_s()
    assert isinstance(model, DAT)
    # The default initialisation leaves the bias networks nearly constant.
    with torch.no_grad():
        for name, parameter in model.named_parameters():
            if ".pos." in name:
                parameter.normal_(0.0, 0.5)
    return model


def _pos_parameters(model: nn.Module) -> dict[str, nn.Parameter]:
    return {n: p for n, p in model.named_parameters() if ".pos." in n}


def _net(attention: Spatial_Attention) -> DynamicPosBias:
    net = attention.pos
    assert isinstance(net, DynamicPosBias)
    return net


def _module_table(attention: Spatial_Attention) -> torch.Tensor:
    return _net(attention)(dict(attention.named_buffers())["rpe_biases"])


def _grad(parameter: torch.Tensor) -> torch.Tensor:
    assert parameter.grad is not None
    return parameter.grad


def _weighted_sum(
    tables: list[torch.Tensor], weights: list[torch.Tensor]
) -> torch.Tensor:
    return torch.stack(
        [(t * w).sum() for t, w in zip(tables, weights, strict=True)]
    ).sum()


# Batched products and the LayerNorm split into normalise-then-affine round
# differently from nn.Linear / nn.LayerNorm, so agreement is to fp32 rounding.
RTOL, ATOL = 1e-5, 1e-6
# Parameter gradients are sums over the 465 table rows in a different order.
GRAD_RTOL, GRAD_ATOL = 1e-4, 1e-5


def _close_msg(name: str) -> Callable[[str], str]:
    return lambda message: f"{name}: {message}"


@pytest.mark.parametrize("residual", [False, True])
def test_batched_tables_equal_module_tables(residual: bool) -> None:
    model = _model()
    attentions = model.spatial_attentions()
    assert len(attentions) == 36
    assert {a.idx for a in attentions} == {0, 1}  # both window orientations
    for attention in attentions:
        _net(attention).residual = residual
    tables = batched_position_biases(attentions)
    for attention, table in zip(attentions, tables, strict=True):
        expected = _module_table(attention)
        torch.testing.assert_close(table, expected, rtol=RTOL, atol=ATOL)


def test_batched_table_gradients_equal_module_gradients() -> None:
    model = _model()
    reference = copy.deepcopy(model)
    g = torch.Generator().manual_seed(4)
    attentions = model.spatial_attentions()
    weights = [torch.randn(465, _net(a).num_heads, generator=g) for a in attentions]
    _weighted_sum(batched_position_biases(attentions), weights).backward()
    ref_tables = [_module_table(a) for a in reference.spatial_attentions()]
    _weighted_sum(ref_tables, weights).backward()
    actual, expected = _pos_parameters(model), _pos_parameters(reference)
    assert actual.keys() == expected.keys()
    assert len(actual) == 36 * 14  # 4 Linear + 3 LayerNorm, weight and bias
    for name, parameter in actual.items():
        torch.testing.assert_close(
            _grad(parameter),
            _grad(expected[name]),
            rtol=GRAD_RTOL,
            atol=GRAD_ATOL,
            msg=_close_msg(name),
        )


def test_default_never_reaches_batched_pass(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def refuse(*args: object, **kwargs: object) -> None:
        raise AssertionError("batched position bias reached")

    monkeypatch.setattr(dat_arch, "batched_position_biases", refuse)
    model = _model().train()
    keys = set(model.state_dict())
    model.prepare_for_compile(input_shape=(2, 3, 32, 32), input_dtype=torch.bfloat16)
    assert not model.use_batched_position_bias
    assert not any(hasattr(a, "position_bias_slot") for a in model.spatial_attentions())
    assert set(model.state_dict()) == keys
    out = model(torch.rand(2, 3, 32, 32))
    assert out.shape == (2, 3, 128, 128)


@pytest.mark.parametrize("use_chk", [False, True])
def test_batched_forward_matches_module_forward(use_chk: bool) -> None:
    reference = _model().train()
    model = copy.deepcopy(reference)
    model.enable_batched_position_bias()  # what prepare_for_compile does on CUDA
    for net in (reference, model):
        for layer in net.modules():
            if isinstance(layer, ResidualGroup):
                layer.use_chk = use_chk
    image = torch.rand(2, 3, 32, 32, generator=torch.Generator().manual_seed(5))
    outputs = []
    for net in (reference, model):
        torch.manual_seed(6)  # same stochastic-depth draws
        out = net(image)
        out.square().mean().backward()
        outputs.append(out.detach())
    torch.testing.assert_close(outputs[1], outputs[0], rtol=1e-4, atol=1e-5)
    actual, expected = _pos_parameters(model), _pos_parameters(reference)
    for name, parameter in actual.items():
        torch.testing.assert_close(
            _grad(parameter),
            _grad(expected[name]),
            rtol=1e-3,
            atol=1e-6,
            msg=_close_msg(name),
        )


# ----------------------------------------------------------------------------- CUDA


def _cuda_step(
    model: nn.Module, image: torch.Tensor, target: torch.Tensor
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    torch.manual_seed(7)
    with torch.autocast("cuda", dtype=torch.bfloat16):
        loss = (model(image).float() - target).abs().mean()
    loss.backward()
    grads = {n: _grad(p).detach().clone() for n, p in model.named_parameters()}
    return loss.detach(), grads


@CUDA
def test_cuda_batched_training_step(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    base = _model().cuda().train()
    image = torch.rand(2, 3, 32, 32, device="cuda")
    target = torch.rand(2, 3, 128, 128, device="cuda")
    torch.use_deterministic_algorithms(True)
    try:
        hand_loss, hand_grads = _cuda_step(copy.deepcopy(base), image, target)
        runs = []
        for _ in range(2):
            model = copy.deepcopy(base)
            model.prepare_for_compile(input_shape=(2, 3, 32, 32))
            assert model.use_batched_position_bias
            runs.append(_cuda_step(model, image, target))
    finally:
        torch.use_deterministic_algorithms(False)
    (loss_a, grads_a), (loss_b, grads_b) = runs
    assert torch.equal(loss_a, loss_b)
    for name in grads_a:
        assert torch.equal(grads_a[name], grads_b[name]), name
    assert abs(float(loss_a - hand_loss)) <= 1e-2 * abs(float(hand_loss))
    for name in (
        "conv_first.weight",
        "layers.0.blocks.0.attn.attns.0.pos.pos_proj.weight",
        "layers.0.blocks.0.attn.attns.1.pos.pos3.2.weight",
        "layers.5.blocks.4.attn.qkv.weight",
    ):
        a, b = grads_a[name].norm(), hand_grads[name].norm()
        assert abs(float(a - b)) <= 5e-2 * float(b), name


@CUDA
def test_cuda_flag_stays_off_without_position_bias() -> None:
    # No constructor argument reaches Spatial_Attention.position_bias (the
    # spatial blocks hard-code it on), so it is switched off by hand here.
    model = _model().cuda().train()
    model.spatial_attentions()[3].position_bias = False
    model.prepare_for_compile(input_shape=(2, 3, 32, 32))
    assert not model.use_batched_position_bias
