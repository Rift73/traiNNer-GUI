"""GPU approximations of the video codec and WebP round trips."""

from __future__ import annotations

import numpy as np
import pytest
import torch
from torch import Tensor
from traiNNer.data import codec_approx
from traiNNer.data.codec_approx import (
    VIDEO_CODECS,
    approximate_video,
    approximate_webp,
    calibration,
    can_approximate,
)
from traiNNer.data.compress_video_batch import (
    _CODEC_SUPPORTED_SAMPLING,
    _filter_sampling,
)
from traiNNer.utils.rng import RNG

pytestmark = pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")


@pytest.fixture(autouse=True)
def _project_rng(monkeypatch: pytest.MonkeyPatch) -> None:
    # The chroma sampling is drawn from the project RNG.
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(0))


# A quality in the middle of a typical training range of every codec.
QUALITY = {"h264": 19, "hevc": 21, "mpeg2": 5, "mpeg4": 5, "vp9": 23}
ALL_SAMPLING = ["444", "422", "420"]
CASES = [
    (codec, sampling)
    for codec in VIDEO_CODECS
    for sampling in sorted(_CODEC_SUPPORTED_SAMPLING[codec])
]


def _image(batch: int, height: int, width: int, seed: int = 0) -> Tensor:
    """Smooth colour gradients with noise and a sharp edge, on CUDA."""
    generator = torch.Generator().manual_seed(seed)
    yy = torch.linspace(0, 1, height).view(1, 1, -1, 1)
    xx = torch.linspace(0, 1, width).view(1, 1, 1, -1)
    phase = torch.rand(batch, 3, 1, 1, generator=generator)
    base = 0.5 + 0.4 * torch.sin(6 * xx + 4 * yy + 6 * phase)
    noise = 0.05 * torch.randn(batch, 3, height, width, generator=generator)
    edge = (xx > 0.5).float() * 0.2
    return (base + noise + edge).clamp(0, 1).cuda()


def _marker_clip(frames: int, height: int = 48, width: int = 96) -> Tensor:
    """A bright 8x8 square on grey that moves 6 pixels right per frame."""
    clip = torch.full((frames, 3, height, width), 0.25)
    for t in range(frames):
        clip[t, :, 20:28, 8 + 6 * t : 16 + 6 * t] = 0.95
    return clip.cuda()


def _assert_contract(result: Tensor, source: Tensor) -> None:
    assert result.shape == source.shape
    assert result.device == source.device
    assert result.dtype == torch.float32
    assert result.is_contiguous()
    assert bool(torch.isfinite(result).all())
    assert float(result.min()) >= 0
    assert float(result.max()) <= 1
    divisor = torch.full((), 255.0, device=result.device)
    assert torch.equal((result * 255).round() / divisor, result)


@pytest.mark.parametrize("temporal", [False, True])
@pytest.mark.parametrize(("codec", "sampling"), CASES)
def test_video_contract(codec: str, sampling: str, temporal: bool) -> None:
    source = _image(5, 37, 50)
    lead_in = 2 if temporal else 0
    result = approximate_video(
        source, codec, QUALITY[codec], [sampling], temporal, lead_in
    )
    _assert_contract(result, source)
    error = (result - source).abs().mean()
    assert 0 < float(error) < 0.1


@pytest.mark.parametrize("temporal", [False, True])
@pytest.mark.parametrize("codec", VIDEO_CODECS)
def test_video_is_deterministic(codec: str, temporal: bool) -> None:
    source = _image(6, 64, 72, seed=1)
    lead_in = 3 if temporal else 0
    results = [
        approximate_video(source, codec, QUALITY[codec], ["420"], temporal, lead_in)
        for _ in range(2)
    ]
    assert torch.equal(results[0], results[1])


@pytest.mark.parametrize("codec", VIDEO_CODECS)
def test_sampling_draw_matches_genuine_path(
    codec: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    """One choice from the project RNG among the codec's options, like
    prepare_video_batch, and the drawn sampling is the one applied."""
    source = _image(4, 32, 48, seed=2)
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(11))
    result = approximate_video(source, codec, QUALITY[codec], ALL_SAMPLING)
    after = RNG.get_rng().uniform()
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(11))
    drawn = str(RNG.get_rng().choice(_filter_sampling(ALL_SAMPLING, codec)))
    expected_after = RNG.get_rng().uniform()
    assert after == expected_after
    assert torch.equal(
        result, approximate_video(source, codec, QUALITY[codec], [drawn])
    )


def test_no_sampling_list_takes_no_draw(monkeypatch: pytest.MonkeyPatch) -> None:
    source = _image(2, 32, 32, seed=3)
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(12))
    result = approximate_video(source, "vp9", 23, None)
    after = RNG.get_rng().uniform()
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(12))
    assert after == RNG.get_rng().uniform()
    assert torch.equal(result, approximate_video(source, "vp9", 23, ["420"]))


@pytest.mark.parametrize("temporal", [False, True])
@pytest.mark.parametrize("codec", ["h264", "hevc", "vp9"])
def test_chroma_sampling_is_honoured(codec: str, temporal: bool) -> None:
    """Colour detail along rows survives 4:4:4 better than 4:2:2, and detail
    along columns survives 4:2:2 better than 4:2:0."""
    source = torch.full((4, 3, 64, 64), 0.5)
    source[:, 0, :, 1::2] = 0.8
    source[:, 2, 1::2, :] = 0.2
    source = source.cuda()
    errors = {}
    for sampling in ALL_SAMPLING:
        result = approximate_video(source, codec, QUALITY[codec], [sampling], temporal)
        errors[sampling] = float((result[:, 0] - source[:, 0]).abs().mean())
        errors[sampling + "b"] = float((result[:, 2] - source[:, 2]).abs().mean())
    assert errors["444"] < errors["422"]
    assert errors["422b"] < errors["420b"]


@pytest.mark.parametrize("lead_in", [0, 4])
@pytest.mark.parametrize("codec", VIDEO_CODECS)
def test_clip_keeps_frame_order(codec: str, lead_in: int) -> None:
    clip = _marker_clip(10)
    result = approximate_video(clip, codec, QUALITY[codec], ["420"], True, lead_in)
    columns = torch.arange(clip.shape[-1], device=clip.device, dtype=torch.float32)
    for t in range(len(clip)):
        bright = (result[t, 1, 20:28] > 0.6).float().sum(0)
        centre = float((bright * columns).sum() / bright.sum())
        assert abs(centre - (11.5 + 6 * t)) < 1.5


@pytest.mark.parametrize("codec", VIDEO_CODECS)
def test_clip_uses_decoded_history(codec: str) -> None:
    """Later frames depend on earlier ones, earlier frames never on later ones,
    and independent frames on nothing but themselves."""
    clip = _image(1, 64, 64, seed=4).repeat(6, 1, 1, 1)
    quality = QUALITY[codec]
    base = approximate_video(clip, codec, quality, ["420"], True)
    first_changed = clip.clone()
    noise = torch.rand(clip.shape[1:], generator=torch.Generator().manual_seed(5))
    first_changed[0] = (clip[0] + 0.06 * (noise.cuda() - 0.5)).clamp(0, 1)
    changed = approximate_video(first_changed, codec, quality, ["420"], True)
    assert not torch.equal(changed[1], base[1])
    last_changed = clip.clone()
    last_changed[-1] = _image(1, 64, 64, seed=6)[0]
    changed = approximate_video(last_changed, codec, quality, ["420"], True)
    assert torch.equal(changed[:-1], base[:-1])
    still = approximate_video(clip, codec, quality, ["420"])
    changed = approximate_video(first_changed, codec, quality, ["420"])
    assert torch.equal(changed[1:], still[1:])


def test_lead_in_frames_are_dropped() -> None:
    clip = _marker_clip(6)
    result = approximate_video(clip, "h264", 19, ["444"], True, 5)
    assert result.shape == clip.shape


def test_strided_input_matches_contiguous() -> None:
    source = _image(4, 40, 56, seed=7)
    channels_last = source.contiguous(memory_format=torch.channels_last)
    assert torch.equal(
        approximate_video(channels_last, "hevc", 21, ["422"]),
        approximate_video(source, "hevc", 21, ["422"]),
    )
    assert torch.equal(
        approximate_webp(channels_last, 70), approximate_webp(source, 70)
    )


@pytest.mark.parametrize(("height", "width"), [(37, 50), (64, 64), (1, 1), (17, 3)])
def test_webp_contract(height: int, width: int) -> None:
    source = _image(3, height, width, seed=8)
    result = approximate_webp(source, 70)
    _assert_contract(result, source)
    assert torch.equal(result, approximate_webp(source, 70))


def test_webp_damage_grows_as_quality_falls() -> None:
    source = _image(4, 96, 96, seed=9)
    errors = [
        float((approximate_webp(source, quality) - source).abs().mean())
        for quality in (95, 70, 40)
    ]
    assert 0 < errors[0] < errors[1] < errors[2]


def test_eligibility() -> None:
    source = _image(4, 32, 32)
    assert can_approximate(source, "webp")
    for codec in VIDEO_CODECS:
        assert can_approximate(source, codec)
        assert can_approximate(source, codec, temporal=True, lead_in=3)
        assert not can_approximate(source, codec, temporal=True, lead_in=4)
        assert not can_approximate(source, codec, temporal=True, lead_in=-1)
        assert not can_approximate(source, codec, lead_in=1)
    assert not can_approximate(source, "jpeg")
    assert not can_approximate(source, "av1")
    assert not can_approximate(source.cpu(), "h264")
    assert not can_approximate(source.half(), "h264")
    assert not can_approximate(source.double(), "webp")
    assert not can_approximate(source[:, :1], "h264")
    assert not can_approximate(source[:, :1], "webp")
    assert not can_approximate(source[0], "h264")
    assert not can_approximate(source[:0], "h264")


def test_ineligible_calls_raise() -> None:
    source = _image(2, 16, 16)
    with pytest.raises(ValueError, match="does not cover"):
        approximate_video(source.cpu(), "h264", 19, ["420"])
    with pytest.raises(ValueError, match="does not cover"):
        approximate_video(source, "h264", 19, ["420"], False, 1)
    with pytest.raises(ValueError, match="does not cover"):
        approximate_webp(source[:, :1], 70)


def test_without_triton_nothing_is_eligible(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(codec_approx, "_triton_available", lambda: False)
    source = _image(2, 16, 16)
    assert not can_approximate(source, "h264")
    assert not can_approximate(source, "webp")


def test_constants_load() -> None:
    constants = calibration()
    assert set(constants.still_strength) == set(VIDEO_CODECS)
    assert set(constants.clip_strength) == set(VIDEO_CODECS)
    assert constants.still_strength["vp9"] == 0.42
    assert constants.clip_strength["hevc"] == 0.42
    assert constants.still_decoder_colors == {
        "420": True,
        "422": True,
        "444": False,
    }
    assert set(constants.clip_tuning) == {"h264", "hevc", "vp9"}
    assert constants.clip_tuning["h264"].chroma == 1.75
    assert constants.webp_scale == 1.8
