from datetime import datetime
from types import SimpleNamespace

from studio.lineage_history import training_history


def test_resumed_chart_uses_checkpoint_branch_and_preserves_raw_attempt(tmp_path):
    from studio.history import history

    def log(run, stamp, start, points):
        folder = tmp_path / run
        folder.mkdir(exist_ok=True)
        path = folder / f"train_shared_{stamp}.log"
        prefix = "2026-11-24 12:00:00,000 INFO: "
        lines = [f"{prefix}Start training from epoch: 0, iter: {start}."]
        lines += [f"{prefix}[epoch: 0, iter: {step}, lr:(1e-4)] l_g_total: {value}" for step, value in points]
        path.write_text("\n".join(lines) + "\n")
        return path

    original = log("parent", "20261124_120000", 0, [(1, 1), (2, 2), (3, 30), (4, 40)])
    log("parent", "20261124_170000", 1, [(2, 200)])  # A later branch from the same parent.
    log("child", "20261124_140000", 2, [(3, 3), (4, 400)])
    log("child", "20261124_180000", 3, [(4, 4), (5, 5)])
    receipt = tmp_path / "attempt"
    receipt.mkdir()
    (receipt / "result.json").write_text('{"updatedAt":"' + datetime(2026, 11, 24, 13).astimezone().isoformat() + '"}')
    runs = SimpleNamespace(experiment_dir=lambda run: tmp_path / run, attempt_dir=lambda run, attempt: receipt)
    queue = SimpleNamespace(history_parents=lambda: {"child": ("parent", "original", 2)})
    state = tmp_path / "index"
    full = training_history(runs, queue, state, "child", "l_g_total", 100, None, None)
    assert full["points"] == [(n, n) for n in range(1, 6)]
    assert full["resumeSteps"] == [2, 3]
    assert not full["partialHistory"]
    assert [item["source"] for item in full["attemptSources"] if item["runId"] == "parent"] == [original.name]
    raw = history(original.parent, state, original.name, "l_g_total")
    assert raw["points"][-1] == [4, 40]


def test_tensorboard_run_replays_writers_and_preserves_the_raw_attempt(tmp_path):
    from tensorboard.compat.proto.event_pb2 import Event, SessionLog
    from tensorboard.compat.proto.summary_pb2 import Summary
    from tensorboard.summary.writer.record_writer import RecordWriter

    from studio.tensorboard_history import combined_history, folder_writers

    folder = tmp_path / "older run"
    folder.mkdir()
    first, resumed = (folder / f"events.out.tfevents.{stamp}.host" for stamp in (100, 200))

    def scalar(step, value):
        return Event(step=step, summary=Summary(value=[Summary.Value(tag="val/psnr", simple_value=value)]))

    def append(path, *events):
        with path.open("ab") as stream:
            writer = RecordWriter(stream)
            for event in events:
                writer.write(event.SerializeToString())

    def points(source=None):
        return combined_history(folder_writers(folder), folder, tmp_path / "state", source,
                                "val/psnr", 100, None, None)["points"]

    append(first, scalar(1, 31), scalar(2, 32), scalar(3, 33))
    assert len(points()) == 3
    append(resumed, Event(step=2, session_log=SessionLog(status=SessionLog.START)), scalar(2, 34))
    assert points() == [[1, 31], [2, 34]]
    append(resumed, scalar(4, 35))
    assert points() == [[1, 31], [2, 34], [4, 35]]
    assert points(str(first)) == [[1, 31], [2, 32], [3, 33]]
