"""CPU checks for restoring a training loader after a batch-size change."""

import pytest
import torch
from torch.utils.data import DataLoader, TensorDataset
from traiNNer.data.data_sampler import (
    EnlargedSampler,
    auto_enlarge_ratio,
    make_sampler_cursor,
    restore_sampler_cursor,
    sampler_geometry,
)


def test_batch_size_change_keeps_rank_local_sample_across_resumes() -> None:
    dataset = TensorDataset(torch.arange(30))
    sampler = EnlargedSampler(dataset, num_replicas=2, rank=1)
    old = DataLoader(dataset, batch_size=2, sampler=sampler, drop_last=True)
    new = DataLoader(dataset, batch_size=3, sampler=sampler, drop_last=True)
    old_geometry = sampler_geometry(old, sampler, 1)
    new_geometry = sampler_geometry(new, sampler, 1)
    assert old_geometry is not None and new_geometry is not None

    sampler.set_epoch(7)
    expected = list(sampler)
    saved = make_sampler_cursor(old_geometry, 7, 4)
    assert saved == {
        "version": 1,
        "epoch": 7,
        "next_batch": 2,
        "geometry": old_geometry,
    }
    unchanged = restore_sampler_cursor(saved, old_geometry)
    assert (unchanged.epoch, unchanged.next_sample) == (7, 4)

    resumed = restore_sampler_cursor(saved, new_geometry)
    sampler.set_epoch(resumed.epoch, start_sample=resumed.next_sample)
    (first_batch,) = next(iter(new))
    assert first_batch.tolist() == expected[4:7]

    saved_again = make_sampler_cursor(
        new_geometry, resumed.epoch, resumed.next_sample + len(first_batch)
    )
    next_resume = restore_sampler_cursor(saved_again, new_geometry)
    sampler.set_epoch(next_resume.epoch, start_sample=next_resume.next_sample)
    (next_batch,) = next(iter(new))
    assert next_batch.tolist() == expected[7:10]


def test_larger_batch_moves_to_next_epoch_if_remaining_samples_do_not_fit() -> None:
    dataset = TensorDataset(torch.arange(15))
    sampler = EnlargedSampler(dataset, num_replicas=1, rank=0)
    old = DataLoader(dataset, batch_size=2, sampler=sampler, drop_last=True)
    new = DataLoader(dataset, batch_size=4, sampler=sampler, drop_last=True)
    old_geometry = sampler_geometry(old, sampler, 1)
    new_geometry = sampler_geometry(new, sampler, 1)

    saved = make_sampler_cursor(old_geometry, 7, 12)
    resumed = restore_sampler_cursor(saved, new_geometry)
    assert (resumed.epoch, resumed.next_sample) == (8, 0)


def test_batch_dependent_auto_enlargement_restarts_only_the_cursor_epoch() -> None:
    dataset = TensorDataset(torch.arange(13))
    old_sampler = EnlargedSampler(dataset, 1, 0, auto_enlarge_ratio(len(dataset), 2))
    new_sampler = EnlargedSampler(dataset, 1, 0, auto_enlarge_ratio(len(dataset), 3))
    old = DataLoader(dataset, batch_size=2, sampler=old_sampler, drop_last=True)
    new = DataLoader(dataset, batch_size=3, sampler=new_sampler, drop_last=True)
    old_geometry = sampler_geometry(old, old_sampler, 1)
    new_geometry = sampler_geometry(new, new_sampler, 1)
    assert new_geometry is not None

    saved = make_sampler_cursor(old_geometry, 7, 12)
    resumed = restore_sampler_cursor(saved, new_geometry, auto_batch_size_per_gpu=3)
    assert resumed.restarted_epoch
    assert (resumed.epoch, resumed.next_sample) == (7, 0)
    with pytest.raises(ValueError, match="enlarge_ratio"):
        restore_sampler_cursor(saved, new_geometry)
    with pytest.raises(ValueError, match="accum_iters"):
        restore_sampler_cursor(
            saved, {**new_geometry, "accum_iters": 2}, auto_batch_size_per_gpu=3
        )
