import os
import time
from collections.abc import Callable
from functools import partial
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import pytest
import torch
from torch.utils.data import DataLoader, Dataset, default_collate
from torch.utils.data._utils.pin_memory import pin_memory
from traiNNer.data import build_dataloader, shared_release
from traiNNer.data.dvd_response import collate_dvd
from traiNNer.data.realesrgan_dataset import RealESRGANDataset
from traiNNer.data.shared_release import (
    RELEASE_MIN_BYTES,
    RELEASE_QUEUE_SIZE,
    SharedBatch,
    collate_shared,
    releases_shared_memory,
    shared_fd,
)
from traiNNer.data.still_source import collate_still_source
from traiNNer.utils.redux_options import DatasetOptions

needs_pinned = pytest.mark.skipif(
    not torch.accelerator.is_available(), reason="pinned memory needs an accelerator"
)
LARGE = RELEASE_MIN_BYTES // 4  # float32 elements of a storage at the size line


def _samples(count: int) -> list[dict[str, Any]]:
    return [
        {
            "gt": torch.full((3, 16, 16), float(i)),
            "kernel1": torch.ones(21, 21),
            "gt_path": f"image_{i}.png",
            "otf_padded_height": i % 2 == 0,
        }
        for i in range(count)
    ]


def _assert_same(left: object, right: object) -> None:
    assert type(left) is type(right)
    if isinstance(left, torch.Tensor):
        assert isinstance(right, torch.Tensor)
        assert left.dtype == right.dtype
        assert left.shape == right.shape
        assert left.is_pinned() == right.is_pinned()
        assert torch.equal(left, right)
    elif isinstance(left, dict):
        assert isinstance(right, dict)
        assert left.keys() == right.keys()
        for key in left:
            _assert_same(left[key], right[key])
    elif isinstance(left, list | tuple):
        assert isinstance(right, list | tuple)
        assert len(left) == len(right)
        for a, b in zip(left, right, strict=True):
            _assert_same(a, b)
    else:
        assert left == right


def _wait(done: Callable[[], bool]) -> None:
    deadline = time.monotonic() + 5.0
    while not done():
        assert time.monotonic() < deadline, "the release thread did not finish"
        time.sleep(0.01)


def _queue_drained() -> bool:
    return shared_release.RELEASER.storages.qsize() == 0


def _collate_to_shared(samples: list[dict[str, Any]]) -> dict[str, Any]:
    # what default_collate does in a loader worker: the stacked batch in new shared memory
    return {
        key: value.share_memory_() for key, value in default_collate(samples).items()
    }


def _pass_through(samples: list[dict[str, Any]]) -> dict[str, Any]:
    return {"gt": samples[0]["gt"]}


@needs_pinned
@pytest.mark.parametrize(
    "batch",
    [
        default_collate(_samples(4)),
        collate_dvd([{**s, "dvd": (i, i + 1)} for i, s in enumerate(_samples(4))]),
        collate_still_source(
            [
                {"gt": torch.full((3, 8, 8), i, dtype=torch.uint8), "gt_orientation": i}
                for i in range(4)
            ]
        ),
    ],
    ids=["default_collate", "collate_dvd", "collate_still_source"],
)
def test_carrier_pins_as_torch_does(batch: dict[str, Any]) -> None:
    _assert_same(SharedBatch(batch, []).pin_memory(), pin_memory(batch))


@needs_pinned
def test_release_empties_the_batch_storage_and_keeps_the_pinned_copy() -> None:
    samples = [{"gt": torch.full((LARGE,), 3.0)}, {"gt": torch.full((LARGE,), 4.0)}]
    carried = collate_shared(samples, _collate_to_shared)
    fd = shared_fd(carried.batch["gt"].untyped_storage())
    pinned = carried.pin_memory()
    _wait(lambda: os.fstat(fd).st_size == 0)
    assert torch.equal(pinned["gt"], torch.stack([s["gt"] for s in samples]))


@needs_pinned
def test_passed_through_tensor_is_left_alone() -> None:
    kept = torch.full((LARGE,), 5.0).share_memory_()
    fd = shared_fd(kept.untyped_storage())
    size = os.fstat(fd).st_size
    carried = collate_shared([{"gt": kept}], _pass_through)
    assert carried.owned == []
    carried.pin_memory()
    _wait(_queue_drained)
    assert os.fstat(fd).st_size == size
    assert torch.equal(kept, torch.full((LARGE,), 5.0))


def test_small_tensors_and_views_are_carried_once() -> None:
    def collate(samples: list[dict[str, Any]]) -> dict[str, Any]:
        large = torch.zeros(LARGE)
        return {"gt": large, "view": large[:10], "kernel": torch.ones(21, 21)}

    carried = collate_shared([{"gt": torch.zeros(1)}], collate)
    assert len(carried.owned) == 1
    assert carried.owned[0].untyped_storage().data_ptr() == (
        carried.batch["gt"].untyped_storage().data_ptr()
    )


class _Images(Dataset):
    def __len__(self) -> int:
        return 24

    def __getitem__(self, index: int) -> dict[str, Any]:
        generator = torch.Generator().manual_seed(index)
        return {
            "gt": torch.rand(3, 256, 256, generator=generator),
            "gt_path": f"image_{index}.png",
        }


def _batches(collate: Any, pin: bool) -> list[Any]:
    loader = DataLoader(
        _Images(),
        batch_size=4,
        shuffle=True,
        num_workers=2,
        pin_memory=pin,
        collate_fn=collate,
        generator=torch.Generator().manual_seed(7),
    )
    return list(loader)


def test_owned_tensors_arrive_with_the_batch_storages() -> None:
    carried = _batches(partial(collate_shared, collate=default_collate), False)
    for item in carried:
        assert isinstance(item, SharedBatch)
        assert len(item.owned) == 1
        assert item.owned[0].untyped_storage().data_ptr() == (
            item.batch["gt"].untyped_storage().data_ptr()
        )


@needs_pinned
def test_loader_with_release_yields_the_same_batches() -> None:
    plain = _batches(default_collate, True)
    released = _batches(partial(collate_shared, collate=default_collate), True)
    assert len(plain) == len(released) == 6
    for a, b in zip(plain, released, strict=True):
        assert isinstance(b, dict)
        _assert_same(a, b)


def test_more_storages_than_the_queue_holds_are_all_released() -> None:
    releaser = shared_release.Releaser()
    count = 3 * RELEASE_QUEUE_SIZE
    tensors = [torch.zeros(1024).share_memory_() for _ in range(count)]
    fds = [shared_fd(t.untyped_storage()) for t in tensors]
    releaser.submit([t.untyped_storage() for t in tensors])
    _wait(lambda: releaser.released == count)
    assert all(os.fstat(fd).st_size == 0 for fd in fds)
    assert releaser.enabled


class _Logger:
    def __init__(self) -> None:
        self.messages: list[str] = []

    def warning(self, message: str, *args: object) -> None:
        self.messages.append(message % args)


def test_failing_truncate_logs_once_and_switches_off(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def failing_ftruncate(fd: int, length: int) -> None:
        raise OSError(9, "Bad file descriptor")

    logger = _Logger()
    monkeypatch.setattr(shared_release, "get_root_logger", lambda: logger)
    monkeypatch.setattr(shared_release.os, "ftruncate", failing_ftruncate)
    releaser = shared_release.Releaser()
    tensors = [torch.zeros(1024).share_memory_() for _ in range(2)]
    releaser.submit([t.untyped_storage() for t in tensors])
    _wait(lambda: releaser.storages.qsize() == 0 and bool(logger.messages))
    time.sleep(0.05)
    assert not releaser.enabled
    assert len(logger.messages) == 1
    assert "Bad file descriptor" in logger.messages[0]


def test_storage_without_descriptor_logs_once_and_switches_off(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    logger = _Logger()
    monkeypatch.setattr(shared_release, "get_root_logger", lambda: logger)
    releaser = shared_release.Releaser()
    releaser.submit([torch.zeros(1024).untyped_storage() for _ in range(2)])
    _wait(lambda: releaser.storages.qsize() == 0 and bool(logger.messages))
    time.sleep(0.05)
    assert not releaser.enabled
    assert len(logger.messages) == 1
    assert releaser.released == 0


def test_conditions_not_met(monkeypatch: pytest.MonkeyPatch) -> None:
    assert not releases_shared_memory(0, True)
    assert not releases_shared_memory(4, False)
    monkeypatch.setattr(
        torch.multiprocessing, "get_sharing_strategy", lambda: "file_system"
    )
    assert not releases_shared_memory(4, True)


def _dataset(root: Path, **changes: Any) -> RealESRGANDataset:
    options: dict[str, Any] = {
        "name": "release",
        "type": "realesrgandataset",
        "phase": "train",
        "dataroot_gt": [str(root)],
        "gt_size": 64,
        "use_hflip": True,
        "use_rot": True,
        "batch_size_per_gpu": 2,
        "num_worker_per_gpu": 2,
        "prefetch_factor": 2,
        "persistent_workers": False,
    }
    cv2.imwrite(str(root / "0.png"), np.zeros((128, 128, 3), dtype=np.uint8))
    return RealESRGANDataset(DatasetOptions(**{**options, **changes}))


@needs_pinned
@pytest.mark.parametrize(
    ("changes", "collate"),
    [
        ({}, default_collate),
        ({"dvd_prob": 0.5}, collate_dvd),
        (
            {"downsample_input": True, "downscale_algorithm": "hermite"},
            collate_still_source,
        ),
    ],
    ids=["default_collate", "collate_dvd", "collate_still_source"],
)
def test_build_dataloader_wraps_the_collation(
    tmp_path: Path, changes: dict[str, Any], collate: Callable[..., Any]
) -> None:
    dataset = _dataset(tmp_path, **changes)
    wrapped = build_dataloader(dataset, dataset.opt, num_gpu=0).collate_fn
    assert isinstance(wrapped, partial)
    assert wrapped.func is collate_shared
    assert wrapped.keywords == {"collate": collate}

    dataset = _dataset(tmp_path, pin_memory=False, **changes)
    assert build_dataloader(dataset, dataset.opt, num_gpu=0).collate_fn is collate
