"""Networks that keep their colour mean as a non-persistent buffer.

The buffer replaced a plain tensor attribute.  "Attribute style" below rebuilds
that former layout on a copy of the network, so checkpoints and outputs can be
compared against it.
"""

import copy
from collections.abc import Callable

import pytest
import torch
from torch import nn
from traiNNer.archs.dat_arch import dat_s
from traiNNer.archs.drct_arch import drct
from traiNNer.archs.dwt_arch import dwt_s
from traiNNer.archs.hat_arch import hat_s
from traiNNer.archs.hit_sir_arch import hit_sir
from traiNNer.archs.hit_sng_arch import hit_sng
from traiNNer.archs.hit_srf_arch import hit_srf
from traiNNer.archs.span_arch import span_f32
from traiNNer.archs.srformerv2_arch import srformerv2
from traiNNer.archs.temporal_span_v2_arch import temporalspanv2

# (factory, training batch, input shape, output shape), shapes without the batch:
# DAT's batch-norms need batch 2 in training mode; TSPANv2 takes a five-frame clip.
NETWORKS = [
    pytest.param(hat_s, 1, (3, 32, 32), (3, 128, 128), id="hat_s"),
    pytest.param(dat_s, 2, (3, 32, 32), (3, 128, 128), id="dat_s"),
    pytest.param(drct, 1, (3, 32, 32), (3, 128, 128), id="drct"),
    pytest.param(srformerv2, 1, (3, 32, 32), (3, 128, 128), id="srformerv2"),
    pytest.param(dwt_s, 1, (3, 32, 32), (3, 128, 128), id="dwt_s"),
    pytest.param(hit_sir, 1, (3, 64, 64), (3, 256, 256), id="hit_sir"),
    pytest.param(hit_sng, 1, (3, 64, 64), (3, 256, 256), id="hit_sng"),
    pytest.param(hit_srf, 1, (3, 32, 32), (3, 128, 128), id="hit_srf"),
    pytest.param(span_f32, 1, (3, 16, 16), (3, 64, 64), id="span_f32"),
    pytest.param(temporalspanv2, 1, (5, 3, 32, 32), (3, 128, 128), id="temporalspanv2"),
]


def _attribute_style(net: nn.Module) -> nn.Module:
    former = copy.deepcopy(net)
    mean = dict(former.named_buffers())["mean"].detach().clone()
    delattr(former, "mean")  # unregisters the buffer
    former.mean = mean  # no longer a buffer name: a plain attribute
    assert "mean" not in dict(former.named_buffers())
    return former


def _pair(factory: Callable[[], nn.Module]) -> tuple[nn.Module, nn.Module]:
    torch.manual_seed(0)
    net = factory()
    return net, _attribute_style(net)


@pytest.mark.parametrize("factory,batch,in_shape,out_shape", NETWORKS)
def test_mean_is_a_buffer_outside_the_state_dict(
    factory: Callable[[], nn.Module],
    batch: int,
    in_shape: tuple[int, ...],
    out_shape: tuple[int, ...],
) -> None:
    net, former = _pair(factory)
    assert "mean" in dict(net.named_buffers())
    assert "mean" not in net.state_dict()
    assert set(net.state_dict()) == set(former.state_dict())


@pytest.mark.parametrize("factory,batch,in_shape,out_shape", NETWORKS)
def test_attribute_style_checkpoint_loads_strictly(
    factory: Callable[[], nn.Module],
    batch: int,
    in_shape: tuple[int, ...],
    out_shape: tuple[int, ...],
) -> None:
    _, former = _pair(factory)
    torch.manual_seed(1)
    net = factory()
    result = net.load_state_dict(former.state_dict(), strict=True)
    assert not result.missing_keys
    assert not result.unexpected_keys
    for key, value in former.state_dict().items():
        assert torch.equal(net.state_dict()[key], value), key


@pytest.mark.parametrize("factory,batch,in_shape,out_shape", NETWORKS)
def test_mean_follows_module_dtype_and_device(
    factory: Callable[[], nn.Module],
    batch: int,
    in_shape: tuple[int, ...],
    out_shape: tuple[int, ...],
) -> None:
    net = factory().to(torch.float64)
    mean = dict(net.named_buffers())["mean"]
    assert mean.dtype == torch.float64
    assert mean.device == next(net.parameters()).device


@pytest.mark.parametrize("factory,batch,in_shape,out_shape", NETWORKS)
def test_forward_matches_attribute_style_bit_for_bit(
    factory: Callable[[], nn.Module],
    batch: int,
    in_shape: tuple[int, ...],
    out_shape: tuple[int, ...],
) -> None:
    net, former = _pair(factory)
    image = torch.rand(batch, *in_shape, generator=torch.Generator().manual_seed(2))
    for training in (True, False):
        outputs = []
        for model in (net, former):
            model.train(training)
            torch.manual_seed(3)  # same stochastic-depth draws
            with torch.no_grad():
                outputs.append(model(image))
        assert outputs[0].shape == (batch, *out_shape)
        assert torch.equal(outputs[0], outputs[1])
