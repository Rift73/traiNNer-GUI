"""sample_degradation_kernels builds only the kernels a stage can apply, and
takes exactly the draws of the sampler that builds all three: Python's random
and the project RNG end in the same state, and every kernel it builds is the
same bit for bit. The reference below is that full sampler."""

from __future__ import annotations

import math
import random
import sys
from pathlib import Path

import msgspec
import numpy as np
import pytest
import torch
import yaml
from torch import Tensor
from traiNNer.data import realesrgan_dataset
from traiNNer.data.degradations import circular_lowpass_kernel, random_mixed_kernels
from traiNNer.data.realesrgan_dataset import (
    RealESRGANDataset,
    sample_degradation_kernels,
)
from traiNNer.utils.options import parse_options
from traiNNer.utils.redux_options import DatasetOptions
from traiNNer.utils.rng import RNG

ROOT = Path(__file__).resolve().parents[2]
HR = ROOT / "datasets" / "train" / "dataset1" / "hr"
KERNEL_TYPES = (
    "iso",
    "aniso",
    "generalized_iso",
    "generalized_aniso",
    "plateau_iso",
    "plateau_aniso",
)
SEEDS = range(5)
CALLS = 8


def _full_sampler(opt: DatasetOptions) -> tuple[Tensor, Tensor, Tensor]:
    """The sampler that builds all three kernels on every call."""
    kernel_size = random.choice(range(opt.kernel_range[0], opt.kernel_range[1] + 1, 2))
    if RNG.get_rng().uniform() < opt.sinc_prob:
        if kernel_size < 13:
            omega_c = RNG.get_rng().uniform(np.pi / 3, np.pi)
        else:
            omega_c = RNG.get_rng().uniform(np.pi / 5, np.pi)
        kernel = circular_lowpass_kernel(omega_c, kernel_size, pad_to=False)
    else:
        kernel = random_mixed_kernels(
            opt.kernel_list,
            opt.kernel_prob,
            kernel_size,
            opt.blur_sigma,
            opt.blur_sigma,
            (-math.pi, math.pi),
            opt.betag_range,
            opt.betap_range,
            noise_range=None,
        )
    pad_size = (21 - kernel_size) // 2
    kernel = np.pad(kernel, ((pad_size, pad_size), (pad_size, pad_size)))

    kernel_size = random.choice(
        range(opt.kernel_range2[0], opt.kernel_range2[1] + 1, 2)
    )
    if RNG.get_rng().uniform() < opt.sinc_prob2:
        if kernel_size < 13:
            omega_c = RNG.get_rng().uniform(np.pi / 3, np.pi)
        else:
            omega_c = RNG.get_rng().uniform(np.pi / 5, np.pi)
        kernel2 = circular_lowpass_kernel(omega_c, kernel_size, pad_to=False)
    else:
        kernel2 = random_mixed_kernels(
            opt.kernel_list2,
            opt.kernel_prob2,
            kernel_size,
            opt.blur_sigma2,
            opt.blur_sigma2,
            (-math.pi, math.pi),
            opt.betag_range2,
            opt.betap_range2,
            noise_range=None,
        )
    pad_size = (21 - kernel_size) // 2
    kernel2 = np.pad(kernel2, ((pad_size, pad_size), (pad_size, pad_size)))

    if RNG.get_rng().uniform() < opt.final_sinc_prob:
        kernel_size = random.choice(
            range(opt.final_kernel_range[0], opt.final_kernel_range[1] + 1, 2)
        )
        omega_c = RNG.get_rng().uniform(np.pi / 3, np.pi)
        sinc_kernel = torch.FloatTensor(
            circular_lowpass_kernel(omega_c, kernel_size, pad_to=21)
        )
    else:
        sinc_kernel = torch.zeros(21, 21)
        sinc_kernel[10, 10] = 1

    return torch.FloatTensor(kernel), torch.FloatTensor(kernel2), sinc_kernel


def _pulse() -> Tensor:
    pulse = torch.zeros(21, 21)
    pulse[10, 10] = 1
    return pulse


def _seed(monkeypatch: pytest.MonkeyPatch, seed: int) -> None:
    random.seed(seed)
    monkeypatch.setattr(RNG, "_rng", np.random.default_rng(seed))


def _states() -> tuple[object, object]:
    return random.getstate(), RNG.get_rng().bit_generator.state


# Every kernel type in each list, alone and in the default mix; the second
# stage takes the next type, so the two stages differ.
KERNEL_CASES = [
    ([kind], [1.0], [KERNEL_TYPES[(i + 1) % len(KERNEL_TYPES)]], [1.0])
    for i, kind in enumerate(KERNEL_TYPES)
] + [(list(KERNEL_TYPES), [1 / 6] * 6, list(KERNEL_TYPES), [1 / 6] * 6)]


@pytest.mark.parametrize("final_sinc_prob", [0.0, 0.6])
@pytest.mark.parametrize("blur_prob2", [0.0, 0.5])
@pytest.mark.parametrize("blur_prob", [0.0, 0.5])
@pytest.mark.parametrize("sinc_prob", [0.0, 0.4])
@pytest.mark.parametrize("kernels", KERNEL_CASES)
def test_sampler_takes_the_full_samplers_draws(
    monkeypatch: pytest.MonkeyPatch,
    kernels: tuple[list[str], list[float], list[str], list[float]],
    sinc_prob: float,
    blur_prob: float,
    blur_prob2: float,
    final_sinc_prob: float,
) -> None:
    kernel_list, kernel_prob, kernel_list2, kernel_prob2 = kernels
    opt = DatasetOptions(
        name="kernels",
        type="realesrgandataset",
        kernel_list=kernel_list,
        kernel_prob=kernel_prob,
        kernel_list2=kernel_list2,
        kernel_prob2=kernel_prob2,
        sinc_prob=sinc_prob,
        sinc_prob2=sinc_prob,
        final_sinc_prob=final_sinc_prob,
        blur_prob=blur_prob,
        blur_prob2=blur_prob2,
    )
    for seed in SEEDS:
        _seed(monkeypatch, seed)
        expected = [_full_sampler(opt) for _ in range(CALLS)]
        expected_states = _states()
        _seed(monkeypatch, seed)
        sampled = [sample_degradation_kernels(opt) for _ in range(CALLS)]
        assert _states() == expected_states
        for (kernel, kernel2, sinc), (want, want2, want_sinc) in zip(
            sampled, expected, strict=True
        ):
            assert torch.equal(kernel, want if blur_prob > 0 else _pulse())
            assert torch.equal(kernel2, want2 if blur_prob2 > 0 else _pulse())
            assert torch.equal(sinc, want_sinc)
            for built in (kernel, kernel2, sinc):
                assert built.dtype == torch.float32
                assert built.shape == (21, 21)


def _samples(
    monkeypatch: pytest.MonkeyPatch, dataset: RealESRGANDataset, seed: int
) -> tuple[list[dict[str, object]], tuple[object, object]]:
    _seed(monkeypatch, seed)
    torch.manual_seed(seed)
    samples = [dict(dataset[index]) for index in range(3)]
    return samples, _states()


def _compare_with_full_sampler(
    monkeypatch: pytest.MonkeyPatch,
    dataset: RealESRGANDataset,
    blur_prob: float,
    blur_prob2: float,
) -> None:
    for seed in range(3):
        samples, states = _samples(monkeypatch, dataset, seed)
        with monkeypatch.context() as full:
            full.setattr(
                realesrgan_dataset, "sample_degradation_kernels", _full_sampler
            )
            expected, expected_states = _samples(monkeypatch, dataset, seed)
        assert states == expected_states
        for sample, want in zip(samples, expected, strict=True):
            assert sample.keys() == want.keys()
            assert torch.equal(sample["gt"], want["gt"])
            assert torch.equal(sample["sinc_kernel"], want["sinc_kernel"])
            for key, prob in (("kernel1", blur_prob), ("kernel2", blur_prob2)):
                assert torch.equal(sample[key], want[key] if prob > 0 else _pulse())


def _dataset_entry() -> dict[str, object]:
    return {
        "name": "kernels",
        "type": "RealESRGANDataset",
        "phase": "train",
        "scale": 2,
        "dataroot_gt": [str(HR)],
        "io_backend": {"type": "disk"},
        "gt_size": 64,
        "use_hflip": True,
        "use_rot": True,
        "sinc_prob": 0.4,
        "sinc_prob2": 0.4,
        "final_sinc_prob": 0.6,
    }


def test_dataset_from_dataset_options_builds_both_blur_kernels(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    opt = msgspec.convert(_dataset_entry(), DatasetOptions)
    assert opt.blur_prob > 0
    assert opt.blur_prob2 > 0
    _compare_with_full_sampler(monkeypatch, RealESRGANDataset(opt), 1.0, 1.0)


@pytest.mark.parametrize(("blur_prob", "blur_prob2"), [(0.0, 0.0), (0.3, 0.0)])
def test_parsed_options_skip_only_unused_blur_kernels(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    blur_prob: float,
    blur_prob2: float,
) -> None:
    config = {
        "name": "kernels",
        "scale": 2,
        "num_gpu": 1,
        "manual_seed": 1024,
        "high_order_degradation": True,
        "blur_prob": blur_prob,
        "blur_prob2": blur_prob2,
        "path": {},
        "datasets": {"train": _dataset_entry()},
        "train": {"total_iter": 1},
    }
    option_file = tmp_path / "kernels.yml"
    option_file.write_text(yaml.safe_dump(config))
    monkeypatch.setattr(sys, "argv", ["train.py", "-opt", str(option_file)])
    opt, _ = parse_options(str(tmp_path), is_train=True)
    dataset_opt = opt.datasets["train"]
    assert dataset_opt.blur_prob == blur_prob
    assert dataset_opt.blur_prob2 == blur_prob2
    _compare_with_full_sampler(
        monkeypatch, RealESRGANDataset(dataset_opt), blur_prob, blur_prob2
    )
