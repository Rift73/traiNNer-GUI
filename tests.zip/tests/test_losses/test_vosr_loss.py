import importlib.util
from pathlib import Path

import cv2
import numpy as np
import pytest
import torch
from PIL import Image
from traiNNer.losses.perceptual_loss import PerceptualLoss
from traiNNer.losses.vosr_loss import (
    VOSRLoss,
    VosrTeacher,
    balance_vosr,
    pillow_bicubic_up,
)

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "tests" / "data" / "vosr2"
ENGINES = ROOT / "vosr2-512-engines"
HAS_TEACHER = (
    torch.cuda.is_available()
    and importlib.util.find_spec("tensorrt") is not None
    and (ENGINES / "dit_cached.plan").is_file()
)
gpu = pytest.mark.skipif(
    not HAS_TEACHER, reason="needs CUDA, TensorRT and the VOSR engines"
)


@pytest.mark.parametrize("size", [(192, 192), (17, 31), (2, 3)])
@pytest.mark.parametrize("scale", [2, 4])
def test_pillow_bicubic_matches_pillow(size: tuple[int, int], scale: int) -> None:
    rng = np.random.default_rng(0)
    image = rng.integers(0, 256, (*size, 3), dtype=np.uint8)
    expected = np.asarray(
        Image.fromarray(image).resize(
            (size[1] * scale, size[0] * scale), Image.Resampling.BICUBIC
        )
    )
    ours = pillow_bicubic_up(torch.from_numpy(image).permute(2, 0, 1)[None], scale)
    assert np.array_equal(ours[0].permute(1, 2, 0).numpy(), expected)


def test_wavelet_colour_matches_upstream() -> None:
    from traiNNer.losses.vosr2_trt import wavelet_colour

    rng = np.random.default_rng(1)
    out, ref = (rng.random((64, 80, 3), dtype=np.float32) for _ in range(2))
    expected = np.clip(
        cv2.GaussianBlur(ref, (0, 0), 5) + out - cv2.GaussianBlur(out, (0, 0), 5), 0, 1
    )

    def to_tensor(array: np.ndarray) -> torch.Tensor:
        return torch.from_numpy(array).permute(2, 0, 1)[None] * 2 - 1

    ours = wavelet_colour(to_tensor(out), to_tensor(ref)) * 0.5 + 0.5
    assert np.abs(ours[0].permute(1, 2, 0).numpy() - expected).max() <= 1e-5


@pytest.mark.parametrize("weight", [1.0, 0.5])
def test_balance_constant_sequences(weight: float) -> None:
    state = None
    for _ in range(50):
        distance = torch.tensor(0.043, requires_grad=True)
        result = balance_vosr(distance, torch.tensor(0.021), state, weight)
        assert result is not None
        weighted, scale, state = result
    assert weighted.item() == pytest.approx(weight * 0.021, rel=1e-6)
    assert not scale.requires_grad
    weighted.backward()
    assert distance.grad is not None
    assert distance.grad.item() == pytest.approx(scale.item())


def test_balance_skips_without_gan() -> None:
    assert balance_vosr(torch.tensor(0.04), None, None, 1.0) is None


@pytest.mark.parametrize(
    ("kwargs", "match"),
    [
        ({"loss_weight": 0.0}, "positive"),
        ({"loss_weight": 1.0, "criterion": "mse"}, "criterion"),
        (
            {"loss_weight": 1.0, "perceptual_options": {"criterion": "fd"}},
            "criterion: perceptual",
        ),
        (
            {
                "loss_weight": 1.0,
                "criterion": "perceptual",
                "perceptual_options": {"criterion": "mse"},
            },
            "perceptual_options criterion",
        ),
        (
            {
                "loss_weight": 1.0,
                "criterion": "perceptual",
                "perceptual_options": {"loss_weight": 2.0},
            },
            "loss_weight",
        ),
    ],
)
def test_rejects_bad_options(kwargs: dict, match: str) -> None:
    with pytest.raises(ValueError, match=match):
        VOSRLoss(engine_dir="missing", plugin="missing", **kwargs)


class _IdentityWindow:
    """Stands in for the TensorRT window on the CPU: returns its 512 px windows unchanged."""

    def __init__(self, engine_dir: str, plugin: str, lanes: int = 2) -> None:
        self.device = torch.device("cpu")
        self.calls: list[tuple[tuple[int, ...], torch.Generator | None]] = []

    def __call__(
        self, windows: torch.Tensor, generator: torch.Generator | None = None
    ) -> torch.Tensor:
        self.calls.append((tuple(windows.shape), generator))
        return windows.clone()


@pytest.fixture
def cpu_teacher(monkeypatch: pytest.MonkeyPatch) -> VosrTeacher:
    from traiNNer.losses import vosr2_trt

    monkeypatch.setattr(vosr2_trt, "Vosr2Window", _IdentityWindow)
    return VosrTeacher("engines", "plugin.so")


def test_teacher_pads_crops_and_colour_corrects(cpu_teacher: VosrTeacher) -> None:
    # With an identity window the restoration is the bicubic input itself: any misplaced crop of the
    # reflect-padded 512 px window would bring mirrored pixels into the result.
    rng = np.random.default_rng(2)
    lq = rng.integers(0, 256, (2, 192, 160, 3), dtype=np.uint8)
    out = cpu_teacher.restore(torch.from_numpy(lq).permute(0, 3, 1, 2).float() / 255, 2)
    assert out.shape == (2, 3, 384, 320)
    assert out.dtype == torch.float32
    assert out.is_contiguous()
    window = cpu_teacher.window
    assert isinstance(window, _IdentityWindow)
    assert window.calls == [((2, 3, 512, 512), cpu_teacher.generator)]
    for index in range(2):
        expected = np.asarray(
            Image.fromarray(lq[index]).resize((320, 384), Image.Resampling.BICUBIC)
        )
        ours = out[index].permute(1, 2, 0).numpy() * 255
        assert np.abs(ours - expected).max() <= 1e-3


def test_teacher_rejects_large_output(
    cpu_teacher: VosrTeacher,
) -> None:  # Review Focus 4
    with pytest.raises(ValueError, match="512"):
        cpu_teacher.restore(torch.rand(1, 3, 300, 300), 2)


def test_perceptual_criterion_sums_vgg_layers(monkeypatch: pytest.MonkeyPatch) -> None:
    from traiNNer.losses import vosr2_trt

    monkeypatch.setattr(vosr2_trt, "Vosr2Window", _IdentityWindow)
    loss = VOSRLoss(1.0, "engines", "plugin.so", criterion="perceptual")
    lq = torch.rand(2, 3, 32, 32)
    output = torch.rand(2, 3, 64, 64, requires_grad=True)
    value = loss(output, lq)
    layers = PerceptualLoss(loss_weight=1.0)(
        output.detach(), loss.teacher.restore(lq, 2).clone()
    )
    assert set(layers) == {"conv1_2", "conv2_2", "conv3_4", "conv4_4", "conv5_4"}
    assert value.ndim == 0
    assert value.item() == pytest.approx(
        sum(layer.item() for layer in layers.values()), rel=1e-5
    )
    value.backward()
    assert output.grad is not None
    assert torch.isfinite(output.grad).all()
    assert output.grad.abs().sum() > 0


def test_perceptual_options_reach_perceptual_loss(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from traiNNer.losses import vosr2_trt

    monkeypatch.setattr(vosr2_trt, "Vosr2Window", _IdentityWindow)
    loss = VOSRLoss(
        1.0,
        "engines",
        "plugin.so",
        criterion="perceptual",
        perceptual_options={"criterion": "fd", "stride_fd": 4},
    )
    criterion = loss.criterion
    assert isinstance(criterion, PerceptualLoss)
    assert criterion.stride_fd == 4
    assert criterion.criterion2 == criterion.fd
    assert set(criterion.layer_weights) == {
        "relu1_2",
        "relu2_2",
        "relu3_4",
        "relu4_4",
        "relu5_4",
    }
    # 128 px output: fd's 5x5 projections need relu5_4 (1/16 size) to be at least 5 px
    output = torch.rand(1, 3, 128, 128, requires_grad=True)
    value = loss(output, torch.rand(1, 3, 64, 64))
    assert value.ndim == 0
    assert torch.isfinite(value)
    value.backward()
    assert output.grad is not None
    assert torch.isfinite(output.grad).all()


@pytest.fixture(scope="module")
def loss() -> VOSRLoss:
    return VOSRLoss(1.0, str(ENGINES), str(ENGINES / "vosr2_qkv.so"))


def _window() -> torch.Tensor:
    return torch.from_numpy(np.load(DATA / "input_window.npy")).cuda()


@gpu
def test_teacher_reference_window(loss: VOSRLoss) -> None:
    output = loss.teacher.window(_window())
    assert torch.isfinite(output).all()
    rgb = output[0].clamp(-1, 1).mul(0.5).add(0.5).permute(1, 2, 0).cpu().numpy()
    rgb = np.rint(rgb * 255).astype(np.uint8)
    expected = np.asarray(Image.open(DATA / "expected_output.png").convert("RGB"))
    assert np.abs(rgb.astype(int) - expected.astype(int)).mean() <= 1.0


@gpu
def test_fresh_noise_reproducible(loss: VOSRLoss) -> None:
    batch = _window().repeat(2, 1, 1, 1)
    a = loss.teacher.window(batch, torch.Generator("cuda").manual_seed(7))
    b = loss.teacher.window(batch, torch.Generator("cuda").manual_seed(7))
    c = loss.teacher.window(batch, torch.Generator("cuda").manual_seed(8))
    assert torch.equal(a, b)
    assert not torch.equal(a, c)
    assert not torch.equal(a[0], a[1])


@gpu
def test_partial_lane_group(loss: VOSRLoss) -> None:
    windows = torch.rand(3, 3, 512, 512, device="cuda") * 2 - 1
    out = loss.teacher.window(windows)
    assert out.shape == (3, 3, 512, 512)
    assert torch.equal(out[2], loss.teacher.window(windows[2:3])[0])


def _target(loss: VOSRLoss, lq: torch.Tensor) -> torch.Tensor:
    loss.teacher.generator.manual_seed(5)
    return loss.teacher.restore(lq, 2)


@gpu
def test_teacher_target_autocast_invariant(loss: VOSRLoss) -> None:
    lq = torch.rand(2, 3, 192, 192, device="cuda")
    with torch.autocast("cuda", dtype=torch.bfloat16):
        inside = _target(loss, lq)
    assert torch.equal(inside, _target(loss, lq))


@gpu
def test_teacher_target_channels_last(loss: VOSRLoss) -> None:
    lq = torch.rand(2, 3, 192, 192, device="cuda")
    channels_last = _target(loss, lq.to(memory_format=torch.channels_last))
    assert torch.equal(channels_last, _target(loss, lq))


@gpu
def test_forward_backward(loss: VOSRLoss) -> None:
    output = torch.rand(2, 3, 384, 384, device="cuda", requires_grad=True)
    value = loss(output, torch.rand(2, 3, 192, 192, device="cuda"))
    assert value.ndim == 0
    assert torch.isfinite(value)
    value.backward()
    assert output.grad is not None


@gpu
@pytest.mark.parametrize("options", [None, {"criterion": "fd", "stride_fd": 4}])
def test_perceptual_forward_backward_as_in_training(options: dict | None) -> None:
    # As the loss loop runs it: moved to the GPU in channels-last, called under autocast
    loss = VOSRLoss(
        1.0,
        str(ENGINES),
        str(ENGINES / "vosr2_qkv.so"),
        criterion="perceptual",
        perceptual_options=options,
    ).to("cuda", memory_format=torch.channels_last)
    output = torch.rand(2, 3, 384, 384, device="cuda")
    output = output.to(memory_format=torch.channels_last).requires_grad_()
    with torch.autocast("cuda", dtype=torch.bfloat16):
        value = loss(output, torch.rand(2, 3, 192, 192, device="cuda"))
    assert value.ndim == 0
    assert value.dtype == torch.float32
    assert torch.isfinite(value)
    value.backward()
    assert output.grad is not None
    assert torch.isfinite(output.grad).all()
    assert output.grad.abs().sum() > 0
