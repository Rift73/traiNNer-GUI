import numpy as np
import pytest
from traiNNer.data.descale import (
    TRANSFERS,
    descale,
    encode_light,
    linearize,
    upscale,
    upscale_matrix,
)

KERNELS = ["bilinear", "bicubic", "lanczos", "spline16", "spline36", "spline64"]
BORDERS = ["mirror", "zero", "extend"]


def _native(shape: tuple[int, int, int], seed: int = 0) -> np.ndarray:
    return np.random.default_rng(seed).random(shape, dtype=np.float32)


@pytest.mark.parametrize("border", BORDERS)
@pytest.mark.parametrize("kernel", KERNELS)
def test_descale_inverts_upscale(kernel: str, border: str) -> None:
    x = _native((23, 31, 3))
    big = upscale(x, 48, 36, kernel, border=border)
    assert big.shape == (36, 48, 3)
    out = descale(big, 31, 23, kernel, border=border)
    assert out.dtype == np.float32
    assert np.abs(out - x).max() <= 1e-4


def test_point_kernel_inverts_upscale() -> None:
    x = _native((10, 14, 2))
    out = descale(upscale(x, 28, 20, "point"), 14, 10, "point")
    assert np.abs(out - x).max() <= 1e-4


@pytest.mark.parametrize("kernel", ["bilinear", "lanczos"])
def test_matches_dense_least_squares(kernel: str) -> None:
    image = _native((30, 40, 2), seed=1)
    out = descale(image, 29, 21, kernel)
    horizontal = upscale_matrix(29, 40, kernel, "mirror").toarray()
    vertical = upscale_matrix(21, 30, kernel, "mirror").toarray()
    for k in range(2):
        expected = np.linalg.lstsq(
            np.kron(vertical, horizontal), image[:, :, k].ravel(), rcond=None
        )[0].reshape(21, 29)
        assert np.abs(out[:, :, k] - expected).max() <= 1e-4


def test_one_axis_unchanged() -> None:
    x = _native((12, 20, 3), seed=2)
    big = upscale(x, 30, 12)
    assert np.abs(descale(big, 20, 12) - x).max() <= 1e-4
    assert np.array_equal(descale(x, 20, 12), x)


def test_full_frame_shape_and_finite() -> None:
    frame = _native((1080, 1920, 3), seed=3)
    out = descale(frame, 1488, 837)
    assert out.shape == (837, 1488, 3)
    assert out.dtype == np.float32
    assert out.flags.c_contiguous
    assert np.isfinite(out).all()


@pytest.mark.parametrize("transfer", TRANSFERS)
def test_linear_light_round_trip(transfer: str) -> None:
    values = np.linspace(-0.2, 1.2, 141, dtype=np.float32).reshape(1, -1, 1)
    back = encode_light(linearize(values, transfer), transfer)
    assert np.abs(back - values).max() <= 1e-5
    assert np.all(np.sign(linearize(values, transfer)) == np.sign(values))
    x = _native((15, 18, 3), seed=4)
    big = upscale(x, 27, 22, linear_light=transfer)
    out = descale(big, 18, 15, linear_light=transfer)
    assert np.abs(out - x).max() <= 1e-4


def test_invalid_arguments_raise() -> None:
    image = _native((20, 20, 3))
    with pytest.raises(ValueError, match="kernel"):
        descale(image, 10, 10, "mitchell")
    with pytest.raises(ValueError, match="border"):
        descale(image, 10, 10, border="wrap")
    with pytest.raises(ValueError, match="transfer"):
        descale(image, 10, 10, linear_light="pq")
    with pytest.raises(ValueError, match="no larger"):
        descale(image, 21, 10)
    with pytest.raises(ValueError, match="no larger"):
        descale(image, 0, 10)
    with pytest.raises(ValueError, match="no smaller"):
        upscale(image, 10, 30)
    with pytest.raises(ValueError, match="float32"):
        descale(image.astype(np.float64), 10, 10)
    with pytest.raises(ValueError, match="float32"):
        descale(image[:, :, 0], 10, 10)
