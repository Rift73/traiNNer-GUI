import numpy as np
import pytest
import torch
from traiNNer.metrics.psnr_ssim import calculate_psnr, calculate_ssim, calculate_ssim_pt


def test_calculate_psnr() -> None:
    """Test metric: calculate_psnr"""

    # mismatched image shapes
    with pytest.raises(AssertionError):
        calculate_psnr(np.ones((16, 16)), np.ones((10, 10)), crop_border=0)

    # wrong input order
    with pytest.raises(ValueError):
        calculate_psnr(
            np.ones((16, 16)), np.ones((16, 16)), crop_border=1, input_order="WRONG"
        )

    out = calculate_psnr(
        np.ones((10, 10, 3)),
        np.ones((10, 10, 3)) * 2,
        crop_border=1,
        test_y_channel=True,
    )
    assert isinstance(out, float)

    # test float inf
    out = calculate_psnr(np.ones((10, 10, 3)), np.ones((10, 10, 3)), crop_border=0)
    assert out == float("inf")


def test_calculate_ssim() -> None:
    """Test metric: calculate_ssim"""

    # mismatched image shapes
    with pytest.raises(AssertionError):
        calculate_ssim(np.ones((16, 16)), np.ones((10, 10)), crop_border=0)

    # wrong input order
    with pytest.raises(ValueError):
        calculate_ssim(
            np.ones((16, 16)), np.ones((16, 16)), crop_border=1, input_order="WRONG"
        )

    out = calculate_ssim(
        np.ones((10, 10, 3)),
        np.ones((10, 10, 3)) * 2,
        crop_border=1,
        test_y_channel=True,
    )
    assert isinstance(out, float)

@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
def test_cuda_ssim_preserves_each_cropped_image_score() -> None:
    rng = torch.Generator().manual_seed(77)
    reference = torch.rand(2, 3, 37, 78, generator=rng)[:, :, :, ::2]
    restored = torch.rand(reference.shape, generator=rng)
    # Low variance exposes cancellation in the local second moments.
    reference[0].mul_(1e-5).add_(0.5)
    restored[0].mul_(1e-5).add_(0.5)
    expected = calculate_ssim_pt(restored, reference, crop_border=4)
    actual = calculate_ssim_pt(restored.cuda(), reference.cuda(), crop_border=4)
    torch.testing.assert_close(actual.cpu(), expected, atol=2e-12, rtol=1e-10)
