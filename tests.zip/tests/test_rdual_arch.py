"""Recurrent DUAL: DUAL transfer boundary, donor dependency, gating and state."""

import copy
import os
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest
import torch
import torch.nn.functional as F  # noqa: N812
from torch.utils.checkpoint import CheckpointPolicy
from traiNNer.archs import rdual_arch
from traiNNer.archs.dual_arch import dual_light
from traiNNer.archs.rdual_arch import (
    _HAS_DIRECT_ATTENTION,
    RDUAL,
    DynamicRouter,
    StateFusion,
    _flow_pairs_per_call,
    _premixed_conv3x3,
    _selective_checkpoint_policy,
    _SpatialAttention,
    _temporal_checkpoint_policy,
    alignment_cues,
    rdual,
)


def randomize_fusion(model: RDUAL) -> None:
    with torch.no_grad():
        model.temporal.output.weight.normal_(std=0.02)
        model.temporal.cosine.normal_(std=0.01)
        model.temporal.sine.normal_(std=0.01)
        model.temporal.key.weight[31::32].normal_(std=0.02)
        model.temporal.cue_score[2].weight.normal_(std=0.5)
        model.temporal.cue_score[2].bias.normal_(std=0.5)


def trainable(model: RDUAL) -> list[tuple[str, torch.nn.Parameter]]:
    """Named parameters that train (the frozen flow estimator has none)."""
    return [(n, p) for n, p in model.named_parameters() if p.requires_grad]


def _rdual_only(name: str) -> bool:
    """A state entry RDUAL has beyond DUAL Light's."""
    return name.startswith(("temporal.", "flow.")) or name == "flow_loaded"


def guidance_for(frames: torch.Tensor) -> torch.Tensor:
    batch, count, _, height, width = frames.shape
    shape = (batch, count - 1, 2, 2, ((height + 3) // 4) * 2, ((width + 3) // 4) * 2)
    return torch.randn(shape) * 0.6


def step(
    model: RDUAL,
    frame: torch.Tensor,
    state: torch.Tensor | None = None,
    flow: torch.Tensor | None = None,
    valid: torch.Tensor | None = None,
    *,
    future: tuple[torch.Tensor, torch.Tensor, torch.Tensor] | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    """One frame through encode() and step_encoded(), cropped to its size."""
    height, width = frame.shape[-2:]
    out, carried = model.step_encoded(
        model.encode(frame), state, flow, valid, future=future
    )
    assert out is not None
    return out[..., : height * model.scale, : width * model.scale], carried


@pytest.mark.parametrize("scale", [1, 2, 4])
def test_dual_light_checkpoint_start_and_donor_fallback(scale: int) -> None:
    torch.set_num_threads(2)
    torch.manual_seed(71)
    spatial = dual_light(scale=scale, use_checkpoint=False).eval()
    model = RDUAL(scale=scale, use_checkpoint=False).eval()
    missing, unexpected = model.load_state_dict(spatial.state_dict(), strict=False)
    assert not unexpected and missing and all(_rdual_only(n) for n in missing)
    frames = torch.rand(1, 3, 3, 9, 11)
    guidance = guidance_for(frames)
    with torch.no_grad():
        expected = torch.stack([spatial(frames[:, t]) for t in range(3)], 1)
        torch.testing.assert_close(
            model(frames, guidance), expected, rtol=2e-5, atol=2e-6
        )
        randomize_fusion(model)
        assert not torch.allclose(model(frames, guidance), expected, atol=1e-5)
        cuts = torch.tensor([[0, 1, 2]])
        torch.testing.assert_close(
            model(frames, guidance, shot_ids=cuts), expected, rtol=2e-5, atol=2e-6
        )
        middle_invalid = torch.tensor([[True, False, True]])
        actual = model(frames, guidance, middle_invalid)
        torch.testing.assert_close(
            actual[:, (0, 2)], expected[:, (0, 2)], rtol=2e-5, atol=2e-6
        )


def test_outputs_depend_on_both_directions() -> None:
    torch.set_num_threads(2)
    torch.manual_seed(72)
    model = RDUAL(scale=2, use_checkpoint=False).eval()
    randomize_fusion(model)
    frames = torch.rand(1, 3, 3, 8, 8, requires_grad=True)
    guidance = guidance_for(frames)
    out = model(frames, guidance)
    last = torch.autograd.grad(out[:, 2].square().mean(), frames, retain_graph=True)[0]
    assert last[:, 0].abs().sum() > 0 and last[:, 1].abs().sum() > 0
    first = torch.autograd.grad(out[:, 0].square().mean(), frames, retain_graph=True)[0]
    assert first[:, 1].abs().sum() > 0 and first[:, 2].abs().sum() > 0
    out.square().mean().backward()
    assert all(
        v.grad is not None and torch.isfinite(v.grad).all()
        for v in model.parameters()
        if v.requires_grad
    )
    assert model.temporal.frequency.grad.abs().sum() > 0
    assert model.temporal.state_norm.norm.weight.grad.abs().sum() > 0


def test_steps_with_both_donors_reproduce_the_sweeps() -> None:
    torch.set_num_threads(2)
    torch.manual_seed(75)
    model = RDUAL(scale=2, use_checkpoint=False).eval()
    randomize_fusion(model)
    frames = torch.rand(2, 3, 3, 9, 11)
    guidance = guidance_for(frames)
    valid = torch.tensor([[True, True, True], [True, False, True]])
    edge = valid[:, 1:] & valid[:, :-1]
    on = torch.ones(2, dtype=torch.bool)
    packed = model.pack_guidance(frames, guidance)
    with torch.no_grad():
        expected = model(frames, guidance, valid)
        future: list[tuple[torch.Tensor, torch.Tensor, torch.Tensor] | None] = [
            None
        ] * 4
        for t in reversed(range(3)):
            state = step(model, frames[:, t], future=future[t + 1])[1]
            if t:
                future[t] = (state, packed[:, t - 1, 1], edge[:, t - 1])
        state, outputs = None, []
        for t in range(3):
            flow = packed[:, t - 1, 0] if t else None
            link = edge[:, t - 1] if t else None
            out, state = step(
                model, frames[:, t], state, flow, link, future=future[t + 1]
            )
            outputs.append(out)
        ahead = future[1]
        assert ahead is not None
        blocked = step(model, frames[:, 0], future=(ahead[0], ahead[1], ~on))[0]
        torch.testing.assert_close(
            blocked, step(model, frames[:, 0])[0], rtol=2e-5, atol=2e-6
        )
    torch.testing.assert_close(
        torch.stack(outputs, 1)[0], expected[0], rtol=2e-5, atol=2e-6
    )
    torch.testing.assert_close(
        torch.stack(outputs, 1)[1, (0, 2)], expected[1, (0, 2)], rtol=2e-5, atol=2e-6
    )


def test_checkpoint_preserves_temporal_and_spatial_gradients() -> None:
    torch.set_num_threads(2)
    torch.manual_seed(98)
    direct = RDUAL(scale=2, use_checkpoint=False).train()
    randomize_fusion(direct)
    recompute = copy.deepcopy(direct)
    recompute.use_checkpoint = True
    for group in recompute.groups:
        group.use_checkpoint = True
    x = torch.rand(1, 3, 3, 8, 8, requires_grad=True)
    xc = x.detach().clone().requires_grad_()
    guidance = guidance_for(x)
    a, b = direct(x, guidance), recompute(xc, guidance)
    torch.testing.assert_close(a, b, rtol=0, atol=0)
    g = torch.randn_like(a)
    (a * g).sum().backward()
    (b * g).sum().backward()
    torch.testing.assert_close(x.grad, xc.grad, rtol=1e-6, atol=1e-7)
    for name, v in trainable(direct):
        torch.testing.assert_close(
            v.grad, recompute.get_parameter(name).grad, rtol=1e-6, atol=1e-7
        )


def test_guidance_contract() -> None:
    model = rdual(scale=2, use_checkpoint=False).eval()
    frames = torch.rand(1, 3, 3, 8, 8)
    # Without flow weights, no guidance is an error that names the remedies.
    for call in (
        lambda: model(frames),
        lambda: model(frames, None),
        lambda: model.infer(frames),
        lambda: model.backward_clip(frames, None, lambda out, t: out.sum()),
        lambda: model.guidance(frames),
    ):
        with pytest.raises(RuntimeError, match=r"load_flow_weights.*guidance tensor"):
            call()
    with pytest.raises(ValueError, match="Guidance"):
        model(frames, torch.zeros(1, 3, 2, 2, 4, 4))
    with pytest.raises(ValueError, match="Guidance"):
        model(frames, torch.zeros(1, 2, 1, 2, 4, 4))
    with pytest.raises(ValueError, match="detached"):
        model(frames, torch.zeros(1, 2, 2, 2, 4, 4, requires_grad=True))
    for bad in (float("nan"), float("inf")):
        with pytest.raises(ValueError, match="finite"):
            model(frames, torch.full((1, 2, 2, 2, 4, 4), bad))
    with torch.no_grad():
        assert model(frames[:, :1], torch.zeros(1, 0, 2, 2, 4, 4)).shape == (
            1,
            1,
            3,
            16,
            16,
        )


def frame_by_frame(model: RDUAL, frames: torch.Tensor, replay: bool) -> None:
    """One backward per frame: detached states, or exact replay last to first."""
    generator = torch.manual_seed(12)
    # Non-zero cues give the first cue-score layer a gradient as well.
    guidance = torch.cat(
        (
            torch.randn(1, 3, 1, 2, 4, 4, generator=generator) * 0.6,
            torch.rand(1, 3, 1, 3, 4, 4, generator=generator),
        ),
        3,
    )
    flows = [None] + [guidance[:, t, 0] for t in range(3)]
    if not replay:
        state = None
        for t in range(4):
            out, state = step(model, frames[:, t], state, flows[t])
            out.square().mean().backward()
            state = state.detach()
        return
    states: list[torch.Tensor | None] = [None]
    with torch.no_grad():
        for t in range(3):
            states.append(step(model, frames[:, t], states[t], flows[t])[1])
    adjoint = None
    for t in reversed(range(4)):
        state = states[t]
        if state is not None:
            state = state.requires_grad_()
        out, carried = step(model, frames[:, t], state, flows[t])
        loss = out.square().mean()
        if adjoint is not None:
            loss = loss + (carried * adjoint).sum()
        loss.backward()
        adjoint = None if state is None else state.grad


@pytest.mark.parametrize("replay", [False, True])
def test_fold_cache_gives_the_per_frame_gradients(replay: bool) -> None:
    torch.set_num_threads(2)
    torch.manual_seed(76)
    model = RDUAL(scale=2, use_checkpoint=False).train()
    randomize_fusion(model)
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn_like(parameter) * 1e-3)
    frames = torch.rand(1, 4, 3, 8, 8)
    frame_by_frame(model, frames, replay)
    expected = {n: v.grad.clone() for n, v in trainable(model)}
    model.zero_grad(set_to_none=True)
    with model.fold_cache(model.compose_kernels if replay else None):
        frame_by_frame(model, frames, replay)
        assert model.stem.fold_kernel.grad.abs().sum() > 0
    for name, v in trainable(model):
        relative = (v.grad - expected[name]).norm() / expected[name].norm()
        assert expected[name].norm() > 0 and relative < 1e-5, name


def test_fold_cache_reads_its_kernels_and_refuses_misuse() -> None:
    torch.set_num_threads(2)
    torch.manual_seed(78)
    model = RDUAL(scale=2, use_checkpoint=False).train()
    frame = torch.rand(1, 3, 8, 8)
    with torch.no_grad():
        expected = step(model, frame)[0]
        with model.fold_cache():
            # Stale on purpose: frames must read the kernels composed on entry.
            model.stem.direct.reduce.weight.mul_(2)
            torch.testing.assert_close(
                step(model, frame)[0], expected, rtol=0, atol=1e-6
            )
        assert not torch.allclose(step(model, frame)[0], expected, atol=1e-4)
    with (
        pytest.raises(RuntimeError, match="already active"),
        model.fold_cache(),
        model.fold_cache(),
    ):
        pass
    with pytest.raises(RuntimeError, match="without a backward"), model.fold_cache():
        step(model, frame)
    assert not any(getattr(m, "fold_active", False) for m in model.modules())
    with model.fold_cache():
        step(model, frame)[0].mean().backward()
    assert model.stem.direct.reduce.weight.grad.abs().sum() > 0
    copy.deepcopy(model.double())


def test_fold_cache_leaves_state_keys_and_plain_calls_unchanged() -> None:
    torch.set_num_threads(2)
    torch.manual_seed(77)
    model = RDUAL(scale=2, use_checkpoint=False).eval()
    randomize_fusion(model)
    frames = torch.rand(1, 2, 3, 8, 8)
    guidance = guidance_for(frames)
    keys = list(model.state_dict())
    with torch.no_grad():
        expected = model(frames, guidance)
        with model.fold_cache():
            torch.testing.assert_close(
                model(frames, guidance), expected, rtol=0, atol=1e-6
            )
        with pytest.raises(RuntimeError, match="inside"), model.fold_cache():
            raise RuntimeError("inside")
        torch.testing.assert_close(model(frames, guidance), expected, rtol=0, atol=0)
    assert list(model.state_dict()) == keys
    assert not any(getattr(m, "fold_active", False) for m in model.modules())
    spatial = dual_light(scale=2, use_checkpoint=False)
    missing, unexpected = model.load_state_dict(spatial.state_dict(), strict=False)
    assert not unexpected and all(_rdual_only(n) for n in missing)


def test_steps_match_for_frames_encoded_together() -> None:
    torch.set_num_threads(2)
    torch.manual_seed(78)
    model = RDUAL(scale=2, use_checkpoint=False).eval()
    randomize_fusion(model)
    frames = torch.rand(2, 3, 3, 9, 11)
    guidance = model.pack_guidance(frames, guidance_for(frames))
    on = torch.ones(2, dtype=torch.bool)
    with torch.no_grad():
        together = model.encode(frames.transpose(0, 1).reshape(6, 3, 9, 11))
        state = None
        for t in range(3):
            encoded = tuple(x[2 * t : 2 * t + 2] for x in together)
            flow = guidance[:, t - 1, 0] if t else None
            future = (torch.randn(2, 128, 6, 6), guidance[:, min(t, 1), 1], on)
            out, carried = step(model, frames[:, t], state, flow, future=future)
            padded, same = model.step_encoded(encoded, state, flow, future=future)
            assert padded is not None
            torch.testing.assert_close(
                padded[:, :, :18, :22], out, rtol=2e-5, atol=2e-6
            )
            torch.testing.assert_close(same, carried, rtol=2e-5, atol=2e-6)
            skipped, only = model.step_encoded(
                encoded, state, flow, future=future, output=False
            )
            assert skipped is None
            torch.testing.assert_close(only, carried, rtol=2e-5, atol=2e-6)
            state = carried
    with pytest.raises(ValueError, match="B,3,H,W"):
        model.encode(frames)


@pytest.mark.parametrize("use_checkpoint", [False, True])
def test_encoded_leaves_carry_the_step_gradients(use_checkpoint: bool) -> None:
    torch.set_num_threads(2)
    torch.manual_seed(79)
    model = RDUAL(scale=2, use_checkpoint=use_checkpoint).train()
    randomize_fusion(model)
    frames = torch.rand(1, 2, 3, 8, 8, requires_grad=True)
    target = torch.rand(1, 2, 3, 16, 16)
    flow = torch.cat((torch.randn(1, 2, 4, 4) * 0.6, torch.rand(1, 3, 4, 4)), 1)
    donor = torch.randn(1, 128, 4, 4)
    on = torch.ones(1, dtype=torch.bool)

    def loss_of(t: int, out: torch.Tensor | None, state: torch.Tensor) -> torch.Tensor:
        value = state.square().mean()
        return value if out is None else value + (out - target[:, t]).abs().mean()

    # Frame 0 contributes only through its state, as a reverse-sweep step does.
    for t in range(2):
        out, state = step(model, frames[:, t], future=(donor, flow, on))
        loss_of(t, out if t else None, state).backward()
    expected = {n: v.grad.clone() for n, v in trainable(model)}
    expected_input = frames.grad.clone()
    model.zero_grad(set_to_none=True)
    frames.grad = None
    with torch.no_grad():
        stored = model.encode(frames.transpose(0, 1).reshape(2, 3, 8, 8))
    leaves = [x.detach().requires_grad_() for x in stored]
    for t in range(2):
        encoded = tuple(x[t : t + 1] for x in leaves)
        out, state = model.step_encoded(encoded, future=(donor, flow, on), output=t > 0)
        loss_of(t, out, state).backward()
    pending = [
        (x, leaf.grad)
        for x, leaf in zip(
            model.encode(frames.transpose(0, 1).reshape(2, 3, 8, 8)),
            leaves,
            strict=True,
        )
        if leaf.grad is not None
    ]
    torch.autograd.backward([x for x, _ in pending], [g for _, g in pending])
    for name, value in trainable(model):
        torch.testing.assert_close(value.grad, expected[name], rtol=1e-4, atol=1e-6)
    torch.testing.assert_close(frames.grad, expected_input, rtol=1e-4, atol=1e-6)


def test_forward_runs_one_reverse_pass_per_read_state() -> None:
    torch.set_num_threads(2)
    torch.manual_seed(80)
    model = RDUAL(scale=2, use_checkpoint=False).eval()
    frames = torch.rand(1, 4, 3, 8, 8)
    guidance = guidance_for(frames)
    calls = []
    # The second group runs once per trunk pass, after the fusion point.
    handle = model.groups[1].register_forward_hook(lambda *_: calls.append(1))
    with torch.no_grad():
        model(frames, guidance)
    handle.remove()
    # Four forward-sweep frames, and reverse states for frames 1-3 only.
    assert len(calls) == 7


def test_file_runs_without_the_trainner_package(tmp_path: Path) -> None:
    script = textwrap.dedent(
        f"""
        import importlib.abc
        import importlib.util
        import sys


        class BlockTrainner(importlib.abc.MetaPathFinder):
            def find_spec(self, name, path=None, target=None):
                if name == "traiNNer" or name.startswith("traiNNer."):
                    raise ModuleNotFoundError(f"No module named {{name!r}}", name=name)
                return None


        sys.meta_path.insert(0, BlockTrainner())
        import torch

        spec = importlib.util.spec_from_file_location(
            "rdual_file_only", {rdual_arch.__file__!r}
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        assert not any(name.split(".")[0] == "traiNNer" for name in sys.modules)
        torch.manual_seed(0)
        frames = torch.rand(1, 2, 3, 8, 8)
        model = module.RDUAL(scale=2).eval()
        with torch.no_grad():
            out = model(frames, torch.zeros(1, 1, 2, 2, 4, 4))
        assert out.shape == (1, 2, 3, 16, 16) and out.isfinite().all()
        print("standalone ok")
        """
    )
    result = subprocess.run(
        [sys.executable, "-c", script],
        cwd=tmp_path,
        env={**os.environ, "CUDA_VISIBLE_DEVICES": ""},
        capture_output=True,
        text=True,
        timeout=600,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "standalone ok" in result.stdout


@pytest.mark.skipif(not _HAS_DIRECT_ATTENTION, reason="the bundled ops require Triton")
def test_checkpoint_policies_save_the_bundled_attention_ops() -> None:
    spatial = torch.ops.rdual_standalone.dense_rpb_attention.default
    temporal = torch.ops.rdual_standalone.attention.default
    assert str(spatial) == "rdual_standalone.dense_rpb_attention.default"
    assert str(temporal) == "rdual_standalone.attention.default"
    for policy in (
        _selective_checkpoint_policy,
        _temporal_checkpoint_policy,
    ):
        assert policy(None, spatial) is CheckpointPolicy.MUST_SAVE
        assert policy(None, torch.ops.aten.mm.default) is (
            CheckpointPolicy.PREFER_RECOMPUTE
        )
    assert _temporal_checkpoint_policy(None, temporal) is CheckpointPolicy.MUST_SAVE
    assert (
        _temporal_checkpoint_policy(None, torch.ops.rdual_standalone.flow_kv.default)
        is CheckpointPolicy.PREFER_RECOMPUTE
    )


def test_triton_backend_reports_missing_kernels(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(rdual_arch, "_HAS_DIRECT_ATTENTION", False)
    monkeypatch.setattr(rdual_arch, "_DIRECT_ATTENTION_ERROR", "missing triton")
    with pytest.raises(RuntimeError, match="temporal kernels are unavailable"):
        rdual(scale=2, temporal_backend="triton")


def test_auto_backend_is_the_default_and_matches_the_reference_on_cpu() -> None:
    torch.manual_seed(5)
    model = rdual(scale=2).eval()
    assert model.temporal.backend == "auto"
    randomize_fusion(model)
    reference = rdual(scale=2, temporal_backend="reference").eval()
    reference.load_state_dict(model.state_dict())
    frames = torch.rand(1, 2, 3, 8, 8)
    guidance = guidance_for(frames)
    with torch.no_grad():
        assert torch.equal(model(frames, guidance), reference(frames, guidance))
    with pytest.raises(ValueError, match="temporal_backend"):
        rdual(scale=2, temporal_backend="cuda")


def test_auto_backend_falls_back_without_the_kernels(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(rdual_arch, "_HAS_DIRECT_ATTENTION", False)
    model = rdual(scale=2).eval()
    assert not model.temporal.kernels_available
    assert "-rdual-reference-" in model.compile_cache_key_tag
    frames = torch.rand(1, 2, 3, 8, 8)
    with torch.no_grad():
        out = model(frames, guidance_for(frames))
    assert out.shape == (1, 2, 3, 16, 16) and out.isfinite().all()


def test_constructor_accepts_only_the_supported_options() -> None:
    for option in (
        {"bidirectional": True},
        {"context_na": True},
        {"embed_dim": 96},
        {"pixel_unshuffle": True},
        {"g_attention_impl": "direct"},
        {"detach_state": False},
        {"attn_type": "masked"},
        {"attn_type": "hybrid"},
    ):
        with pytest.raises(TypeError):
            RDUAL(scale=2, **option)
    for option in (
        {"scale": 3},
        {"dynamic_experts": True},
        {"dynamic_experts": 1},
        {"c_windows": (32,)},
        {"use_checkpoint": 1},
        {"local_na": 1},
        {"retrieval_na": None},
    ):
        with pytest.raises(ValueError):
            RDUAL(**option)
    model = RDUAL(scale=2, dynamic_experts=3, c_windows=[16, 48])
    assert model.groups[0].conv.experts.shape[0] == 3
    assert model.groups[0].layers[2].attention.window == 16
    assert model.groups[1].layers[2].attention.window == 48
    assert model.local_na and model.retrieval_na
    assert all(m.local_na for m in spatial_layers(model, False))
    assert not any(m.local_na for m in spatial_layers(model, True))
    windows = RDUAL(scale=2, local_na=False, retrieval_na=False)
    assert not windows.local_na and not windows.retrieval_na
    assert not any(m.local_na for m in spatial_layers(windows, False))
    assert windows.state_dict().keys() == model.state_dict().keys()


def test_routing_na_defaults_validation_and_cache_tag() -> None:
    model, routed = RDUAL(scale=2), rdual(scale=2, routing_na=True)
    assert not model.routing_na and routed.routing_na
    assert not any(m.routing_na for m in model.modules() if isinstance(m, DynamicRouter))
    assert all(m.routing_na for m in routed.modules() if isinstance(m, DynamicRouter))
    assert "routing-na" not in model.compile_cache_key_tag
    assert routed.compile_cache_key_tag == model.compile_cache_key_tag + ":routing-na"
    assert routed.state_dict().keys() == model.state_dict().keys()
    with pytest.raises(ValueError, match="routing_na"):
        RDUAL(scale=2, routing_na=1)


def routed_case(
    height: int, width: int
) -> tuple[DynamicRouter, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    torch.manual_seed(5)
    router = DynamicRouter(16, 3).double()
    with torch.no_grad():
        router.fc2.bias.normal_(0, 0.5)
    x = torch.randn(2, 16, height, width, dtype=torch.float64)
    experts = torch.randn(3, 16, 16 * 9, dtype=torch.float64) * 0.05
    w0 = torch.randn(16, 16, 3, 3, dtype=torch.float64) * 0.1
    b0 = torch.randn(16, dtype=torch.float64)
    return router, x, experts, w0, b0


@pytest.mark.parametrize(("height", "width"), [(96, 96), (40, 96), (96, 17)])
def test_routing_na_keeps_maps_within_96_per_image(height: int, width: int) -> None:
    router, x, experts, w0, b0 = routed_case(height, width)
    off = _premixed_conv3x3(x, w0, b0, experts, router(x))
    router.routing_na = True
    coefficients = router(x)
    assert coefficients.shape == (2, 3, 1, 1)
    on = _premixed_conv3x3(x, w0, b0, experts, coefficients)
    torch.testing.assert_close(on, off, atol=0, rtol=0)


def test_routing_na_keeps_the_rdual_function_within_reach() -> None:
    torch.manual_seed(12)
    model = RDUAL(scale=2, use_checkpoint=False).eval()
    with torch.no_grad():
        for group in model.groups:
            group.conv.experts.normal_(0, 0.02)
            group.conv.router.fc2.bias.normal_(0, 0.5)
    randomize_fusion(model)
    routed = copy.deepcopy(model)
    for router in (m for m in routed.modules() if isinstance(m, DynamicRouter)):
        router.routing_na = True
    frames = torch.rand(1, 2, 3, 20, 28)
    guidance = guidance_for(frames)
    with torch.no_grad():
        torch.testing.assert_close(
            routed(frames, guidance), model(frames, guidance), atol=0, rtol=0
        )


@pytest.mark.parametrize(("height", "width"), [(100, 104), (97, 30)])
def test_routing_na_reads_each_position_clamped_96x96_mean(
    height: int, width: int
) -> None:
    router, x, experts, w0, b0 = routed_case(height, width)
    router.routing_na = True
    coefficients = router(x)
    assert coefficients.shape == (2, 3, height, width)
    out = _premixed_conv3x3(x, w0, b0, experts, coefficients)
    base = F.conv2d(x, w0, b0, padding=1)
    convs = [
        F.conv2d(x, experts[i].reshape(16, 16, 3, 3), padding=1) for i in range(3)
    ]
    ky, kx = min(96, height), min(96, width)
    for n, y, xx in ((0, 0, 0), (1, height - 1, width - 1), (0, 50, 7), (1, 3, width - 2)):
        sy = min(max(y - ky // 2, 0), height - ky)
        sx = min(max(xx - kx // 2, 0), width - kx)
        mean = x[n, :, sy : sy + ky, sx : sx + kx].mean((1, 2))
        hidden = F.gelu(
            F.linear(F.layer_norm(mean, (16,), eps=1e-5), router.fc1.weight, router.fc1.bias)
        )
        c = F.linear(hidden, router.fc2.weight, router.fc2.bias).softmax(-1) - 1 / 3
        ref = base[n, :, y, xx] + sum(c[i] * convs[i][n, :, y, xx] for i in range(3))
        torch.testing.assert_close(out[n, :, y, xx], ref, atol=1e-12, rtol=1e-10)


def spatial_layers(model: RDUAL, context: bool) -> list[_SpatialAttention]:
    return [
        m
        for m in model.modules()
        if isinstance(m, _SpatialAttention) and m.context == context
    ]


def test_prepare_for_compile_sets_only_the_bf16_context_layout() -> None:
    model = rdual(scale=2, local_na=False).train()
    context = spatial_layers(model, True)
    with pytest.raises(ValueError, match="B,T,3,H,W"):
        model.prepare_for_compile((2, 3, 64, 64), torch.bfloat16)
    model.prepare_for_compile((1, 2, 3, 64, 64), torch.bfloat16)
    assert all(m.na_training_fast for m in context)
    model.prepare_for_compile(None, torch.float16)
    assert not any(m.na_training_fast for m in context)
    model.eval().prepare_for_compile((1, 2, 3, 64, 64), torch.bfloat16)
    assert not any(m.na_training_fast for m in context)


def test_cpu_training_keeps_sdpa_without_a_report() -> None:
    # Kernels run only for CUDA BF16/FP16 training calls; CPU stays silent.
    torch.manual_seed(10)
    model = RDUAL(scale=2, use_checkpoint=False, local_na=False).train()
    randomize_fusion(model)
    frames = torch.rand(1, 2, 3, 64, 64)
    model(frames, guidance_for(frames))
    assert not any(m.direct_fallback_reason for m in model.modules() if isinstance(m, _SpatialAttention))


def test_export_folding_keeps_the_outputs() -> None:
    torch.manual_seed(88)
    model = RDUAL(scale=2, use_checkpoint=False).eval()
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.add_(torch.randn_like(parameter) * 1e-3)
    randomize_fusion(model)
    frames = torch.rand(1, 3, 3, 10, 12)
    guidance = guidance_for(frames)
    with pytest.raises(RuntimeError, match="eval"):
        copy.deepcopy(model).train().prepare_for_export()
    deployed = copy.deepcopy(model)
    deployed.prepare_for_export()
    deployed.prepare_for_export()
    assert deployed.deployed
    assert not any(
        isinstance(m, rdual_arch.EDBBReparamConv3x3) for m in deployed.modules()
    )
    with torch.no_grad():
        torch.testing.assert_close(
            deployed(frames, guidance), model(frames, guidance), rtol=1e-4, atol=1e-5
        )
        torch.testing.assert_close(
            deployed.infer(frames, guidance, chunk=2),
            model.infer(frames, guidance, chunk=2),
            rtol=1e-4,
            atol=1e-5,
        )


CUDA = pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")


@CUDA
def test_temporal_auto_falls_back_where_the_kernels_cannot_run() -> None:
    fusion = StateFusion("auto")
    x = torch.zeros(1, 128, 4, 4, device="cuda")
    flow = torch.zeros(1, 1, 5, 4, 4, device="cuda")
    assert fusion.use_kernels(x, flow) == _HAS_DIRECT_ATTENTION
    assert not fusion.use_kernels(x.double(), flow)
    assert not fusion.use_kernels(x, flow.double())
    assert not fusion.use_kernels(x.cpu(), flow.cpu())
    torch.use_deterministic_algorithms(True)
    try:
        assert not fusion.use_kernels(x, flow)
    finally:
        torch.use_deterministic_algorithms(False)


def test_alignment_cues_follow_their_definitions() -> None:
    torch.manual_seed(81)
    source = torch.rand(2, 3, 6, 8)
    zero = torch.zeros(2, 2, 6, 8)
    # Sampling at pixel centres rounds the normalized grid: zero up to ~1e-7.
    torch.testing.assert_close(
        alignment_cues(source, source, zero, zero),
        torch.zeros(2, 3, 6, 8),
        rtol=0,
        atol=1e-6,
    )
    # target(y, x) = source(y - 1, x + 2): flow (2, -1) leaves the frame on the
    # last two columns and the first row.
    target = torch.rand(2, 3, 6, 8)
    target[:, :, 1:, :6] = source[:, :, :5, 2:]
    flow = torch.tensor([2.0, -1.0])[None, :, None, None].expand(2, 2, 6, 8)
    inside = torch.zeros(6, 8, dtype=torch.bool)
    inside[1:, :6] = True
    cues = alignment_cues(target, source, flow, -flow)
    assert cues[:, 0][:, inside].abs().max() < 1e-6
    assert cues[:, 0][:, ~inside].abs().min() > 0
    torch.testing.assert_close(cues[:, 1], torch.zeros(2, 6, 8))
    assert torch.equal(cues[:, 2], (~inside).float().expand(2, 6, 8))
    disagreement = torch.tensor([0.3, -0.4])[None, :, None, None]
    cues = alignment_cues(target, source, flow, -flow + disagreement)
    torch.testing.assert_close(cues[:, 1], torch.full((2, 6, 8), 0.5))


def test_pack_guidance_gives_each_donor_its_cues() -> None:
    torch.manual_seed(82)
    model = RDUAL(scale=2, use_checkpoint=False)
    frames = torch.rand(1, 3, 3, 8, 12)
    guidance = guidance_for(frames)
    packed = model.pack_guidance(frames, guidance)
    assert packed.shape == (*guidance.shape[:3], 5, 4, 6)
    assert torch.equal(packed[:, :, :, :2], guidance)
    small = torch.nn.functional.avg_pool2d(frames[0], 2)[:, None]
    for i in range(2):
        torch.testing.assert_close(
            packed[:, i, 0, 2:],
            alignment_cues(
                small[i + 1], small[i], guidance[:, i, 0], guidance[:, i, 1]
            ),
        )
        torch.testing.assert_close(
            packed[:, i, 1, 2:],
            alignment_cues(
                small[i], small[i + 1], guidance[:, i, 1], guidance[:, i, 0]
            ),
        )


LANE_DEVICES = [
    pytest.param("cpu", id="reference"),
    pytest.param(
        "cuda",
        id="kernels",
        marks=pytest.mark.skipif(
            not (_HAS_DIRECT_ATTENTION and torch.cuda.is_available()),
            reason="the kernel path needs CUDA and Triton",
        ),
    ),
]


def make_fusion(device: str) -> StateFusion:
    torch.manual_seed(83)
    fusion = StateFusion("reference" if device == "cpu" else "triton").to(device)
    with torch.no_grad():
        fusion.output.weight.normal_(std=0.02)
        fusion.key.weight[31::32].normal_(std=0.02)
    return fusion


def fusion_inputs(device: str) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Center, two donor states and their 5-channel flow on device."""
    generator = torch.Generator().manual_seed(84)
    center = torch.randn(2, 128, 5, 7, generator=generator)
    states = torch.randn(2, 2, 128, 5, 7, generator=generator)
    flow = torch.cat(
        (
            torch.randn(2, 2, 2, 5, 7, generator=generator) * 0.6,
            torch.rand(2, 2, 3, 5, 7, generator=generator),
        ),
        2,
    )
    return center.to(device), states.to(device), flow.to(device)


SLOTS = torch.tensor([0, 1])


@pytest.mark.parametrize("device", LANE_DEVICES)
def test_bias_lane_adds_exactly_to_the_score(device: str) -> None:
    fusion = make_fusion(device)
    center, states, flow = fusion_inputs(device)
    valid = torch.ones(2, 2, dtype=torch.bool, device=device)
    slots = SLOTS.to(device)
    with torch.no_grad():
        # One constant on every donor sample is the same softmax as its
        # opposite on the null slot, up to the rounding of the shifted logits.
        fusion.cue_score[2].bias.fill_(2.5)
        raised = fusion(center, states, valid, flow, slots)
        fusion.cue_score[2].bias.zero_()
        fusion.null_bias.sub_(2.5)
        lowered = fusion(center, states, valid, flow, slots)
        torch.testing.assert_close(raised, lowered, rtol=1e-5, atol=1e-5)
        fusion.null_bias.add_(2.5)
        # A score of about -8400 on every sample of slot 1 masks it: the cue
        # score reads the photometric cue alone, 1 for slot 1 and 0 for slot 0.
        fusion.cue_score[0].weight.zero_()
        fusion.cue_score[0].bias.zero_()
        fusion.cue_score[0].weight[0, 0, 1, 1] = 1.0
        fusion.cue_score[2].weight.zero_()
        fusion.cue_score[2].weight[:, 0] = -1e4
        marked = flow.clone()
        marked[:, :, 2:] = 0
        marked[:, 1, 2] = 1
        masked = fusion(center, states, valid, marked, slots)
        closed = valid.clone()
        closed[:, 1] = False
        invalid = fusion(center, states, closed, marked, slots)
        torch.testing.assert_close(masked, invalid, rtol=1e-6, atol=1e-6)
        unmarked = marked.clone()
        unmarked[:, 1, 2] = 0
        assert not torch.allclose(
            fusion(center, states, valid, unmarked, slots), invalid, atol=1e-4
        )


def test_cues_change_nothing_until_the_cue_score_is_trained() -> None:
    torch.manual_seed(85)
    model = RDUAL(scale=2, use_checkpoint=False).eval()
    with torch.no_grad():
        model.temporal.output.weight.normal_(std=0.02)
    frame = torch.rand(1, 3, 8, 8)
    state = torch.randn(1, 128, 4, 4)
    flow = torch.randn(1, 2, 4, 4) * 0.6
    cues = torch.rand(1, 3, 4, 4)

    def run(cue: torch.Tensor) -> torch.Tensor:
        return step(model, frame, state, torch.cat((flow, cue), 1))[0]

    with torch.no_grad():
        base = run(torch.zeros_like(cues))
        assert torch.equal(run(cues), base)
        model.temporal.cue_score[2].weight.normal_(std=0.5)
        base = run(torch.zeros_like(cues))
        assert not torch.allclose(run(cues), base, atol=1e-5)


def chunk_case(batch: int = 1) -> tuple[RDUAL, torch.Tensor, torch.Tensor]:
    torch.manual_seed(87)
    model = RDUAL(scale=2, use_checkpoint=False).eval()
    randomize_fusion(model)
    frames = torch.rand(batch, 7, 3, 8, 8)
    return model, frames, guidance_for(frames)


def test_infer_without_chunks_is_forward() -> None:
    model, frames, guidance = chunk_case()
    with torch.no_grad():
        expected = model(frames, guidance)
    for chunk in (0, -2, 7, 20):
        assert torch.equal(model.infer(frames, guidance, chunk=chunk), expected)


def test_chunks_equal_forward_when_the_look_ahead_reaches_the_end() -> None:
    model, frames, guidance = chunk_case()
    with torch.no_grad():
        expected = model(frames, guidance)
    # Chunks [0,3), [3,6), [6,7): a look-ahead of 4 lets the first one reach
    # the clip's end, so every chunk's reverse sweep is forward()'s.
    for lookahead in (4, 7, 30):
        got = model.infer(frames, guidance, chunk=3, lookahead=lookahead)
        assert torch.equal(got, expected), lookahead
    # One frame short, the first chunk's last frame misses the last future.
    short = model.infer(frames, guidance, chunk=3, lookahead=3)
    assert not torch.allclose(short[:, 2], expected[:, 2], atol=1e-5)
    # Without look-ahead the last frame of every chunk but the final one has
    # no future at all.
    blind = model.infer(frames, guidance, chunk=3, lookahead=0)
    for t in (2, 5):
        assert not torch.allclose(blind[:, t], expected[:, t], atol=1e-5), t


def test_infer_edges_do_not_depend_on_chunk_boundaries() -> None:
    model, frames, guidance = chunk_case(batch=2)
    # Chunks of 3: a cut at the first boundary (frames 2|3) and an invalid
    # frame inside the first chunk's look-ahead, then an invalid first frame
    # of the second chunk and a cut inside the look-ahead of the second.
    validity = {
        "shot_ids": torch.tensor([[0, 0, 0, 1, 1, 1, 1], [0, 0, 0, 0, 0, 1, 1]]),
        "frame_valid": torch.tensor(
            [
                [True, True, True, True, True, False, True],
                [True, True, True, False, True, True, True],
            ]
        ),
    }
    with torch.no_grad():
        expected = model(frames, guidance, **validity)
    got = model.infer(frames, guidance, **validity, chunk=3, lookahead=4)
    assert torch.equal(got, expected)


def test_infer_moves_one_window_at_a_time(monkeypatch: pytest.MonkeyPatch) -> None:
    model, frames, guidance = chunk_case()
    expected = model.infer(frames, guidance, chunk=2, lookahead=2)
    windows: list[tuple[int, int, str]] = []
    pack = model.pack_guidance

    def counting_pack(window: torch.Tensor, flow: torch.Tensor) -> torch.Tensor:
        windows.append((window.shape[1], flow.shape[1], window.device.type))
        return pack(window, flow)

    # Every frame the model runs passes through the stem twice (frame and
    # coarse retrieval input), one frame per call.
    stems: list[int] = []
    handle = model.stem.register_forward_hook(
        lambda _, args, __: stems.append(args[0].shape[0])
    )
    monkeypatch.setattr(model, "pack_guidance", counting_pack)
    got = model.infer(frames, guidance, chunk=2, lookahead=2, offload="cpu")
    handle.remove()
    assert got.device.type == "cpu" and got.shape == (1, 7, 3, 16, 16)
    assert torch.equal(got, expected)
    # Chunks [0,2), [2,4), [4,6), [6,7): each window is the chunk, its
    # look-ahead and, after the first, the frame that links the carried state;
    # none holds the whole clip, and the linking frame is not run again.
    assert windows == [(4, 3, "cpu"), (5, 4, "cpu"), (4, 3, "cpu"), (2, 1, "cpu")]
    assert len(stems) == 2 * (4 + 4 + 3 + 1) and set(stems) == {1}


def test_infer_validates_its_arguments() -> None:
    model, frames, guidance = chunk_case()
    for options in ({"chunk": 2.0}, {"lookahead": 1.5}, {"chunk": True}):
        with pytest.raises(ValueError, match="ints"):
            model.infer(frames, guidance, **options)
    with pytest.raises(ValueError, match="non-negative"):
        model.infer(frames, guidance, chunk=2, lookahead=-1)
    with pytest.raises(ValueError, match="Guidance"):
        model.infer(frames, guidance[:, :, :1], chunk=2)
    with pytest.raises(ValueError, match="detached"):
        model.infer(frames, guidance.requires_grad_(), chunk=2)


def test_fusion_reads_a_normalized_donor() -> None:
    fusion = make_fusion("cpu")
    center, states, flow = fusion_inputs("cpu")
    valid = torch.ones(2, 2, dtype=torch.bool)
    with torch.no_grad():
        plain = fusion(center, states, valid, flow, SLOTS) - center
        scaled = fusion(center, 10 * states, valid, flow, SLOTS) - center
        with pytest.raises(ValueError, match="donors,5"):
            fusion(center, states, valid, flow[:, :, :2], SLOTS)
    assert plain.abs().max() > 1e-3
    torch.testing.assert_close(scaled, plain, rtol=1e-4, atol=1e-6)


def test_context_neighborhoods_match_between_training_and_inference_layouts() -> None:
    # Trunk 36x40: G16 neighborhoods, C32 neighborhoods and whole C64 windows.
    torch.manual_seed(12)
    model = RDUAL(scale=2, use_checkpoint=False)
    randomize_fusion(model)
    frames = torch.rand(1, 2, 3, 72, 80)
    guidance = guidance_for(frames)
    with torch.no_grad():
        trained = model.train()(frames, guidance)
        inferred = model.eval()(frames, guidance)
    torch.testing.assert_close(trained, inferred, rtol=1e-5, atol=1e-6)
    frames.requires_grad_()
    model.train()(frames, guidance).square().mean().backward()
    assert frames.grad is not None and frames.grad.abs().sum() > 0
    assert model.groups[0].layers[2].attention.qkv.weight.grad.abs().sum() > 0


@pytest.mark.parametrize("retrieval_na", [False, True])
def test_retrieval_spans_several_blocks(retrieval_na: bool) -> None:
    # Trunk 98x50: two retrieval block rows, the second a partial one; with
    # retrieval_na the 49x25 coarse grid takes the neighborhood path instead.
    torch.manual_seed(13)
    model = RDUAL(scale=1, use_checkpoint=False, retrieval_na=retrieval_na).eval()
    with torch.no_grad():
        model.xr.project.weight.normal_(std=0.02)
        frames = torch.rand(1, 1, 3, 196, 100)
        out = model(frames, torch.zeros(1, 0, 2, 2, 98, 50))
    assert out.shape == (1, 1, 3, 196, 100) and out.isfinite().all()


def test_checkpoint_under_cpu_autocast_keeps_the_gradients() -> None:
    torch.manual_seed(14)
    direct = RDUAL(scale=2, use_checkpoint=False).train()
    randomize_fusion(direct)
    recompute = copy.deepcopy(direct)
    recompute.use_checkpoint = True
    for group in recompute.groups:
        group.use_checkpoint = True
    frames = torch.rand(1, 3, 3, 8, 8)
    guidance = guidance_for(frames)
    outputs = []
    for model in (direct, recompute):
        with torch.autocast("cpu", torch.bfloat16):
            out = model(frames, guidance)
        out.float().square().mean().backward()
        outputs.append(out.detach())
    torch.testing.assert_close(outputs[0], outputs[1], rtol=0, atol=0)
    for name, value in direct.named_parameters():
        other = recompute.get_parameter(name).grad
        assert (value.grad is None) == (other is None), name
        if value.grad is not None:
            torch.testing.assert_close(value.grad, other, rtol=1e-2, atol=1e-5)


def test_clip_and_step_inputs_are_validated() -> None:
    model = rdual(scale=2, use_checkpoint=False).eval()
    frames = torch.rand(1, 2, 3, 8, 8)
    guidance = torch.zeros(1, 1, 2, 2, 4, 4)
    with pytest.raises(ValueError, match="B,T,3,H,W"):
        model(frames[0], guidance)
    with pytest.raises(ValueError, match="frame_valid"):
        model(frames, guidance, torch.ones(1, 2))
    with pytest.raises(ValueError, match="shot_ids"):
        model(frames, guidance, shot_ids=torch.zeros(2, 1))
    with pytest.raises(ValueError, match="positive"):
        model.backward_clip(frames, guidance, lambda out, t: out.mean(), grad_chunk=0)
    encoded = model.encode(frames[:, 0])
    state = torch.zeros(1, 128, 4, 4)
    flow = torch.zeros(1, 5, 4, 4)
    on = torch.ones(1, dtype=torch.bool)
    with pytest.raises(ValueError, match="carried state"):
        model.step_encoded(encoded, state, flow.requires_grad_())
    with pytest.raises(ValueError, match="future state"):
        model.step_encoded(encoded, future=(state, flow, on))


NEUFLOW_WEIGHTS = Path("experiments/pretrained_models/neuflow_v2.safetensors")


def with_own_flow(model: RDUAL) -> RDUAL:
    """Mark the flow's own random weights as loaded, so guidance() runs anywhere."""
    model.load_flow_weights(copy.deepcopy(model.flow.state_dict()))
    return model


def test_missing_guidance_is_computed_by_the_flow() -> None:
    torch.set_num_threads(2)
    torch.manual_seed(91)
    model = with_own_flow(RDUAL(scale=2, use_checkpoint=False)).eval()
    randomize_fusion(model)
    frames = torch.rand(1, 3, 3, 8, 8)
    with torch.no_grad():
        guidance = model.guidance(frames)
        assert torch.isfinite(guidance).all()
        torch.testing.assert_close(
            model(frames), model(frames, guidance), rtol=0, atol=0
        )
        torch.testing.assert_close(
            model.infer(frames, chunk=2, lookahead=0),
            model.infer(frames, guidance, chunk=2, lookahead=0),
            rtol=0,
            atol=0,
        )
    explicit = copy.deepcopy(model).train()
    model.train()
    targets = torch.rand(1, 3, 3, 16, 16)

    def loss(out: torch.Tensor, t: int) -> torch.Tensor:
        return (out - targets[:, t]).abs().mean()

    got = model.backward_clip(frames, None, loss)
    want = explicit.backward_clip(frames, guidance, loss)
    torch.testing.assert_close(got, want, rtol=0, atol=0)
    for (name, p), q in zip(
        model.named_parameters(), explicit.parameters(), strict=True
    ):
        assert (p.grad is None) == (q.grad is None), name
        if p.grad is not None:
            torch.testing.assert_close(p.grad, q.grad, rtol=0, atol=0)


def test_guidance_shapes_dtype_and_precision_settings() -> None:
    torch.set_num_threads(2)
    model = with_own_flow(RDUAL(scale=2, use_checkpoint=False))
    frames = torch.rand(2, 3, 3, 9, 11, requires_grad=True)
    precision = torch.get_float32_matmul_precision()
    cudnn_tf32 = torch.backends.cudnn.allow_tf32
    torch.set_float32_matmul_precision("high")
    torch.backends.cudnn.allow_tf32 = True
    try:
        with torch.autocast("cpu", dtype=torch.bfloat16):
            guidance = model.guidance(frames)
        assert torch.get_float32_matmul_precision() == "high"
        assert torch.backends.cudnn.allow_tf32
    finally:
        torch.set_float32_matmul_precision(precision)
        torch.backends.cudnn.allow_tf32 = cudnn_tf32
    assert guidance.shape == (2, 2, 2, 2, 6, 6)
    assert guidance.dtype == torch.float32 and not guidance.requires_grad
    assert model.guidance(frames[:, :1]).shape == (2, 0, 2, 2, 6, 6)
    # Pairs run in groups of 16: a clip longer than one group gives each pair
    # the flow it gets on its own.
    clip = torch.rand(1, 19, 3, 8, 8)
    whole = model.guidance(clip)
    torch.testing.assert_close(whole[:, -2:], model.guidance(clip[:, -3:]))


def test_guidance_under_per_backend_precision_settings() -> None:
    torch.set_num_threads(2)
    model = with_own_flow(RDUAL(scale=2, use_checkpoint=False))
    matmul, conv = torch.backends.cuda.matmul, torch.backends.cudnn.conv
    saved = matmul.fp32_precision, conv.fp32_precision
    # One backend set on its own makes the global precision getters raise.
    matmul.fp32_precision = "tf32"
    conv.fp32_precision = "tf32"
    try:
        guidance = model.guidance(torch.rand(1, 2, 3, 8, 8))
        assert (matmul.fp32_precision, conv.fp32_precision) == ("tf32", "tf32")
    finally:
        matmul.fp32_precision, conv.fp32_precision = saved
    assert torch.isfinite(guidance).all()


def test_flow_pairs_per_call_follow_the_correlation_size() -> None:
    # A 192x192 crop keeps the full group; the two flows of one padded
    # 1488x848 pair already pass the budget, so its pairs run one at a time.
    assert _flow_pairs_per_call(192, 192) == 16
    assert _flow_pairs_per_call(512, 1024) == 4
    assert _flow_pairs_per_call(848, 1488) == 1


def test_flow_is_frozen_saved_and_flagged(tmp_path: Path) -> None:
    torch.set_num_threads(2)
    torch.manual_seed(92)
    model = RDUAL(scale=2, use_checkpoint=False)
    assert not bool(model.flow_loaded)
    assert all(not p.requires_grad for p in model.flow.parameters())
    model.train()
    assert not any(m.training for m in model.flow.modules())
    assert model.groups.training

    # A DUAL Light checkpoint leaves the flag False; loading the flow sets it.
    spatial = dual_light(scale=2, use_checkpoint=False)
    missing, _ = model.load_state_dict(spatial.state_dict(), strict=False)
    assert "flow_loaded" in missing and any(n.startswith("flow.") for n in missing)
    assert not bool(model.flow_loaded)
    with_own_flow(model)
    assert bool(model.flow_loaded)

    path = tmp_path / "rdual.pth"
    torch.save(model.state_dict(), path)
    restored = RDUAL(scale=2, use_checkpoint=False)
    restored.load_state_dict(torch.load(path, weights_only=True))
    assert bool(restored.flow_loaded)
    for key, value in model.flow.state_dict().items():
        assert torch.equal(restored.flow.state_dict()[key], value), key

    # Training leaves the flow bit-identical.
    before = copy.deepcopy(model.flow.state_dict())
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-2)
    frames = torch.rand(1, 3, 3, 8, 8)
    model.backward_clip(frames, None, lambda out, t: out.square().mean())
    optimizer.step()
    for key, value in model.flow.state_dict().items():
        assert torch.equal(value, before[key]), key


def test_flow_does_not_change_the_seeded_weights(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    torch.manual_seed(93)
    model = RDUAL(scale=2, use_checkpoint=False)
    after = torch.rand(4)
    # The same construction without the flow estimator
    monkeypatch.setattr(rdual_arch, "NeuFlowV2", torch.nn.Module)
    torch.manual_seed(93)
    bare = RDUAL(scale=2, use_checkpoint=False)
    torch.testing.assert_close(torch.rand(4), after, rtol=0, atol=0)
    flowless = bare.state_dict()
    state = {k: v for k, v in model.state_dict().items() if not k.startswith("flow.")}
    assert state.keys() == flowless.keys()
    for key, value in state.items():
        assert torch.equal(value, flowless[key]), key


@pytest.mark.skipif(not NEUFLOW_WEIGHTS.exists(), reason=f"needs {NEUFLOW_WEIGHTS}")
def test_real_flow_finds_still_and_shifted_frames() -> None:
    from safetensors.torch import load_file

    torch.set_num_threads(2)
    model = RDUAL(scale=2, use_checkpoint=False)
    model.load_flow_weights(load_file(str(NEUFLOW_WEIGHTS)))
    gen = torch.Generator().manual_seed(0)
    coarse = torch.rand(1, 3, 6, 6, generator=gen)
    smooth = torch.nn.functional.interpolate(
        coarse, size=(64, 72), mode="bicubic", align_corners=False
    )
    image = (0.8 * smooth + 0.2 * torch.rand(1, 3, 64, 72, generator=gen)).clamp(0, 1)
    still = model.guidance(image[:, None].expand(1, 3, 3, 64, 72)).abs()
    # in token pixels; a moving clip gives displacements of several pixels
    assert still.mean() < 0.02 and still.max() < 0.5
    shifted = torch.stack([image, torch.roll(image, shifts=4, dims=-1)], 1)
    out = model.guidance(shifted)[0, 0, :, :, 8:-8, 8:-8]
    # frame 1 is frame 0 moved 4 px right: 2 token pixels in x, none in y
    assert (out[0, 0].median() + 2).abs() < 0.5
    assert (out[1, 0].median() - 2).abs() < 0.5
    assert out[:, 1].abs().median() < 0.5


@pytest.mark.skipif(not torch.cuda.is_available(), reason="requires CUDA")
def test_tensorrt_guidance_uses_current_weights_and_both_directions() -> None:
    pytest.importorskip("tensorrt")
    pytest.importorskip("onnx")
    from traiNNer.ops.neuflow_trt import FrozenFlowRunner

    torch.set_num_threads(2)
    torch.manual_seed(458)
    model = RDUAL(scale=2, use_checkpoint=False).cuda().eval()
    with_own_flow(model)
    runner = FrozenFlowRunner(model.flow)
    frames = torch.rand(2, 10, 3, 41, 55, device="cuda")
    for clip in (frames[:, :2], frames):
        reference = model.guidance(clip)
        result = model.guidance(clip, estimator=runner)
        torch.testing.assert_close(result, reference, atol=2e-3, rtol=1e-4)

    weights = model.flow.state_dict()
    bias = "refine_s8.conv3.bias"
    weights[bias] = weights[bias].clone()
    weights[bias][:2] += 0.25
    model.load_flow_weights(weights)
    reference = model.guidance(frames)
    assert (reference - result).abs().max() > 0.1
    torch.testing.assert_close(
        model.guidance(frames, estimator=runner), reference, atol=2e-3, rtol=1e-4
    )

    # At this crop a profile for 16 simultaneous pairs exceeded the workspace.
    wide = torch.rand(1, 2, 3, 256, 320, device="cuda")
    torch.testing.assert_close(
        model.guidance(wide, estimator=runner),
        model.guidance(wide),
        atol=2e-3,
        rtol=1e-4,
    )
