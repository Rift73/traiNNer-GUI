"""The YUV channel shift moves BT.2020 chroma only: luma stays exactly, Cb and
Cr move by their own offsets with mirrored borders, and the offsets are drawn
from the project RNG (x then y, Cb then Cr, never for Y).

The torch path runs on the CPU; the CUDA kernel is compared with it on a GPU.
"""

from __future__ import annotations

from collections.abc import Mapping
from types import SimpleNamespace
from typing import Any, cast

import numpy as np
import pytest
import torch
from torch import Tensor
from traiNNer.data.gpu_degradations import chroma_shift_pt, sample_shift
from traiNNer.models import realesrgan_model
from traiNNer.models.realesrgan_model import RealESRGANModel, warn_ignored_luma_shift
from traiNNer.utils.redux_options import ReduxOptions
from traiNNer.utils.rng import RNG

# The unbound method, called with a stand-in model.
_APPLY_SHIFT = vars(RealESRGANModel)["_apply_shift"]

KR, KB = 0.2627, 0.0593
KG = 1 - KR - KB


def _luma(rgb: Tensor) -> Tensor:
    return KR * rgb[:, 0] + KG * rgb[:, 1] + KB * rgb[:, 2]


def _saturated(batch: int, height: int, width: int, seed: int) -> Tensor:
    """Random RGB with blocks of pure and near-pure colours, so shifted chroma
    lands on pixels where unscaled it would leave [0, 1]."""
    generator = torch.Generator().manual_seed(seed)
    image = torch.rand(batch, 3, height, width, generator=generator)
    grid = image[:, :, ::4, ::4]
    image[:, :, ::4, ::4] = torch.randint(0, 2, grid.shape, generator=generator).float()
    image[:, :, : height // 2, : width // 3] = torch.tensor([1.0, 0.0, 0.0])[
        :, None, None
    ]
    image[:, :, height // 2 :, width // 3 : 2 * width // 3] = torch.tensor(
        [0.0, 0.0, 1.0]
    )[:, None, None]
    return image


def _model(**options: object) -> SimpleNamespace:
    """What _apply_shift reads of the model."""
    zero = [[0, 0], [0, 0]]
    opt = {
        "shift_prob": 0.05,
        "shift_types": ["yuv"],
        "shift_percent": False,
        "shift_yuv_y": zero,
        "shift_yuv_u": zero,
        "shift_yuv_v": zero,
        **options,
    }
    return SimpleNamespace(opt=SimpleNamespace(**opt))


@pytest.mark.parametrize(
    ("cb", "cr"), [((2, -1), (-3, 2)), ((0, 4), (0, 0)), ((-9, 13), (11, -7))]
)
def test_luma_is_kept_on_saturated_edges(
    cb: tuple[int, int], cr: tuple[int, int]
) -> None:
    image = _saturated(2, 24, 30, seed=3)
    out = chroma_shift_pt(image, cb, cr)
    assert float(out.min()) >= 0 and float(out.max()) <= 1
    torch.testing.assert_close(_luma(out), _luma(image), rtol=0, atol=1e-6)
    assert not torch.equal(out, image)


@pytest.mark.parametrize(("cb", "cr"), [((2, -1), (-3, 2)), ((-5, 0), (0, 6))])
def test_chroma_planes_move_by_their_own_offsets(
    cb: tuple[int, int], cr: tuple[int, int]
) -> None:
    """Mid-grey colours keep RGB in range, so no chroma is scaled down: Cb and
    Cr of the output are those of the input at (x - dx, y - dy), reflected
    (REFLECT_101) at the borders."""
    generator = torch.Generator().manual_seed(5)
    image = 0.4 + 0.2 * torch.rand(2, 3, 17, 21, generator=generator)
    out = chroma_shift_pt(image, cb, cr)

    def moved(plane: Tensor, dx: int, dy: int) -> Tensor:
        pad = max(abs(dx), abs(dy))
        padded = np.pad(plane.numpy(), ((0, 0), (pad, pad), (pad, pad)), "reflect")
        height, width = plane.shape[-2:]
        return torch.from_numpy(
            padded[:, pad - dy : pad - dy + height, pad - dx : pad - dx + width]
        )

    cb_in, cr_in = image[:, 2] - _luma(image), image[:, 0] - _luma(image)
    cb_out, cr_out = out[:, 2] - _luma(out), out[:, 0] - _luma(out)
    torch.testing.assert_close(cb_out, moved(cb_in, *cb), rtol=0, atol=2e-6)
    torch.testing.assert_close(cr_out, moved(cr_in, *cr), rtol=0, atol=2e-6)


def test_zero_offsets_return_the_input() -> None:
    image = _saturated(1, 8, 8, seed=0)
    assert chroma_shift_pt(image, (0, 0), (0, 0)) is image


def test_zero_ranges_take_no_draw(monkeypatch: pytest.MonkeyPatch) -> None:
    rng = np.random.default_rng(11)
    monkeypatch.setattr(RNG, "_rng", rng)
    before = rng.bit_generator.state
    assert sample_shift([[0, 0], [0, 0]], 40, 48) == (0, 0)
    assert sample_shift([[0, 0], [0, 0]], 40, 48, percent=True) == (0, 0)
    assert sample_shift([[3, 3], [-2, -2]], 40, 48) == (3, -2)
    assert rng.bit_generator.state == before


def _apply(
    monkeypatch: pytest.MonkeyPatch, model: SimpleNamespace, image: Tensor, seed: int
) -> tuple[Tensor, list[tuple[tuple[int, int], tuple[int, int]]], Mapping[str, Any]]:
    """_apply_shift with the project RNG freshly seeded: the output, the
    offsets chroma_shift_pt got and the RNG state afterwards."""
    calls: list[tuple[tuple[int, int], tuple[int, int]]] = []

    def recording(
        tensor: Tensor, cb_offset: tuple[int, int], cr_offset: tuple[int, int]
    ) -> Tensor:
        calls.append((cb_offset, cr_offset))
        return chroma_shift_pt(tensor, cb_offset, cr_offset)

    monkeypatch.setattr(realesrgan_model, "chroma_shift_pt", recording)
    rng = np.random.default_rng(seed)
    monkeypatch.setattr(RNG, "_rng", rng)
    out = _APPLY_SHIFT(cast(RealESRGANModel, model), image)
    return out, calls, rng.bit_generator.state


def test_luma_range_is_ignored_with_one_warning(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    warnings: list[str] = []
    logger = SimpleNamespace(
        warning=lambda message, *args: warnings.append(message % args)
    )
    monkeypatch.setattr(realesrgan_model, "get_root_logger", lambda: logger)
    ranges = {"shift_yuv_u": [[-2, 2], [-2, 2]], "shift_yuv_v": [[-2, 2], [-2, 2]]}
    with_luma = _model(shift_yuv_y=[[-2, 2], [-2, 2]], **ranges)
    without = _model(**ranges)

    warn_ignored_luma_shift(cast(ReduxOptions, with_luma.opt))
    assert len(warnings) == 1
    assert "shift_yuv_y" in warnings[0]
    warn_ignored_luma_shift(cast(ReduxOptions, without.opt))
    # No warning either when no YUV shift can fire.
    luma = [[-2, 2], [-2, 2]]
    never = _model(shift_prob=0.0, shift_yuv_y=luma)
    other_types = _model(shift_types=["rgb", "cmyk"], shift_yuv_y=luma)
    warn_ignored_luma_shift(cast(ReduxOptions, never.opt))
    warn_ignored_luma_shift(cast(ReduxOptions, other_types.opt))
    assert len(warnings) == 1

    image = _saturated(2, 16, 20, seed=1)
    for seed in range(5):
        out, calls, state = _apply(monkeypatch, with_luma, image, seed)
        expected, expected_calls, expected_state = _apply(
            monkeypatch, without, image, seed
        )
        assert torch.equal(out, expected)
        assert calls == expected_calls
        assert state == expected_state
        torch.testing.assert_close(_luma(out), _luma(image), rtol=0, atol=1e-6)


def test_draws_follow_the_cadence(monkeypatch: pytest.MonkeyPatch) -> None:
    """The shift type, then Cb x, Cb y, Cr x, Cr y, inclusive integers."""
    model = _model(shift_yuv_u=[[-2, 2], [0, 3]], shift_yuv_v=[[1, -1], [4, 4]])
    image = _saturated(1, 16, 20, seed=2)
    _, calls, _ = _apply(monkeypatch, model, image, 9)
    rng = np.random.default_rng(9)
    rng.choice(["yuv"])
    expected = (
        (int(rng.integers(-2, 3)), int(rng.integers(0, 4))),
        (int(rng.integers(-1, 2)), 4),
    )
    assert calls == [expected]


def test_percent_x_uses_width_and_y_uses_height(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """25 % of a 40 x 48 (height x width) image: 12 pixels in x, 10 in y."""
    model = _model(
        shift_percent=True,
        shift_yuv_u=[[25, 25], [0, 0]],
        shift_yuv_v=[[0, 0], [25, 25]],
    )
    _, calls, _ = _apply(monkeypatch, model, _saturated(1, 40, 48, seed=0), 0)
    assert calls == [((12, 0), (0, 10))]


def test_clip_frames_share_one_offset_set(monkeypatch: pytest.MonkeyPatch) -> None:
    """A clip chain passes its T frames as one batch: one draw, every frame
    shifted by the same offsets."""
    model = _model(shift_yuv_u=[[-3, 3], [-3, 3]], shift_yuv_v=[[-3, 3], [-3, 3]])
    clip = _saturated(6, 16, 20, seed=4)
    out, calls, _ = _apply(monkeypatch, model, clip, 21)
    assert len(calls) == 1
    cb, cr = calls[0]
    assert (cb, cr) != ((0, 0), (0, 0))
    for t in range(clip.shape[0]):
        assert torch.equal(out[t : t + 1], chroma_shift_pt(clip[t : t + 1], cb, cr))


@pytest.mark.skipif(not torch.cuda.is_available(), reason="needs CUDA")
@pytest.mark.parametrize("channels_last", [False, True])
@pytest.mark.parametrize(
    ("cb", "cr"), [((2, -1), (-3, 2)), ((0, 5), (7, 0)), ((-40, 33), (29, -50))]
)
def test_kernel_matches_torch(
    channels_last: bool, cb: tuple[int, int], cr: tuple[int, int]
) -> None:
    image = _saturated(3, 37, 45, seed=7)
    memory_format = torch.channels_last if channels_last else torch.contiguous_format
    device = image.cuda().contiguous(memory_format=memory_format)
    actual = chroma_shift_pt(device, cb, cr)
    assert actual.is_contiguous(memory_format=memory_format)
    expected = chroma_shift_pt(image, cb, cr)
    assert float((actual.cpu() - expected).abs().max()) <= 2e-6
    torch.testing.assert_close(_luma(actual.cpu()), _luma(image), rtol=0, atol=1e-6)
