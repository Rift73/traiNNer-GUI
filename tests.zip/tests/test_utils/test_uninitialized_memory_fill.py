from collections.abc import Iterator
from typing import cast

import pytest
from torch.utils import deterministic
from traiNNer.utils.misc import (
    _UninitializedFillSetting,
    disable_uninitialized_memory_fill,
)

FILL_SETTING = cast(_UninitializedFillSetting, deterministic)


@pytest.fixture
def restore_fill_setting() -> Iterator[None]:
    previous = FILL_SETTING.fill_uninitialized_memory
    try:
        yield
    finally:
        FILL_SETTING.fill_uninitialized_memory = previous


@pytest.mark.usefixtures("restore_fill_setting")
@pytest.mark.parametrize("initial", [False, True])
def test_disable_uninitialized_memory_fill(initial: bool) -> None:
    FILL_SETTING.fill_uninitialized_memory = initial

    disable_uninitialized_memory_fill()

    assert not FILL_SETTING.fill_uninitialized_memory
