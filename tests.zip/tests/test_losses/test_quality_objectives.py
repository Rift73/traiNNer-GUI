"""Scores from the JPEG XL v0.13.0 tools on the same odd-sized RGB crop."""

import pytest
import torch

from traiNNer.losses import build_loss


@pytest.mark.parametrize(
    ("options", "expected", "tolerance"),
    [
        ({"type": "ssimulacra2loss"}, (100 + 24.90798463) / 100, 0.001),
        ({"type": "butteraugliloss", "pooling": "max"}, 45.7524642944, 0.003),
    ],
)
def test_jpegxl_scores_on_shifted_edges(options, expected, tolerance):
    y, x = torch.meshgrid(torch.arange(65), torch.arange(67), indexing="ij")
    target = torch.stack(((3 * x + 2 * y) % 256, (5 * y + x) % 256, (x + 7 * y) % 256))
    target = target.unsqueeze(0).float() / 255
    prediction = target.roll(2, dims=-2).requires_grad_()
    loss = build_loss(options)(prediction, target)
    assert loss.item() == pytest.approx(expected, abs=tolerance)
    (gradient,) = torch.autograd.grad(loss, prediction)
    assert torch.isfinite(gradient).all() and gradient.abs().max() > 0
